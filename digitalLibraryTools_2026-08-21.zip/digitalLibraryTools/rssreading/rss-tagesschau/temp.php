<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

  <html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta><meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>tagesschau.de | Schlagzeilen - rssreading</title><link rel="shortcut icon" href="../images/favicon/fav-tagesschau.ico"></link><link href="../css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="../js/unfold.js"></script><script type="text/javascript" src="../js/visitLink.js"></script><script type="text/javascript" src="../js/wndLocalStorage.js"></script><script type="text/javascript">
          </script><?php 
					include("../uc/header_imports_02.php");
				?><?php 
					include("../uc/articleItem.php");
				?><?php 
					include("../uc/articleLink.php");
				?><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Tagesschau");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="../rss-tagesschau/">
							  &gt; Alle Nachrichten (<?php 
								  echo '40';
								?>)</a></div></div><div class="divContent"><strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; tagesschau.de - Die Nachrichten der ARD</strong><hr></hr><strong xmlns="">&gt; Ausland (<?php 
		  echo '9';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'ausland',
                    	'1',
                    	'20 Aug 2026 22:15:53',
                    	'https://www.tagesschau.de/ausland/asien/stellungnahme-israel-westjordanland-siedler-100.html',
                    	'Europäer und Kanada fordern Israel auf, Siedlungspläne zurückzunehmen',
                    	'Im besetzten Westjordanland sollen weitere israelische Siedlungen entstehen - sie würden das Gebiet faktisch weiter aufspalten. Deutschland und sechs weitere Länder fordern Israel nun gemeinsam auf, die rechtswidrigen Pläne aufzugeben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'2',
                    	'20 Aug 2026 20:31:09',
                    	'https://www.tagesschau.de/ausland/belgien-dendermonde-goldschatz-100.html',
                    	'Auf Baustelle entdeckt: Wem gehört der Goldschatz von Dendermonde?',
                    	'Der Fund machte weltweit Schlagzeilen: In Belgien entdeckten Bauarbeiter bei Renovierungsarbeiten Gold im Wert von rund neun Millionen Euro. Doch wem gehört es? Die Spur könnte zu einer Brauereifamilie führen. Von S. Fritz.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'3',
                    	'20 Aug 2026 18:02:10',
                    	'https://www.tagesschau.de/ausland/afrika/unglueck-goldmine-tote-100.html',
                    	'Mehr als 100 Tote bei Einsturz von Goldmine in Zentralafrika',
                    	'Mindestens 100 Menschen sind am Dienstag bei einem Erdrutsch in einer Goldmine in der Zentralafrikanischen Republik ums Leben gekommen. Rettungskräfte suchen nach Überlebenden. Heute konnten sie jedoch nur weitere Leichen bergen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'4',
                    	'20 Aug 2026 17:12:08',
                    	'https://www.tagesschau.de/ausland/afrika/ervebo-impfstoff-ebola-kongo-100.html',
                    	'DR Kongo bekommt 70.000 Impfdosen gegen Ebola und hofft auf Wirksamkeit',
                    	'Im Kampf gegen Ebola bekommt die DR Kongo 70.000 Dosen des Impfstoffs Ervebo. Unklar ist, ob er gegen die vorherrschende Bundibugyo-Virusvariante wirkt. Eine klinische Studie soll das klären.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'5',
                    	'20 Aug 2026 17:08:15',
                    	'https://www.tagesschau.de/ausland/ungarn-oerr-nachrichten-100.html',
                    	'Ungarns öffentlich-rechtliches Fernsehen sendet wieder Nachrichten',
                    	'Unter Orban galt Ungarns öffentlich-rechtlicher Sender M1 als Sprachrohr der Regierung - das will der neue Regierungschef Magyar ändern. Nach einer Zwangspause sendet M1 nun wieder Nachrichten. Doch es gibt auch Kritik. Von D. Freches.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'6',
                    	'20 Aug 2026 16:08:49',
                    	'https://www.tagesschau.de/ausland/amerika/faq-usa-sanktionen-internationaler-strafgerichtshof-100.html',
                    	'Internationaler Strafgerichtshof: Vereint gegen Kriegsverbrechen und Völkermord?',
                    	'Der US-Regierung ist der Internationale Strafgerichtshof in Den Haag ein Dorn im Auge. Jüngst verhängte sie sogar Sanktionen gegen Gerichtsmitglieder. Aber welche Aufgaben hat der Gerichtshof eigentlich? Von A. Stephany und F. Bräutigam.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'7',
                    	'20 Aug 2026 10:10:35',
                    	'https://www.tagesschau.de/ausland/amerika/medizin-hautkrebs-studi-impfstoff-100.html',
                    	'Hoffnung auf Impfstoff gegen schwarzen Hautkrebs',
                    	'Mit der Entwicklung eines mRNA-basierten Impfstoffes könnte den US-Konzernen Merck und Moderna ein Erfolg in der Behandlung von schwarzem Hautkrebs gelungen sein. Finale Ergebnisse einer klinischen Studie machen Hoffnung.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'8',
                    	'20 Aug 2026 11:26:25',
                    	'https://www.tagesschau.de/ausland/amerika/trump-iran-222.html',
                    	'"Beispielloser Wirtschaftskrieg" - was steckt hinter Trumps Drohung?',
                    	'Weder militärisch noch diplomatisch geht es für Trump in Iran voran. Nun droht er Iran und allen Staaten, die das Regime unterstützen, mit einem "beispiellosen Wirtschaftskrieg". Wie ist das zu deuten?'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'9',
                    	'20 Aug 2026 09:22:10',
                    	'https://www.tagesschau.de/ausland/asien/israel-krieg-nahost-auswanderer-100.html',
                    	'Krieg in Nahost: Immer mehr Israelis verlassen das Land',
                    	'Die Zahl der Menschen, die Israel verlassen, übersteigt mittlerweile die Zahl derjenigen, die zuziehen. Ein Grund: der wachsende Einfluss ultraorthodoxer Parteien. Ökonomisch könnte der Trend zum Auswandern heikel werden. Von Jörg Poppendieck.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'ausland',
                    	'9'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Ausland - Europa (<?php 
		  echo '8';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'1',
                    	'20 Aug 2026 19:28:42',
                    	'https://www.tagesschau.de/ausland/europa/spanien-ceuta-fluechtlinge-lager-100.html',
                    	'Spanien richtet Unterkünfte für Migranten in Exklave Ceuta ein',
                    	'Im Juli gelangten Zehntausende Migranten von Marokko aus in die spanische Exklave Ceuta - die meisten kehrten danach zurück. Für die dort verbliebenen Menschen richtet Spaniens Regierung jetzt Unterkünfte ein.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'2',
                    	'20 Aug 2026 18:49:58',
                    	'https://www.tagesschau.de/ausland/europa/griechenland-infektionen-100.html',
                    	'West-Nil-Virus: 157 Fälle in Griechenland gemeldet',
                    	'Dutzende Menschen haben sich in Südeuropa in den vergangenen Wochen mit dem West-Nil-Virus infiziert. In Griechenland hat sich die Zahl seit Ende Juli vervierfacht, seit Jahresbeginn starben dort 13 Menschen nach einer Infektion.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'3',
                    	'20 Aug 2026 18:04:55',
                    	'https://www.tagesschau.de/ausland/europa/belgien-waldbrand-unter-kontrolle-100.html',
                    	'Waldbrand in Belgien nahe der deutschen Grenze unter Kontrolle',
                    	'Einer der größten Waldbrände in der Geschichte Belgiens ist laut Behörden "vollumfänglich" unter Kontrolle. Nur im Osten des Hohen Venn wird weiter gegen die Flammen gekämpft. Deutsche Feuerwehrkräfte rücken ab.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'4',
                    	'20 Aug 2026 16:03:48',
                    	'https://www.tagesschau.de/ausland/europa/daenemark-tourismus-100.html',
                    	'Urlaub in Dänemark boomt - vor allem bei Deutschen',
                    	'Dänemark ist als Reiseziel beliebt wie noch nie. Zwischen Januar und Juni kamen mehr Übernachtungsgäste als jemals zuvor in das Land. Die Urlauber kamen zu einem großen Teil aus Deutschland - doch nicht nur.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'5',
                    	'20 Aug 2026 14:10:48',
                    	'https://www.tagesschau.de/ausland/europa/rumaenien-abschuss-drohne-sprengstoff-100.html',
                    	'Kampfjet schießt in Rumänien mit Sprengstoff versehene Drohne ab',
                    	'Schon mehrfach sind in diesem Jahr Drohnen in den rumänischen Luftraum eingedrungen. Doch beim jüngsten Vorfall war eine schwimmende Drohne mit Sprengstoff präpariert - was an den Drohnenfund auf dem Flughafen Leipzig/Halle erinnert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'6',
                    	'20 Aug 2026 07:27:15',
                    	'https://www.tagesschau.de/ausland/europa/harry-meghan-rueckkehr-grossbritannien-100.html',
                    	'Prinz Harry und Meghan kehren wohl nach Großbritannien zurück',
                    	'Anfang 2020 entschieden sich der britische Prinz Harry und seine Frau Meghan, ihre königlichen Pflichten abzugeben und ins Ausland zu ziehen. Nun steht Medienberichten zufolge die Rückkehr des Paares nach England kurz bevor.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'7',
                    	'20 Aug 2026 13:57:49',
                    	'https://www.tagesschau.de/ausland/europa/ukraine-krieg-russland-kiew-100.html',
                    	'Massive russische Angriffe auf die ukrainische Hauptstadt Kiew',
                    	'Russland hat die ukrainische Hauptstadt Kiew erneut massiv angegriffen. Mindestens 16 Menschen wurden getötet, mehr als 30 verletzt. Polen reagierte mit einer militärischen Luftoperation zum Schutz seines Luftraums.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'8',
                    	'20 Aug 2026 05:05:04',
                    	'https://www.tagesschau.de/ausland/europa/ukraine-debatte-wahlen-100.html',
                    	'Fedorow fordert Wahlen in der Ukraine - während des Krieges',
                    	'Wahlen mitten im Krieg? In der Ukraine galt das bislang als tabu. Ex-Verteidigungsminister Fedorow hat diese Forderung nun offen in den Raum gestellt und damit eine Debatte angestoßen. Kritiker sehen dahinter ein Kalkül. Von Florian Kellermann.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'ausland-europa',
                    	'8'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Inland (<?php 
		  echo '11';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'inland',
                    	'1',
                    	'20 Aug 2026 19:34:00',
                    	'https://www.tagesschau.de/inland/regional/nordrheinwestfalen/waldbrand-huertgenwald-110.html',
                    	'Nordrhein-Westfalen: Waldbrand in Hürtgenwald bei Aachen endgültig gelöscht',
                    	'Im Hürtgenwald bei Aachen haben Einsatzkräfte auch die letzten Feuer und Glutnester gelöscht. Der größte Waldbrand der Geschichte Nordrhein-Westfalens ist vorbei, etwa 300 Hektar Waldfläche haben gebrannt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'2',
                    	'20 Aug 2026 17:12:43',
                    	'https://www.tagesschau.de/inland/innenpolitik/hitze-gesundheit-bundesregierung-100.html',
                    	'Hitzetote in Deutschland: Warum Experten mehr Prävention fordern',
                    	'Mindestens 14.000 Menschen sind in diesem Jahr hitzebedingt zu Tode gekommen - mehr als in jedem einzelnen Gesamtjahr zuvor. Prävention hätte helfen können. Wie reagiert die Politik? Von Isabell Karras.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'3',
                    	'20 Aug 2026 17:11:19',
                    	'https://www.tagesschau.de/inland/innenpolitik/klimapolitik-bundesregierung-partzsch-100.html',
                    	'Kurs der Bundesregierung: "Klimapolitik von der Kür zur Pflicht machen"',
                    	'Die Wochen voller Hitze, Niedrigwasser und Waldbrände waren unübersehbar - auch für die Bundesregierung. Politikwissenschaftlerin Lena Partzsch erklärt, wie es um die deutsche Klimapolitik steht und welchen Stellenwert sie hat.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'4',
                    	'20 Aug 2026 14:49:48',
                    	'https://www.tagesschau.de/inland/regional/berlin/senatorin-badenberg-laesst-doktorarbeit-nach-plagiatsvorwuerfen-pruefen-100.html',
                    	'Plagiatsvorwürfe: Berliner Senatorin lässt ihre Doktorarbeit prüfen',
                    	'Die Doktorarbeit von Berlins Justizsenatorin Badenberg soll etwa 80 Plagiate beinhalten. Dem widerspricht die CDU-Politikerin. Sie bittet nun die Universität zu Köln um eine Prüfung ihrer Dissertation.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'5',
                    	'20 Aug 2026 14:22:24',
                    	'https://www.tagesschau.de/inland/statistik-behandlungsfehler-patienten-102.html',
                    	'Medizinischer Dienst: Mehr Todesfälle durch Behandlungsfehler',
                    	'In Deutschland wurden im vergangenen Jahr mehr als 3.000 medizinische Behandlungsfehler bestätigt. 97 von ihnen hatten tödliche Folgen, zeigt eine aktuelle Statistik. Doch die Dunkelziffer liegt vermutlich deutlich höher.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'6',
                    	'20 Aug 2026 14:14:11',
                    	'https://www.tagesschau.de/inland/innenpolitik/nord-stream-festnahme-politik-100.html',
                    	'Nord-Stream-Pipelines: Ein Anschlag mit politischer Sprengkraft?',
                    	'Zum zweiten Mal lässt die Bundesanwaltschaft einen mutmaßlich an den Nord-Stream-Anschlägen beteiligten Taucher festnehmen. Der Fall hat auch eine politische Dimension - wie sich in aktuellen Wahlkämpfen zeigt. Von Christina Nagel.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'7',
                    	'20 Aug 2026 13:13:00',
                    	'https://www.tagesschau.de/inland/regional/bremen/bremen-jva-ermittlungen-bestechlichkeit-100.html',
                    	'Razzia in Bremer Gefängnis - Beschäftigte bestechlich?',
                    	'Wegen des Verdachts der Bestechlichkeit sind mehrere Wohnungen sowie Zellen in einem Gefängnis in Bremen durchsucht worden. Ermittelt wird gegen 23 Verdächtige - unter ihnen sind auch mehrere JVA-Mitarbeiter. Sie sollen Häftlinge mit Drogen und Handys versorgt haben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'8',
                    	'20 Aug 2026 13:01:59',
                    	'https://www.tagesschau.de/inland/gesellschaft/anschlag-muenchen-1970-100.html',
                    	'Anschlag auf jüdisches Altenheim in München nach 56 Jahren offenbar aufgeklärt',
                    	'1970 starben bei einem Anschlag auf ein jüdisches Altenheim in München sieben Menschen. Die Fall konnte nicht aufgeklärt werden - bis jetzt: Die Ermittler sind davon überzeugt, dass ein damals 25-jähriger Neonazi das Feuer legte.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'9',
                    	'20 Aug 2026 11:25:24',
                    	'https://www.tagesschau.de/inland/hitze-todesfaelle-rki-100.html',
                    	'RKI meldet mehr als 14.000 Hitzetote seit Jahresbeginn',
                    	'Der heiße Sommer hat für Tausende Sterbefälle gesorgt. Laut einer neuen Schätzung des Robert Koch-Instituts sind seit Jahresbeginn mindestens 14.000 Menschen wegen der Hitze gestorben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'10',
                    	'20 Aug 2026 18:06:40',
                    	'https://www.tagesschau.de/inland/unwetter-deutschland-180.html',
                    	'Tote und Schäden nach heftigen Unwettern in Teilen Deutschlands',
                    	'Weggerissene Wände, abgedeckte Dächer, entwurzelte Bäume - heftige Unwetter haben schwere Schäden in mehreren Bundesländern angerichtet. Mindestens zwei Menschen kamen ums Leben. In Brandenburg und Hessen tobten Tornados.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'11',
                    	'20 Aug 2026 05:04:50',
                    	'https://www.tagesschau.de/inland/innenpolitik/ernaehrungssicherheit-landwirtschaft-100.html',
                    	'Ernährungssicherheit: Wie sinnvoll sind die Maßnahmen der Politik?',
                    	'Braucht es Agrarsubventionen, um die Lebensmittelversorgung in Europa zu sichern? Eine neue Studie des NABU stellt ein zentrales Argument von Bundeslandwirtschaftsminister Rainer infrage. Von Eva Huber.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'inland',
                    	'11'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Wirtschaft (<?php 
		  echo '7';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'1',
                    	'20 Aug 2026 19:04:25',
                    	'https://www.tagesschau.de/wirtschaft/finanzen/marktberichte/marktbericht-dax-dow-nikkei-staatsverschuldung-100.html',
                    	'Marktbericht: DAX-Schwäche hält an',
                    	'Der DAX ist heute weiter auf Talfahrt gegangen. Am Vormittag rutschte er unter die psychologisch wichtige Marke von 26.000 Punkten. Der Leitindex hat sich damit weiter von seinem Rekordhoch entfernt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'2',
                    	'20 Aug 2026 17:43:10',
                    	'https://www.tagesschau.de/wirtschaft/dgb-ausbildungsreport-106.html',
                    	'DGB-Ausbildungsreport: Jeder zweite Azubi ist psychisch belastet',
                    	'Finanzielle Sorgen, angespannter Wohnungsmarkt und Druck im Berufsleben: Immer mehr Auszubildenden macht das zu schaffen, so der aktuelle Ausbildungsreport des DGB. Der Gewerkschaftsbund sieht die Politik in der Pflicht. Von F. Siegel.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'3',
                    	'20 Aug 2026 14:34:28',
                    	'https://www.tagesschau.de/wirtschaft/finanzen/moderna-merck-impfstoff-hautkrebs-100.html',
                    	'Forschungserfolg treibt Aktien von Moderna & Co.',
                    	'Die beiden US-Pharma-Unternehmen Moderna und Merck haben möglicherweise einen Durchbruch bei einem potenziellen Impfstoff gegen schwarzen Hautkrebs erreicht. Das kommt bei Anlegern und Analysten gut an.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'4',
                    	'20 Aug 2026 12:58:31',
                    	'https://www.tagesschau.de/wirtschaft/verbraucher/immobilien-preise-babyboomer-angebot-100.html',
                    	'Viele Babyboomer übergeben in den kommenden Jahren ihr Eigenheim',
                    	'In den kommenden Jahrzehnten dürften zunehmend Häuser der Babyboomer-Generation auf den Markt kommen. Das zusätzliche Angebot könnte Immobilienpreise sinken lassen. Wo vor allem? Von Bianca von der Au.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'5',
                    	'20 Aug 2026 11:27:37',
                    	'https://www.tagesschau.de/wirtschaft/konjunktur/exporte-deutschland-china-100.html',
                    	'China bleibt Deutschlands Top-Handelspartner',
                    	'China bleibt weiterhin Deutschlands wichtigster Handelspartner. Allerdings wird der Handel immer unausgeglichener, denn die Importquote ist deutlich höher als die Exportrate.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'6',
                    	'20 Aug 2026 11:27:34',
                    	'https://www.tagesschau.de/wirtschaft/verbraucher/vermoegensungleichheit-deutschland-100.html',
                    	'Vermögensungleichheit leicht gesunken - bleibt auf hohem Niveau',
                    	'Die Vermögensungleichheit in Deutschland ist laut einer aktuellen Studie seit der Finanzkrise nicht größer geworden - sie ist sogar leicht gesunken. Trotzdem sind Vermögen hierzulande ungleich verteilt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'7',
                    	'20 Aug 2026 08:57:14',
                    	'https://www.tagesschau.de/wirtschaft/unternehmen/urteil-evergrande-insolvenz-xu-100.html',
                    	'Evergrande-Gründer Xu in China zu lebenslanger Haft verurteilt',
                    	'In China ist das Urteil gegen den Gründer des insolventen Immobilienkonzerns Evergrande gefallen: Xu Jiayin muss lebenslang in Haft. Ihm und weiteren ehemaligen Mitarbeitern wurden unter anderem Betrug und Korruption vorgeworfen.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'7'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sport (<?php 
		  echo '0';
		?>)
		</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sonstige (<?php 
		  echo '5';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'20 Aug 2026 21:43:06',
                    	'https://www.tagesschau.de/kommentar/ceuta-migranten-kommentar-100.html',
                    	'Umgang mit Migranten in Ceuta: Politische und humanitäre Bankrotterklärung',
                    	'Die meisten Migranten, die von Marokko aus in die spanische Exklave Ceuta gelangten, sind zurückgekehrt. Die Verbliebenen werden jetzt in Unterkünfte verlegt, Minderjährige aufs spanische Festland gebracht. Das sei zu wenig und komme zu spät, meint Franka Welz.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'20 Aug 2026 20:21:48',
                    	'https://www.tagesschau.de/kultur/ballett-staatstheater-saarbruecken-100.html',
                    	'Ballett: Tanzen unter Druck an deutschen Theatern',
                    	'Kurze Karrieren, hoher Konkurrenzdruck: Balletttänzer gehören zur verwundbarsten Gruppe an deutschen Theatern. Am Saarbrücker Staatstheater soll es zudem zu sexuellen Übergriffen gekommen sein. Von A. Kremer.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'20 Aug 2026 16:45:23',
                    	'https://www.tagesschau.de/wissen/gesundheit/u10-untersuchung-kinder-100.html',
                    	'Kinderärzte: Neue Untersuchung für Neun- bis Zehnjährige kommt',
                    	'Bei der Geburt eines Kindes erhalten Eltern ein gelbes Heft, das alle Vorsorgeuntersuchungen auflistet. Jetzt kommt noch die U10 hinzu, ein Check-up für Neun- bis Zehnjährige, der eine Lücke schließen soll. Von A. Braun und P. Kiss.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'20 Aug 2026 11:01:46',
                    	'https://www.tagesschau.de/wissen/klima/pik-studie-waldbraende-100.html',
                    	'Studie warnt vor deutlich mehr Waldbränden in Europa',
                    	'In Europa könnten künftig deutlich mehr Flächen brennen als bislang. Das zeigt eine Studie des Potsdam-Instituts für Klimafolgenforschung. Wie sehr das Risiko mit der Erderwärmung steigt - und was Brandmanagement leisten kann. Von S. Peyk.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'20 Aug 2026 08:45:33',
                    	'https://www.tagesschau.de/investigativ/swr/com-gruppen-bundesanwaltschaft-100.html',
                    	'Terrorismusverdacht: Bundesanwaltschaft ermittelt im Fall der "Com"-Gruppen',
                    	'Sicherheitsbehörden warnen vor Online-Netzwerken, in denen junge Täter Chatpartner zu Straftaten anstiften. Nach SWR-Informationen ermittelt nun in einem Fall die Bundesanwaltschaft: unter anderem wegen Terrorismus-Vorwürfen. Von E. Beres und P. Reichert.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'5'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div></div><div style="clear:both"></div></div><div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div></body></html>

