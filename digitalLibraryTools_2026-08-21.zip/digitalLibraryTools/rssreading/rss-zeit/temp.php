<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

  <html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta><meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>ZEIT Online | Schlagzeilen - rssreading</title><link rel="shortcut icon" href="../images/favicon/fav-zeit.ico"></link><link href="../css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="../js/unfold.js"></script><script type="text/javascript" src="../js/visitLink.js"></script><script type="text/javascript" src="../js/wndLocalStorage.js"></script><script type="text/javascript">
          </script><?php 
					include("../uc/header_imports_02.php");
				?><?php 
					include("../uc/articleItem.php");
				?><?php 
					include("../uc/articleLink.php");
				?><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Zeit");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="../rss-zeit/">
							  &gt; Alle Nachrichten (<?php 
								  echo '15';
								?>)</a></div></div><div class="divContent"><strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; DIE ZEIT | Nachrichten, News, Hintergründe und Debatten</strong><hr></hr><strong xmlns="">&gt; Wirtschaft (<?php 
		  echo '0';
		?>)
		</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Politik (<?php 
		  echo '3';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'politik',
                    	'1',
                    	'20 Aug 2026 21:19:25',
                    	'https://www.zeit.de/politik/ausland/2026-08/serbien-parlamentswahl-praesidentschaftswahl-aleksandar-vucic-proteste',
                    	'Serbien: Vučić kündigt vorgezogene Parlamentswahl in Serbien für Oktober an',
                    	'Nach monatelangen Protesten plant Serbiens Präsident Aleksandar Vučić, die Parlamentswahl vorzuziehen. An der Macht könnte er in anderer Rolle auch danach noch bleiben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'2',
                    	'20 Aug 2026 21:08:19',
                    	'https://www.zeit.de/politik/ausland/2026-08/norwegen-arktis-militaer-finnmark-brigade-russland',
                    	'Militär in der Arktis: Nato-Mitglied Norwegen rüstet Brigade nahe russischer Grenze auf',
                    	'Norwegen hat seine Militärpräsenz in der Arktis erhöht. Die Finnmark-Brigade im Grenzgebiet zu Russland erhielt mehr Artillerie sowie Flugabwehrbatterien.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'3',
                    	'20 Aug 2026 19:12:07',
                    	'https://www.zeit.de/politik/ausland/2026-08/afghanistan-unama-mitarbeiter-taliban-geheimdienst-herat',
                    	'Afghanistan: Taliban lassen zwei festgenommene UN-Mitarbeiter wieder frei',
                    	'Mehr als eine Woche nach ihrer Festnahme durch die Taliban befinden sich zwei afghanische UN-Mitarbeiter wieder auf freiem Fuß. Was ihnen vorgeworfen wurde, ist unklar.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'politik',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sport (<?php 
		  echo '0';
		?>)
		</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sonstige (<?php 
		  echo '12';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'20 Aug 2026 22:04:04',
                    	'https://www.zeit.de/news/2026-08/21/kritik-an-androhung-von-finanzsanktionen-fuer-sachsen-anhalt',
                    	'Vor Landtagswahl: Kritik an Androhung von Finanzsanktionen für Sachsen-Anhalt',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'20 Aug 2026 21:57:16',
                    	'https://www.zeit.de/news/2026-08/20/motorradfahrer-wird-schwer-verletzt',
                    	'Hubschraubereinsatz: Motorradfahrer wird schwer verletzt',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'20 Aug 2026 21:55:04',
                    	'https://www.zeit.de/news/2026-08/20/was-geschah-am-21-august',
                    	'Kalenderblatt: Was geschah am 21. August?',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'20 Aug 2026 21:45:41',
                    	'https://www.zeit.de/news/2026-08/20/lastwagenfahrer-mit-mehr-als-3-5-promille-auf-autobahn',
                    	'Kriminalität: Lastwagenfahrer mit mehr als 3,5 Promille auf Autobahn',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'20 Aug 2026 21:21:31',
                    	'https://www.zeit.de/news/2026-08/20/auto-prallt-gegen-baeume-fahrer-stirbt-noch-am-unfallort',
                    	'Unfallursache unklar: Auto prallt gegen Bäume – Fahrer stirbt noch am Unfallort',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'6',
                    	'20 Aug 2026 20:50:21',
                    	'https://www.zeit.de/news/2026-08/20/drei-menschen-bei-auffahrunfall-verletzt',
                    	'Karambolage: Drei Menschen bei Auffahrunfall verletzt',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'7',
                    	'20 Aug 2026 20:27:08',
                    	'https://www.zeit.de/news/2026-08/20/sc-freiburg-siegt-in-motherwell-ginter-trifft-doppelt',
                    	'Conference-League-Playoffs: SC Freiburg siegt in Motherwell – Ginter trifft doppelt',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'8',
                    	'20 Aug 2026 20:11:36',
                    	'https://www.zeit.de/news/2026-08/20/mann-wegen-versuchter-brandstiftung-festgenommen',
                    	'Polizei-Einsatz: Mann wegen versuchter Brandstiftung festgenommen',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'9',
                    	'20 Aug 2026 18:49:13',
                    	'https://www.zeit.de/gesellschaft/2026-08/jason-arday-cambridge-nathan-cofnas-plagiat-mobbing',
                    	'Cambridge-Professor Jason Arday: Uni suspendiert Mitarbeiter nach Plagiatsvorwurf gegen Jason Arday',
                    	'Der US-Forscher Nathan Cofnas hatte öffentlich Plagiatsvorwürfe gegen den Cambridge-Professor Jason Arday erhoben. Nun wurde Cofnas von seiner Universität suspendiert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'10',
                    	'20 Aug 2026 18:33:05',
                    	'https://www.zeit.de/familie/2026-08/kinderbetreuung-eltern-vertrauen-fremdbetreuung-gxe',
                    	'Kinderbetreuung: Wovor genau habt ihr Angst?',
                    	'Für Kinder ist es bereichernd, in andere Familien zu schauen, wenn sie alleine bei ihren Freunden sind. Doch Eltern sind heute so überbehütend, dass dies kaum vorkommt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'11',
                    	'20 Aug 2026 18:32:37',
                    	'https://www.zeit.de/zeit-magazin/unterhaltung/2026-08/harry-meghan-rueckkehr-grossbritannien-koenigsfamilie-charles',
                    	'Harry und Meghan: Sie sind wieder da',
                    	'In Kalifornien gescheitert, kehren Prinz Harry und Ehefrau Meghan nach England zurück. Als Entertainer wissen sie: Das Familiendrama braucht eine Fortsetzung.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'12',
                    	'20 Aug 2026 18:26:03',
                    	'https://www.zeit.de/wissenschaft/umwelt/2026-08/waldbrand-huertgenwald-eifel-nordrhein-westfalen-evakuierung',
                    	'NRW: Waldbrand im Hürtgenwald laut Bürgermeister gelöscht',
                    	'Der größte Waldbrand in der Geschichte Nordrhein-Westfalens hat ein Ende gefunden. Laut dem Bürgermeister sind die Flammen gelöscht und die Einsatzkräfte ziehen ab.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'12'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div></div><div style="clear:both"></div></div><div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div></body></html>

