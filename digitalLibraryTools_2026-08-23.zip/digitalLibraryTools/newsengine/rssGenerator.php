<?php
	$dom = new DOMDocument();
	
	$rss = $dom->createElement('rss');
	$rss->setAttribute("xmlns:atom", "http://www.w3.org/2005/Atom");
	$rss->setAttribute("version", "2.0");

	$channel = $dom->createElement('channel');
	
	$item = $dom->createElement('item');
	$title = $dom->createElement('title');
	$text = $dom->createTextNode('Text');
	$title->appendChild($text);
	$item->appendChild($title);
	$channel->appendChild($item);
	
	$item = $dom->createElement('item');
	$title = $dom->createElement('title');
	$text = $dom->createTextNode('Text');
	$title->appendChild($text);
	$item->appendChild($title);
	$channel->appendChild($item);
	
	$item = $dom->createElement('item');
	$title = $dom->createElement('title');
	$text = $dom->createTextNode('Text');
	$title->appendChild($text);
	$item->appendChild($title);
	$channel->appendChild($item);
	
	$item = $dom->createElement('item');
	$title = $dom->createElement('title');
	$text = $dom->createTextNode('Text');
	$title->appendChild($text);
	$item->appendChild($title);
	$channel->appendChild($item);
	
	$rss->appendChild($channel);
	$dom->appendChild($rss);
	
	file_put_contents("temp.xml", $dom->saveXML() );

	$xml = new DOMDocument();
	$xml->load("temp.xml");
	
	echo $xml->saveXML();
?>