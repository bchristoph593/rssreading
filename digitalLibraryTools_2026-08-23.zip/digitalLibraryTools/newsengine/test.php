<?php
	$portalName = "sport1";

	$cwd = getcwd();
	
	$rssFileName = "";
	
	if($rssFileName == "") {
	  if($portalName == "sport1") {
	    $url = "http://www.sport1.de/de_1/startseite/rss.xml";
	  }
	}

	$opts = array(
     	    'http' => array(
	        'user_agent' => 'Opera/9.80 (X11; Linux i686; U; en) Presto/2.8.131 Version/11.10',
 	    )
	);
	
	$context = stream_context_create($opts);
	libxml_set_streams_context($context);

	$content = file_get_contents($url, FALSE, $context);

	echo $content;
	@$uncompressed = gzinflate($content);  
	echo $uncompressed;

/*	
   	$xmlDoc = new DOMDocument();
   	$xmlDoc->loadXML( $content );
	
	echo $xmlDoc->saveXML();
*/
?>
