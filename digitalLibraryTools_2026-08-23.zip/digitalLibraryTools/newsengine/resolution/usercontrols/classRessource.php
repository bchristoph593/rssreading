<?php
	class WebRessource {
		var $ressourceURL;
		var $ressourcePortal 	= "";
		var $ressourceTitle 	= "";
		var $ressourceDate 		= "";
		var $ressourceTopic 	= "";
		var $ressourceSummary	= "";
		var $ressourceMediaType	= "";
		
		public function __construct() {}
		
		public function getUTF8String_2c($hex1, $hex2) {
			$str = utf8_encode( chr(hexdec($hex1)) );
			$str .= utf8_encode( chr(hexdec($hex2)) );
			
			return $str;
		}
		
		public function getUTF8String_3c($hex1, $hex2, $hex3) {
			$str = utf8_encode( chr(hexdec($hex1)) );
			$str .= utf8_encode( chr(hexdec($hex2)) );
			$str .= utf8_encode( chr(hexdec($hex3)) );
			
			return $str;
		}
		
		public function convertChars($element) {
			$element = str_replace("\"", "&quot;", $element);
			$element = str_replace("Ã¶", "&ouml;", $element);
			$element = str_replace("Ã¼", "&uuml;", $element);
			$element = str_replace( $this->getUTF8String_2c("C3", "A4"), "&auml;", $element);
			$element = str_replace( $this->getUTF8String_2c("C3", "84"), "&Auml;", $element);
			$element = str_replace( $this->getUTF8String_2c("C3", "9F"), "&szlig;", $element);
			$element = str_replace( $this->getUTF8String_3c("E2", "80", "9E"), "&#8222;", $element);
			$element = str_replace( $this->getUTF8String_3c("E2", "80", "9C"), "&#8220;", $element);
			
			return $element;
		}
		
		public function setURL($ressourceURL) {
			$this->ressourceURL = trim($ressourceURL);
		}
		
		public function setPortal($ressourcePortal) {
			$this->ressourcePortal = trim($ressourcePortal);
		}
		
		public function setTopic($element) {
			$element = $this->convertChars($element);
			$this->ressourceTopic = trim($element);
		}
		
		public function setTitle($element) {
			$element = $this->convertChars($element);
			$this->ressourceTitle = trim($element);
		}
		
		public function setDate($ressourceDate) {
			$this->ressourceDate = trim($ressourceDate);
		}
		
		public function setSummary($ressourceSummary) {
			$this->ressourceSummary = trim($ressourceSummary);
		}
		
		
		public function getURL() {
			return $this->ressourceURL;
		}
		
		public function getTitle() {
			return $this->ressourceTitle;
		}
		
		/*
		 *	Generate Html Section
		 */
		public function getHtmlRow($fieldKey, $fieldValue) {
			$html = '
				<div id="divRowMeta">
					<div style="float:left; width:170px;">
						<strong>'. $fieldKey .':</strong>
					</div>
					<div style="float:left;">
						'. $fieldValue .'
					</div>
					<div style="clear:both">&nbsp;</div>
				</div>
			';
			
			return $html;
		}
		
		public function getOutputBox() {
			$ressourceDate 		= $this->ressourceDate;
			$ressourceDate		= trim($ressourceDate);
			if($this->ressourceTopic != '') {
				$ressourceTitleFull	= $this->ressourceTopic. ": ". $this->ressourceTitle;
			} else {
				$ressourceTitleFull	= $this->ressourceTitle;
			}
			
			$htmlSection .= '
				<div id="divOutput" style="width:600px; border:0px solid black;">
					<div id="divRow" style="margin:3px;">
						<div style="float:left; width:170px;">
							<strong>Ressource-Date:</strong>
						</div>
						<div style="float:left;">
							<input id="txtRessourceDate" name="txtRessourceDate" value="'. $ressourceDate.'" size="60">
						</div>
						
						<div style="clear:both"></div>
					</div>
					<div id="divRow" style="margin:3px; background-color:#FFFFCC; ">
						<div style="float:left; width:170px;">
							<strong>Ressource-Name:</strong>
						</div>
						<div style="float:left; width:100px;">
							<input id="txtRessourceName" name="txtRessourceName" value="'. $ressourceTitleFull.'" size="60">
						</div>
					
						<div style="clear:both"></div>
					</div>
					<div id="divRow" style="margin:3px;">
						<div style="float:left; width:170px;">
							<strong>Bookmark Folder:</strong>
						</div>
						<div style="float:left; width:100px;">
							<select name="">
								<option>-- select a folder --</option>
								<option>Folder 1</option>
								<option>Folder 2</option>
								<option>Folder 3</option>
								<option>Folder 4</option>
								<option>Folder 5</option>
							</select>
						</div>
					
						<div style="clear:both"></div>
					</div>
					
				</div>
			';
			
			return $htmlSection;
		}
		
		public function getHtmlSection() {
			$htmlSection .= '<div style="width:850px;">';
			
			if($this->ressourceURL != "") {
				$htmlSection .= $this->getHtmlRow("Ressource-URL", 			$this->ressourceURL );
			}
			if($this->ressourcePortal != "") {
				$htmlSection .= $this->getHtmlRow("Ressource-Portal", 		$this->ressourcePortal );
			}
			if($this->ressourceMediaType != "") {
				$htmlSection .= $this->getHtmlRow("Ressource-MediaType", 	$this->ressourceMediaType );
			}
			if($this->ressourceTopic != "") {
				$htmlSection .= $this->getHtmlRow("Ressource-Topic", 		$this->ressourceTopic );
			}
			if($this->ressourceTitle != "") {
				$htmlSection .= $this->getHtmlRow("Ressource-Title", 		$this->ressourceTitle );
			}
			if($this->ressourceDate != "") {
				$htmlSection .= $this->getHtmlRow("Ressource-Date", 		$this->ressourceDate );
			}
			if($this->ressourceSummary != "") {
				$htmlSection .= $this->getHtmlRow("Ressource-Summary", 		$this->ressourceSummary );
			}
			
			$htmlSection .= '</div>';
			
			return $htmlSection;
		}
	}
?>
