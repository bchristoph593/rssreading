<?php
	function input_getSectionFormular() {
		$html = '
		';
		
		return $html;
	}
?>

<form id="form1" name="form1" method="post" action="">
    <div style="width:800px;">
        <div style="float:left; width:150px;">
        	<strong>URL:</strong>
	</div>
	<div style="float:left">
       		<input style="width:400px;" onkeyup="loadTitle()" name="txtInputURL" type="text" id="textfield" />
    	</div>
  	<div style="clear:both">
		&nbsp;
        </div>        
    </div>
</form>
