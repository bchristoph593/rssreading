<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class Sport1Wrapper extends AbstractWrapper {
		var $portalURL = "http://www.sport1.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			
			$content = $this->ressourceDoc->getElementById('newspage_content');
			if($content == null) {
				$article = $this->ressourceDoc->getElementById('links');
				$content = $this->getDivElementByClassName($article, 'modul artikel_content');
			}
			
			$head = $this->getDivElementByClassName($content, 'breadcrumb');
			$topicElement = $this->getElementByTagAndClassName($head, 'h4', 'font_11');
								
			$ressourceTopic = $topicElement->nodeValue;
			$ressourceTopic = preg_replace('/\//i', ' / ' ,$ressourceTopic);
			$ressourceTopic = preg_replace('/  /i', ' ' ,$ressourceTopic);
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$content = $this->ressourceDoc->getElementById('newspage_content');
			if($content == null) {
				$article = $this->ressourceDoc->getElementById('links');
				$content = $this->getDivElementByClassName($article, 'modul artikel_content');
			}
			
			$headlineElement = $this->getDivElementByClassName($content, 'headline');
			
			$ressourceTitle = $headlineElement->nodeValue;
						
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$content = $this->ressourceDoc->getElementById('newspage_content');
			if($content == null) {
				$article = $this->ressourceDoc->getElementById('links');
				$content = $this->getDivElementByClassName($article, 'modul artikel_content');
			}
			
			$head = $this->getDivElementByClassName($content, 'breadcrumb');
			$dateElement = $this->getElementByTagAndClassName($head, 'span', 'datum font_0');
			
			$ressourceDate = $dateElement->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
