<?php
	/* 
	 * imports for used class
	 */
	 
?>

<?php
	/*
	 * class implementation
	 */
	
	class SueddeutscheWrapper extends AbstractWrapper {
		var $portalURL = "http://www.sueddeutsche.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
						
		public function extractRessourceTopic() {
			
			$articleTitle = $this->ressourceDoc->getElementById('articleTitle');
			$ressourceTopic = $articleTitle->getElementsByTagName('strong')->item(0)->nodeValue;
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$articleTitle = $this->ressourceDoc->getElementById('articleTitle');
			$ressourceTitle = $articleTitle->lastChild->nodeValue;
						
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$article = $this->ressourceDoc->getElementById('wrapper');
			$headerDiv = $this->getDivElementByClassName($article, 'articleheader');
			$dateDiv = $this->getDivElementByClassName($headerDiv, 'header');
			$pDate = $this->getElementByTagAndClassName($dateDiv, 'p', 'updated');
						
			$ressourceDate = $pDate->firstChild->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
		/*	
			$spIntroTeaser = $this->ressourceDoc->getElementById('spIntroTeaser');
			@$ressourceSummary = $spIntroTeaser->getElementsByTagName('strong')->item(0)->nodeValue;
		*/
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
