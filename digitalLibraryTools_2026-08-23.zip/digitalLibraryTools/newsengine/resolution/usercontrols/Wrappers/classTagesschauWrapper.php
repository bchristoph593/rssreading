<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class TagesschauWrapper extends AbstractWrapper {
		var $portalURL = "http://www.tagesschau.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			
			$centerColumn = $this->ressourceDoc->getElementById('centerCol');
			$ressourceTopic = $centerColumn->getElementsByTagName('span')->item(0)->nodeValue;
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$centerColumn = $this->ressourceDoc->getElementById('centerCol');
			$ressourceTitle = $centerColumn->getElementsByTagName('h1')->item(0)->nodeValue;
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$centerColumn = $this->ressourceDoc->getElementById('centerCol');
			
			$i = 0;
			while($found == false) {
				$className = $centerColumn->getElementsByTagName('div')->item($i)->getAttribute("class");
				
				if($className == "standDatum") {
					$ressourceDate = $centerColumn->getElementsByTagName('div')->item($i)->nodeValue;
					$ressourceDate = substr($ressourceDate, 7, strlen($ressourceDate) - 7);
					$found = true;
				}
				$i++;
			}
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {

			$centerColumn = $this->ressourceDoc->getElementById('centerCol');
			
			$ressourceSummary = $centerColumn->getElementsByTagName('p')->item(0)->nodeValue;
			
//			$ressourceSummary = $centerColumn;
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>