<?php
	/* 
	 * imports for used class
	 */ 
?>

<?php
	/*
	 * class implementation
	 */
	
	class TagesspiegelWrapper extends AbstractWrapper {
		var $portalURL = "http://www.tagesspiegel.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
						
		public function extractRessourceTopic() {
			
			$article = $this->ressourceDoc->getElementById('hcf-wrapper');
			$topicElement = $this->getElementByTagAndClassName($article, 'em', 'hcf-overline');
			
			$ressourceTopic = $topicElement->nodeValue;
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$article = $this->ressourceDoc->getElementById('hcf-wrapper');
			$titleElement = $this->getElementByTagAndClassName($article, 'span', 'hcf-headline');
			
			$ressourceTitle = $titleElement->nodeValue;
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$article = $this->ressourceDoc->getElementById('hcf-wrapper');
			$dateContainer = $this->getDivElementByClassName($article, 'hcf-status');
			$dateElement = $this->getElementByTagAndClassName($dateContainer, 'span', 'hcf-date hcf-separate');
			
			$ressourceDate = $dateElement->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
