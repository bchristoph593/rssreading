<?php
	class AbstractWrapper extends DomHelper {
		/*
		 *	Setters
		 */
		public function setURL($ressourceURL) {
			$this->ressource->setURL( $ressourceURL );
			$this->ressource->setPortal( $this->portalURL );
		}
				
		/*
		 *	Getters
		 */
		public function getRessource() {
			return $this->ressource;
		}
		
		public function parseRessource() {
			$this->extractRessourceTopic();
			$this->extractRessourceTitle();
			$this->extractRessourceDate();
			$this->extractRessourceSummary();
		}
		
		/*
		 *	Processing
		 */
		public function fetchRessource() {
			$response = @file_get_contents($this->ressource->getURL() );
			
			if (! strpos($http_response_header[0], "200")) { 
			   print "page not found!";
			}
			
			$this->ressourceHtml = $response;
			
			$result = @$this->ressourceDoc->loadHTML($this->ressourceHtml);
		}
		
		public function getTopicFromCompoundHeadline($compound) {
			$pos = strpos($compound, ":");
			$topic = substr($compound, 0, $pos);
			
			return $topic;
		}
		
		public function getTitleFromCompoundHeadline($compound) {
			$pos = strpos($compound, ":");
			$title = substr($compound, $pos + 1, strlen($compound) - $pos );
			
			return $title;
		}
	}
?>