<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class GolemWrapper extends AbstractWrapper {
		var $portalURL = "http://www.golem.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			
			$article = $this->ressourceDoc->getElementById('screen');
			$header = $article->getElementsByTagName('header')->item(0);
			$ressourceTopic = $header->getElementsByTagName('span')->item(0)->nodeValue;
						
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$article = $this->ressourceDoc->getElementById('screen');
			$header = $article->getElementsByTagName('header')->item(0);
			$ressourceTitle = $header->getElementsByTagName('span')->item(1)->nodeValue;
						
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$article = $this->ressourceDoc->getElementById('screen');
			$dateDiv = $this->getDivElementByClassName($article, 'g g2');
						
			$listItems = $dateDiv->getElementsByTagName('li');
			foreach($listItems as $item) {
				if($item->getAttribute('class')=='text1') {
					$meta = $item->getElementsByTagName('strong')->item(0)->nodeValue;
					if($meta == 'Datum:') {
						$dateItem = $item;
						break;
					}
				}
			}
			
			$dateString = $dateItem->nodeValue;
			$pos = strpos($dateString, ":");
			
			$ressourceDate = trim(substr($dateString, $pos+1, strlen($dateString)-$pos));
			
			/*
			 * search /^(.)\./
			 * replace by $1
			 */
			$ressourceDate = preg_replace("/^([^\.])\./", "0$1.", $ressourceDate);
			
			/*
			 * search /\.([^\.])\./
			 * replace by $1
			 */
			$ressourceDate = preg_replace("/\.([^\.])\./", ".0$1.", $ressourceDate);
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
		/*	
			$spIntroTeaser = $this->ressourceDoc->getElementById('spIntroTeaser');
			@$ressourceSummary = $spIntroTeaser->getElementsByTagName('strong')->item(0)->nodeValue;
			
		*/
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
