<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class FAZWrapper extends AbstractWrapper {
		var $portalURL = "http://www.faz.net";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			
			$article = $this->ressourceDoc->getElementById('FAZContent');
			$header = $this->getDivElementByClassName($article, 'FAZArtikelEinleitung');
			$headLine = $header->getElementsByTagName('h1')->item(0);
			$topicElement = $this->getElementByTagAndClassName($headLine, 'span', 'Stichwort');
			$ressourceTopic = $topicElement->nodeValue;
									
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$article = $this->ressourceDoc->getElementById('FAZContent');
			$header = $this->getDivElementByClassName($article, 'FAZArtikelEinleitung');
			$ressourceTitle = $header->getElementsByTagName('h1')->item(0)->lastChild->nodeValue;
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$article = $this->ressourceDoc->getElementById('FAZContent');
			$dateElement = $this->getElementByTagAndClassName($article, 'span', 'Datum');
			$ressourceDate = $dateElement->firstChild->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
