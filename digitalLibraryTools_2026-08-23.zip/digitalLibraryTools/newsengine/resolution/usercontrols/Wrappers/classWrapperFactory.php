<?php
	/* 
	 * imports for used class
	 */
	
	include("../usercontrols/classRessource.php");
	
	include("../usercontrols/Wrappers/classDomHelper.php");
	include("../usercontrols/Wrappers/classAbstractWrapper.php");
	include("../usercontrols/Wrappers/classDefaultWrapper.php");
	include("../usercontrols/Wrappers/classSpiegelOnlineWrapper.php");
	include("../usercontrols/Wrappers/classSueddeutscheWrapper.php");
	include("../usercontrols/Wrappers/classGolemWrapper.php");
	include("../usercontrols/Wrappers/classFinancialTimesWrapper.php");
	include("../usercontrols/Wrappers/classHandelsblattWrapper.php");
	include("../usercontrols/Wrappers/classTagesschauWrapper.php");
	include("../usercontrols/Wrappers/classFocusOnlineWrapper.php");
	include("../usercontrols/Wrappers/classNTVWrapper.php");
	include("../usercontrols/Wrappers/classZeitWrapper.php");
	include("../usercontrols/Wrappers/classFAZWrapper.php");
	include("../usercontrols/Wrappers/classHeiseWrapper.php");
	include("../usercontrols/Wrappers/classSport1Wrapper.php");
	include("../usercontrols/Wrappers/classTagesspiegelWrapper.php");
	include("../usercontrols/Wrappers/classYoutubeWrapper.php");
	include("../usercontrols/Wrappers/classTUDarmstadtWrapper.php");
		
?>

<?php
	/*
	 * class implementation
	 */
	
	class WrapperFactory {
		
		function createWrapper($portalURL, $ressourceUrl) {
			if($portalURL == "www.spiegel.de") {
				return new SpiegelOnlineWrapper();
			}
			if($portalURL == "www.golem.de") {
				return new GolemWrapper();
			}
			if($portalURL == "www.ftd.de") {
				return new FinancialTimesWrapper();
			}
			if($portalURL == "www.sueddeutsche.de") {
				return new SueddeutscheWrapper();
			}
			if($portalURL == "www.handelsblatt.com") {
				return new HandelsblattWrapper();
			}
			if($portalURL == "www.tagesschau.de") {
				return new TagesschauWrapper();
			}
			/*
			if($portalURL == "www.focus.de") {
				return new FocusOnlineWrapper();
			}
			 */
			if($portalURL == "www.n-tv.de") {
				return new NTVWrapper();
			}
			if($portalURL == "www.zeit.de") {
				return new ZeitWrapper();
			}
			if($portalURL == "www.faz.net") {
				return new FAZWrapper();
			}
			if(($portalURL == "www.heise.de") 
				&& (preg_match("/\/newsticker\//", $ressourceUrl) > 0)
				) {
				return new HeiseWrapper();
			}
			if($portalURL == "www.sport1.de") {
				return new Sport1Wrapper();
			}
			if($portalURL == "www.tagesspiegel.de") {
				return new TagesspiegelWrapper();
			}
			if($portalURL == "www.youtube.com") {
				return new YoutubeWrapper();
			}
			if($portalURL == "www.tu-darmstadt.de") {
				return new TUDarmstadtWrapper();
			}
			
			return new DefaultWrapper();
		}
	}
?>
