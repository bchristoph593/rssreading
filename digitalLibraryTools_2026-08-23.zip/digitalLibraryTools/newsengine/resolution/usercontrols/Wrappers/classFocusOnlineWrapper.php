<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class FocusOnlineWrapper extends AbstractWrapper {
		var $portalURL = "http://www.focus.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
				
		public function extractRessourceTopic() {
			
			$article = $this->ressourceDoc->getElementById('area_ct_article');
			
			$i = 0;
			while($found == false) {
				$className = $article->getElementsByTagName('h1')->item($i)->getAttribute("class");
				
				if($className == "f-xxxl bld") {
					$headline = $article->getElementsByTagName('h1')->item($i)->nodeValue;
					$ressourceTopic = $this->getTopicFromCompoundHeadline($headline);
					$found = true;
				}
				$i++;
			}
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$article = $this->ressourceDoc->getElementById('area_ct_article');
			
			$i = 0;
			while($found == false) {
				$className = $article->getElementsByTagName('h1')->item($i)->getAttribute("class");
				
				if($className == "f-xxxl bld") {
					$headline = $article->getElementsByTagName('h1')->item($i)->nodeValue;
					$ressourceTitle = $this->getTitleFromCompoundHeadline($headline);
					$found = true;
				}
				$i++;
			}
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$article = $this->ressourceDoc->getElementById('area_ct_article');
			
			$i = 0;
			while($found == false) {
				$className = $article->getElementsByTagName('div')->item($i)->getAttribute("class");
				
				if($className == "float-l c-b") {
					$ressourceDate = $article->getElementsByTagName('div')->item($i)->nodeValue;
					$found = true;
				}
				$i++;
			}
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			
			$article = $this->ressourceDoc->getElementById('area_ct_article');
			
			$i = 0;
			while($found == false) {
				$className = $article->getElementsByTagName('div')->item($i)->getAttribute("class");
				
				if($className == "f-xl bld pd-t7") {
					$ressourceSummary = $article->getElementsByTagName('div')->item($i)->nodeValue;
					$found = true;
				}
				$i++;
			}
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>