<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class TUDarmstadtWrapper extends AbstractWrapper {
		var $portalURL = "http://www.tu-darmstadt.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			$article = $this->ressourceDoc->getElementById('newsdetailansicht');
			
			$header = $article->getElementsByTagName('hgroup')->item(0);
			$ressourceTopic = $header->getElementsByTagName('h1')->item(0)->nodeValue;
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			$article = $this->ressourceDoc->getElementById('newsdetailansicht');
			
			$header = $article->getElementsByTagName('hgroup')->item(0);
			$ressourceTitle = $header->getElementsByTagName('h2')->item(0)->nodeValue;
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			$article = $this->ressourceDoc->getElementById('newsdetailansicht');
			
			$header = $article->getElementsByTagName('header')->item(0);
			$ressourceDate = $header->getElementsByTagName('p')->item(0)->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			$ressourceSummary = "";
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>