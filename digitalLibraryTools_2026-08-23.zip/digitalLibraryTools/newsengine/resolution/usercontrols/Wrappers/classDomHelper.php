<?php
	/*
	 * helper class for DOM structures
	 */
	
	class DomHelper {
		public function getDivElementByClassName($node, $className) {
			$nodeList = $node->getElementsByTagName('div');
			foreach($nodeList as $nodeElement) {
				if($nodeElement->getAttribute('class')==$className) {
					$resultNode = $nodeElement;
					break;
				}
			}
			
			return $resultNode;
		}
		
		public function getElementByTagAndClassName($node, $tagName, $className) {
			$nodeList = $node->getElementsByTagName($tagName);
			foreach($nodeList as $nodeElement) {
				if($nodeElement->getAttribute('class')==$className) {
					$resultNode = $nodeElement;
					break;
				}
			}
			
			return $resultNode;
		}
	}
?>