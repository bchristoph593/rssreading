<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class NTVWrapper extends AbstractWrapper {
		var $portalURL = "http://www.n-tv.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			
			@$articleHead = $this->getElementByTagAndClassName($this->ressourceDoc, "h1", "articleH1");
			if($articleHead == NULL) {
				@$articleHead = $this->getElementByTagAndClassName($this->ressourceDoc, "h1", "articleTitle");
			}
			if($articleHead == NULL) {
				$articleHead = $this->ressourceDoc->getElementById("articleH1");
			}
						
			$headLine = $articleHead->nodeValue;
			$ressourceTopic = $this->getTopicFromCompoundHeadline($headLine);
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			@$articleHead = $this->getElementByTagAndClassName($this->ressourceDoc, "h1", "articleH1");
			if($articleHead == NULL) {
				@$articleHead = $this->getElementByTagAndClassName($this->ressourceDoc, "h1", "articleTitle");
			}
			if($articleHead == NULL) {
				$articleHead = $this->ressourceDoc->getElementById("articleH1");
			}
			
			$headLine = $articleHead->nodeValue;
			$ressourceTitle = $this->getTitleFromCompoundHeadline($headLine);
						
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$articleContent = $this->ressourceDoc;
			
			$i = 0;
			while($found == false) {
				$className = $articleContent->getElementsByTagName('p')->item($i)->getAttribute("class");
				
				if($className == "date") {
					$ressourceDate = $articleContent->getElementsByTagName('p')->item($i)->nodeValue;
					$found = true;
				}
				$i++;
			}
			
			$ressourceDate = preg_replace("/^[^ ]*, /", "", $ressourceDate);
			$ressourceDate = preg_replace("/Januar/", "01.", $ressourceDate);
			$ressourceDate = preg_replace("/Februar/", "02.", $ressourceDate);
			$ressourceDate = preg_replace("/März/", "03.", $ressourceDate);
			$ressourceDate = preg_replace("/MÃ¤rz/", "03.", $ressourceDate);
			$ressourceDate = preg_replace("/April/", "04.", $ressourceDate);
			$ressourceDate = preg_replace("/Mai/", "05.", $ressourceDate);
			$ressourceDate = preg_replace("/Juni/", "06.", $ressourceDate);
			$ressourceDate = preg_replace("/Juli/", "07.", $ressourceDate);
			$ressourceDate = preg_replace("/August/", "08.", $ressourceDate);
			$ressourceDate = preg_replace("/September/", "09.", $ressourceDate);
			$ressourceDate = preg_replace("/Oktober/", "10.", $ressourceDate);
			$ressourceDate = preg_replace("/November/", "11.", $ressourceDate);
			$ressourceDate = preg_replace("/Dezember/", "12.", $ressourceDate);
			$ressourceDate = preg_replace("/( )*/", "", $ressourceDate);
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			
			$articleContent = $this->ressourceDoc;
			
			$strongTagList = $articleContent->getElementsByTagName('strong');
			$size = $strongTagList->length;

			if($size > 0) {
				$i = 0;
				while( ($found == false) && ($i < $size) ) {
					$item = $strongTagList->item($i);
					$className = "";

					$className = $strongTagList->item($i)->getAttribute("class");
					
					if($className == "intro") {
						$ressourceSummary = $strongTagList->item($i)->nodeValue;
						$found = true;
					}
					$i++;
				}
			} else {
				$ressourceSummary = "";
				$found = true;
			}
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
