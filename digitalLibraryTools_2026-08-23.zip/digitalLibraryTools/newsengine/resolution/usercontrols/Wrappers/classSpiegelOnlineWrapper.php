<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class SpiegelOnlineWrapper extends AbstractWrapper {
		var $portalURL = "http://www.spiegel.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
				
		public function extractRessourceTopic() {
			
			$spArticleColumn = $this->ressourceDoc->getElementById('spArticleColumn');
			// $ressourceTopic = $spArticleColumn->getElementsByTagName('h1')->item(0)->nodeValue;
			
			$ressourceTopic = $this->getElementByTagAndClassName($spArticleColumn, "span", "spArticleTopicLine")->nodeValue;
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$spArticleColumn = $this->ressourceDoc->getElementById('spArticleColumn');
			// $ressourceTitle = $spArticleColumn->getElementsByTagName('h2')->item(0)->nodeValue;

			$ressourceTitle = $this->getElementByTagAndClassName($spArticleColumn, "span", "spArticleHeadLine")->nodeValue;
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$spShortDate = $this->ressourceDoc->getElementById('spShortDate');
			$ressourceDate = $spShortDate->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			
			$spIntroTeaser = $this->ressourceDoc->getElementById('spIntroTeaser');
			$ressourceSummary = $spIntroTeaser->getElementsByTagName('strong')->item(0)->nodeValue;
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>