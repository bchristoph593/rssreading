<?php
	/* 
	 * imports for used class
	 */
	 
?>

<?php
	/*
	 * class implementation
	 */
	 
	class HandelsblattWrapper extends AbstractWrapper {
		var $portalURL = "http://www.handelsblatt.com";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument;
		}
				
		public function extractRessourceTopic() {
			
			$contentWrapper = $this->ressourceDoc->getElementById('hcf-content-wrapper');
			$headerDiv = $this->getDivElementByClassName($contentWrapper, 'hcf-detail-header');
			$headerContent = $this->getDivElementByClassName($headerDiv, 'hcf-content');
			
			$headLine = $headerContent->getElementsByTagName('h1')->item(0)->nodeValue;
			$ressourceTopic = $this->getTopicFromCompoundHeadline($headLine);
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$contentWrapper = $this->ressourceDoc->getElementById('hcf-content-wrapper');
			$headerDiv = $this->getDivElementByClassName($contentWrapper, 'hcf-detail-header');
			$headerContent = $this->getDivElementByClassName($headerDiv, 'hcf-content');
			
			$headLine = $headerContent->getElementsByTagName('h1')->item(0)->nodeValue;
			$ressourceTitle = $this->getTitleFromCompoundHeadline($headLine);
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$contentWrapper = $this->ressourceDoc->getElementById('hcf-content-wrapper');
			$headerDiv = $this->getDivElementByClassName($contentWrapper, 'hcf-detail-header');
			$headerDate = $this->getDivElementByClassName($headerDiv, 'hcf-article-date');
			
			$ressourceDate = $headerDate->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			
			$ressourceSummary = 'summary';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>