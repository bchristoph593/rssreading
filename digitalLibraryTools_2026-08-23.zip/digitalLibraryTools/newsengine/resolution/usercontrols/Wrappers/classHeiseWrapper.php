<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class HeiseWrapper extends AbstractWrapper {
		var $portalURL = "http://www.heise.de/newsticker";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			
			$article = $this->ressourceDoc->getElementById('mitte_news');
			$header = $article->getElementsByTagName('h1')->item(0)->nodeValue;
			
			$ressourceTopic = $this->getTopicFromCompoundHeadline($header);
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$article = $this->ressourceDoc->getElementById('mitte_news');
			$header = $article->getElementsByTagName('h1')->item(0)->nodeValue;
			
			$ressourceTitle = $this->getTitleFromCompoundHeadline($header);
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$article = $this->ressourceDoc->getElementById('mitte_news');
			$dateElement = $this->getElementByTagAndClassName($article, 'p', 'news_datum');
			$ressourceDate = $dateElement->nodeValue;
						
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
