<?php
	/* 
	 * imports for used class
	 */
	 
?>

<?php
	/*
	 * class implementation
	 */
	
	class YoutubeWrapper extends AbstractWrapper {
		var $portalURL = "http://www.youtube.com";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
						
		public function extractRessourceTopic() {
			$ressourceTopic = "";
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$articleTitle = $this->ressourceDoc->getElementById('watch-headline-title');
			$ressourceTitle = $articleTitle->nodeValue;
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			$spanDate = $this->ressourceDoc->getElementById('eow-date');
			$ressourceDate = $spanDate->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
