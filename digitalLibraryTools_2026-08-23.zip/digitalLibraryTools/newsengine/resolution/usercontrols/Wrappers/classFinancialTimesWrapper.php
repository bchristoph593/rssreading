<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class FinancialTimesWrapper extends AbstractWrapper {
		var $portalURL = "http://www.ftd.de";
		
		var $ressource;
		var $ressourceDoc;
				
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
				
		public function extractRessourceTopic() {
			
			$content = $this->ressourceDoc->getElementById('BoxA-2-0-0');
			$introBoxDiv = $this->getDivElementByClassName($content, 'boxIntroHead');
			$part01 = $introBoxDiv->getElementsByTagName('h1')->item(0);
			
			$headline = $part01->nodeValue;
			$ressourceTopic = $this->getTopicFromCompoundHeadline($headline);
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$content = $this->ressourceDoc->getElementById('BoxA-2-0-0');
			$introBoxDiv = $this->getDivElementByClassName($content, 'boxIntroHead');
			$part01 = $introBoxDiv->getElementsByTagName('h1')->item(0);
			
			$headline = $part01->nodeValue;
			$ressourceTitle = $this->getTitleFromCompoundHeadline($headline);
			
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$contentBox = $this->ressourceDoc->getElementById('BoxA-2-0-0');
			$part01 = $contentBox->getElementsByTagName('div')->item(0);
			$part02 = $part01->getElementsByTagName('div')->item(0);
			$headFrame = $part02->getElementsByTagName('div')->item(1);
			$date = $this->getElementByTagAndClassName($part01, 'span', 'date');
			
			$ressourceDate = $date->nodeValue;
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
				
			$contentBox = $this->ressourceDoc->getElementById('BoxA-2-0-0');
			$part01 = $contentBox->getElementsByTagName('div')->item(0);
			$part02 = $part01->getElementsByTagName('div')->item(0);
			
			$ressourceSummary = $part02->getElementsByTagName('span')->item(5)->nodeValue;
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
