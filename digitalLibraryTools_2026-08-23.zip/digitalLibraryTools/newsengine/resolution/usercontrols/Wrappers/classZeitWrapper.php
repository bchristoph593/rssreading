<?php
	/* 
	 * imports for used class
	 */
?>

<?php
	/*
	 * class implementation
	 */
	
	class ZeitWrapper extends AbstractWrapper {
		var $portalURL = "http://www.zeit.de";
		
		var $ressource;
		var $ressourceDoc;
		
		public function __construct() {
			$this->ressource = new WebRessource();
			$this->ressourceDoc = new DOMDocument();
		}
		
		public function extractRessourceTopic() {
			
			$article = $this->ressourceDoc->getElementById('main');
			$header = $article->getElementsByTagName('h1')->item(0);
			$ressourceTopic = $header->getElementsByTagName('span')->item(0)->nodeValue;
			
			$this->ressource->setTopic( $ressourceTopic );
		}
		
		public function extractRessourceTitle() {
			
			$article = $this->ressourceDoc->getElementById('main');
			$header = $article->getElementsByTagName('h1')->item(0);
			$ressourceTitle = $header->getElementsByTagName('span')->item(1)->nodeValue;
						
			$this->ressource->setTitle( $ressourceTitle );
		}
		
		public function extractRessourceDate() {
			
			$sideBar = $this->ressourceDoc->getElementById('informatives');
									
			$listItems = $sideBar->getElementsByTagName('li');
			foreach($listItems as $item) {
				if($item->getAttribute('class')=='date') {
					$meta = $item->getElementsByTagName('strong')->item(0)->nodeValue;
					if($meta == 'Datum') {
						$dateItem = $item;
						break;
					}
				} else if($item->getAttribute('class')=='date first') {
					$meta = $item->getElementsByTagName('strong')->item(0)->nodeValue;
					if($meta == 'Datum') {
						$dateItem = $item;
						break;
					}
				}
			}
			
			$dateString = $dateItem->nodeValue;
			$pos = strpos($dateString, "Datum");
			
			$ressourceDate = substr($dateString, $pos+5, strlen($dateString)-$pos);
			
			$this->ressource->setDate( $ressourceDate );
		}
		
		public function extractRessourceSummary() {
		/*	
			$spIntroTeaser = $this->ressourceDoc->getElementById('spIntroTeaser');
			@$ressourceSummary = $spIntroTeaser->getElementsByTagName('strong')->item(0)->nodeValue;
			
		*/
			$ressourceSummary = '';
			
			$this->ressource->setSummary( $ressourceSummary );
		}
		
	}
?>
