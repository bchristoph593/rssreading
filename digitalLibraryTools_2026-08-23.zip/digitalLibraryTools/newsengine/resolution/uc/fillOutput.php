<?php
	/* 
	 * imports for used class
	 */
	
	include("../usercontrols/Wrappers/classWrapperFactory.php");
?>

<?php
	$ressource_url = $_GET["url"];
	
	$ressource_url = str_replace("AMP", "&", $ressource_url);
	
	/*
	 *	Process here:
	 *	- extract portal from url -> http://(.*)/
	 *	- create adapter related to portal
	 *
	 *	- adapter::setRessourceURL( url )
	 *	- adapter::fetchDocument()
	 *
	 *	- adapter::extractTitle()
	 *	- adapter::extractDate()
	 *	- adapter::extractTopic()
	 *
	 *	- WebRessource = adapter::getRessource()
	 */
	
	preg_match("|http://([^/]*)/|", $ressource_url, $matches);
	
	$portal = $matches[1];
	
	$factory = new WrapperFactory();
	$wrapper = $factory->createWrapper($portal, $ressource_url);
	
	$wrapper->setURL( $ressource_url );
	$wrapper->fetchRessource();
	
	$wrapper->parseRessource();
	
	$ressource = $wrapper->getRessource();
	
	echo $ressource->getOutputBox();
?>