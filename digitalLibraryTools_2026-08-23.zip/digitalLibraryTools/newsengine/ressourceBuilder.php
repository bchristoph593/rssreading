<?php
	$portalName = "";
	$sectionName = "";

	if(isset($_GET["portal"])) {
		$portalName = $_GET["portal"];
		// echo "portal known.". "<br />";
	}
	if(isset($_GET["section"])) {
		$sectionName = $_GET["section"];
		// echo "section known.". "<br />";
	}
	
	$cwd = getcwd();
	
	$xmlFileName = "";
	
	/*
	if($portalName == "spiegelonline") {
		$xmlFileName = "index.rss";
		
	} else if($portalName == "ftd") {
		$xmlFileName = "index.xml";
		
	} else if($portalName == "tagesschau") {
		$xmlFileName = "alle-meldungen.xml";
		
	} else if($portalName == "zeit") {
		$xmlFileName = "index_rss.xml";
	
	}
	*/
	
	// echo $sectionName."<br />";
	
	// BrowsingSession_xmlDataFile.xml
	if($sectionName == "browsingSession") {
		$xmlFileName = "BrowsingSession_xmlDataFile.xml";
		
		$sourceXmlFile = "http://localhost/digitalLibraryTools/knowledgeLibrary/BrowsingSession_xmlDataFile.xml";
		$targetXmlFile = $cwd."\\browsingSession\\".$xmlFileName;
		
		// echo $sourceXmlFile."<br>";
		// echo $targetXmlFile."<br>";
		
		$doc = new DOMDocument();
		$doc->load($sourceXmlFile);
		
		$bytesStored = $doc->save($targetXmlFile);
		
		// echo 'Wrote: ' . $bytesStored . ' bytes'. '<br>'; // Wrote: 72 bytes
		
	} else {
		$xmlFileName = "";
	}
	
	// echo $xmlFileName. "<br>";
	
	if($xmlFileName == "BrowsingSession_xmlDataFile.xml") {
		// $url = $cwd."/browsingSession/".$xmlFileName;
		$dataPath = $cwd."\\browsingSession\\".$xmlFileName;
		
		// echo $dataPath."<br />";
		
	} else if($xmlFileName != "") {
		$dataPath = $cwd."/rss-news/".$portalName."/".$sectionName."/".$xmlFileName;
		
	} else {
		if($portalName == "zeit") {
			$dataPath = "http://newsfeed.zeit.de/index";
			
	    } else if($portalName == "tagesschau") {
	    	$dataPath = "https://www.tagesschau.de/infoservices/alle-meldungen-100~rss2.xml";
	    	
	    } else if($portalName == "ntv") {
	    	$dataPath = "http://www.n-tv.de/rss";
			
	  	} else if($portalName == "sport1") {
	    	$dataPath = "http://www.sport1.de/de_1/startseite/rss.xml";
	    	
	    } else if($portalName == "faz") {
	    	$dataPath = "http://www.faz.net/aktuell/?rssview=1";
			
	    } else if($portalName == "golem") {
	    	$dataPath = "http://golem.de.dynamic.feedsportal.com/pf/578068/http://rss.golem.de/rss.php?feed=RSS2.0";
	    	
	    }
			
/*	    	
	    } else if($portalName == "sueddeutsche") {
	    	$dataPath = "http://rssfeed.sueddeutsche.de/c/795/f/447925/index.rss";
		}
*/
			
	}

/*
	$opts = array(
     	    'http' => array(
	        'user_agent' => 'Opera/9.80 (X11; Linux i686; U; en) Presto/2.8.131 Version/11.10',
 	    )
	);
	
	$context = stream_context_create($opts);
	libxml_set_streams_context($context);
*/

//	$content = file_get_contents($url, false, $context);

	// echo "load xml doc: ". $url. "<br>";

	$xmlDoc = new DOMDocument();
	$xmlDoc->load( $dataPath );
	
//	$xmlDoc->loadXML($content);
	
	echo $xmlDoc->saveXML();
?>
