<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
  <meta name="ROBOTS" content="All"></meta>
  <meta name="revisit-after" content="2 days"></meta>
  <title>RSS Spiegel Online | Schlagzeilen</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head>

<body>
  <script type="text/javascript" src="/js/unfold.js"></script>
  <script type="text/javascript" src="/js/visitLink.js"></script>
  
  <div class="divContainer"><div style="display:block;"> | <a href="/rss-tagesschau/">Tagesschau</a> | <strong>SpiegelOnline</strong> | <a href="/rss-zeit/">Zeit</a> | <a href="/rss-sport1/">Sport1</a> | <a href="/rss-financialtimes/">FinancialTimes</a> | <a href="/rss-handelsblatt/">Handelsblatt</a>
<hr><br>
</div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a></div></div><div class="divContent"><strong>
                            RSS Newsletter: SPIEGEL ONLINE - Schlagzeilen</strong><br></br><hr></hr><strong xmlns="">&gt; Wirtschaft</strong><div xmlns="" class="divLinkSection">

			<div id="divContainer_wirtschaft_1">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 19:25:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_1_img' 
                		src="images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/wirtschaft/soziales/0,1518,761266,00.html#ref=rss" onclick="javascript:visit('wirtschaft_1');">
				Debatte &uuml;ber W&auml;hrungsunion: Top-&Ouml;konom fordert Euro-Aus f&uuml;r Griechenland
			</a>
		
						
			<div class="divArticleSummary" id="summary_1">
				Die Euro-Finanzminister wiegeln nach Kr&auml;ften ab, doch die Diskussion &uuml;ber einen Verbleib Griechenlands in der W&auml;hrungsunion ebbt nicht ab. Ifo-Pr&auml;sident Hans-Werner Sinn erneuert jetzt seine Forderung: Das hochverschuldete Land soll raus aus der W&auml;hrungsunion - im eigenen Interesse.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		<div style="display:none" id="divContainerVisited_wirtschaft">
			<div style="width:140px; display:block">
				<hr />
            </div>
		
				<div id="divContainerVisited_wirtschaft_1">
				</div>
			</div></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Politik</strong><div xmlns="" class="divLinkSection">

			<div id="divContainer_politik_1">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 23:16:49</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_1_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,761280,00.html#ref=rss" onclick="javascript:visit('politik_1');">
				Proteste in Hauptstadt: Tunesiens Regierung verh&auml;ngt Ausgangssperre
			</a>
		
						
			<div class="divArticleSummary" id="summary_1">
				In Tunesien gl&uuml;ckte der Despotensturz - doch zurzeit herrscht alles andere als Freude im Land. Die &Uuml;bergangsregierung geht hart gegen Proteste vor und verh&auml;ngt nun�eine Ausgangssperre &uuml;ber Tunis. Den libyschen Machthaber Gaddafi warnte sie, weiter Grenzorte zu beschie&szlig;en.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_2">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 22:13:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_2_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/deutschland/0,1518,761279,00.html#ref=rss" onclick="javascript:visit('politik_2');">
				Baden-W&uuml;rttemberg: Gr&uuml;ne und SPD billigen Koalitionsvertrag
			</a>
		
						
			<div class="divArticleSummary" id="summary_2">
				Es gab nicht eine einzige Ablehnung: Auf Sonderparteitagen haben SPD und Gr&uuml;ne in Baden-W&uuml;rttemberg ihren Koalitionsvertrag angenommen. Auch in der Aussprache gab es kaum Kritik an der Vereinbarung - stattdessen eindringliche Appelle zur Geschlossenheit.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_3">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 21:20:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_3_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,761272,00.html#ref=rss" onclick="javascript:visit('politik_3');">
				Bin Ladens Leben in Pakistan: Terrorf&uuml;rst, ganz privat
			</a>
		
						
			<div class="divArticleSummary" id="summary_3">
				Homestory aus dem Haus des Terrors: Der US-Geheimdienst hat�Videos von Osama Bin Ladens Leben�in Pakistan ver&ouml;ffentlicht. Sie stammen aus dessen eigenem Besitz - und zeigen einen alten Mann, der in sich selbst verliebt scheint. Was verraten die Bilder &uuml;ber die�Organisationsstruktur der Qaida?
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_4">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 18:23:16</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_4_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/deutschland/0,1518,761261,00.html#ref=rss" onclick="javascript:visit('politik_4');">
				FDP-Parteitag in Stuttgart: Homburger gewinnt - und verliert&nbsp;trotzdem
			</a>
		
						
			<div class="divArticleSummary" id="summary_4">
				Mit knappem Vorsprung hat Birgit Homburger ihre Stellung in der baden-w&uuml;rttembergischen FDP verteidigt. Sie brauchte allerdings zwei Anl&auml;ufe, um sich gegen ihren Widersacher�durchzusetzen, den Europaparlamentarier Michael Theurer. Ihre Zukunft in der Bundespolitik ist denkbar ungewiss.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_5">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 17:04:28</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_5_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,749915,00.html#ref=rss" onclick="javascript:visit('politik_5');">
				Waffenhandel in Beirut: Der Preis f&uuml;r den Tod steigt auf 1200 Dollar
			</a>
		
						
			<div class="divArticleSummary" id="summary_5">
				Sein Gesch&auml;ft ist der Tod, und es l&auml;uft bestens - Rami ist in Beirut ein�gefragter� Mann. Bei ihm decken sich vor allem Hisbollah-Anh&auml;nger ein. Die Nachfrage ist enorm, sagt der Waffenh&auml;ndler: "Die Libanesen bereiten sich auf den Showdown nach dem Hariri-Tribunal vor."
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_6">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 16:59:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_6_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,758236,00.html#ref=rss" onclick="javascript:visit('politik_6');">
				Umerziehungslager in Pakistan: Einmal Talib und zur&uuml;ck
			</a>
		
						
			<div class="divArticleSummary" id="summary_6">
				Die Taliban haben das Swat-Tal terrorisiert, Tausende unterst&uuml;tzten sie - freiwillig oder gezwungen. Nach dem Sieg &uuml;ber die Extremisten will die Armee jetzt Mitl&auml;ufer resozialisieren. In "De-Radikalisierungszentren" lernen sie, dass man ein guter Muslim sein kann, ohne Andersgl&auml;ubige zu t&ouml;ten. 
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_7">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 16:48:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_7_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,761257,00.html#ref=rss" onclick="javascript:visit('politik_7');">
				K&uuml;hlaggregat-Panne in Brasilien: Pr&auml;sidenten-Airbus streikt - Wulffs fliegen Linie
			</a>
		
						
			<div class="divArticleSummary" id="summary_7">
				Bundespr&auml;sident Christian Wulff hat seine Lateinamerikareise unfreiwillig verl&auml;ngern m&uuml;ssen. Der Pr&auml;sidenten-Airbus 310 konnte in S�o Paulo wegen einer technischen Panne nicht zum R&uuml;ckflug nach Berlin starten. Wulff und seine Frau stiegen auf einen Linienflieger um.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_8">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 16:23:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_8_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,761256,00.html#ref=rss" onclick="javascript:visit('politik_8');">
				Aufstand in Syrien: Assads Truppen st&uuml;rmen Hochburg der Proteste
			</a>
		
						
			<div class="divArticleSummary" id="summary_8">
				Sie verlangen freie Wahlen, aber nicht den sofortigen R&uuml;cktritt von Machthaber Assad: Erstmals hat die syrische Opposition einen konkreten Forderungskatalog formuliert. Der Diktator reagiert auf seine Weise - er schickt Panzer in die Stadt Banias, Menschenrechtler berichten von mehreren Toten.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_9">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 15:49:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_9_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,761250,00.html#ref=rss" onclick="javascript:visit('politik_9');">
				Luftangriff: Gaddafis Armee zerbombt &Ouml;lvorr&auml;te von Misurata
			</a>
		
						
			<div class="divArticleSummary" id="summary_9">
				Die libysche Armee hat nach Angaben von Aufst&auml;ndischen mehrere &Ouml;ltanks in der besetzten Stadt Misurata beschossen. Die Speicher gingen in Flammen auf, das Feuer ist noch nicht unter Kontrolle. Auch im Grenzgebiet�wird wieder heftig gek&auml;mpft - Granaten schlugen im Nachbarland Tunesien ein. 
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_politik_10">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 14:50:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_10_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/politik/ausland/0,1518,761245,00.html#ref=rss" onclick="javascript:visit('politik_10');">
				K&auml;mpfe in Kandahar: Taliban nehmen Regierungsviertel unter Dauerbeschuss
			</a>
		
						
			<div class="divArticleSummary" id="summary_10">
				K&auml;mpfer der Taliban haben�mehrere Regierungsgeb&auml;ude in der s&uuml;dafghanischen Stadt Kandahar angegriffen - sie attackierten den Wohnsitz des Provinzgouverneurs, das Rathaus und B&uuml;ros des Geheimdienstes. Die Extremisten verschanzten sich in einem Einkaufszentrum und er&ouml;ffneten das Feuer. 
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		<div style="display:none" id="divContainerVisited_politik">
			<div style="width:140px; display:block">
				<hr />
            </div>
		
				<div id="divContainerVisited_politik_1">
				</div>
			
				<div id="divContainerVisited_politik_2">
				</div>
			
				<div id="divContainerVisited_politik_3">
				</div>
			
				<div id="divContainerVisited_politik_4">
				</div>
			
				<div id="divContainerVisited_politik_5">
				</div>
			
				<div id="divContainerVisited_politik_6">
				</div>
			
				<div id="divContainerVisited_politik_7">
				</div>
			
				<div id="divContainerVisited_politik_8">
				</div>
			
				<div id="divContainerVisited_politik_9">
				</div>
			
				<div id="divContainerVisited_politik_10">
				</div>
			</div></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Netzwelt</strong><div xmlns="" class="divLinkSection">

			<div id="divContainer_netzwelt_1">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 17:23:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_1_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/netzwelt/gadgets/0,1518,761254,00.html#ref=rss" onclick="javascript:visit('netzwelt_1');">
				Paperphones: So d&uuml;nn sind die Handys&nbsp;von &uuml;bermorgen
			</a>
		
						
			<div class="divArticleSummary" id="summary_1">
				Der Bildschirm ist gr&ouml;&szlig;er als beim iPhone, doch das Ger&auml;t ist d&uuml;nn wie ein paar Blatt Papier: Forscher einer kanadischen Universit&auml;t haben den Prototyp eines�solchen Zukunftshandys gebaut. Sie sind sich sicher, dass derartige Mobiltelefone in wenigen Jahren auf den Markt kommen.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		<div style="display:none" id="divContainerVisited_netzwelt">
			<div style="width:140px; display:block">
				<hr />
            </div>
		
				<div id="divContainerVisited_netzwelt_1">
				</div>
			</div></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Unispiegel</strong><div xmlns="" class="divLinkSection"><div style="display:none" id="divContainerVisited_unispiegel">
			<div style="width:140px; display:block">
				<hr />
            </div>
		</div></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport</strong><div xmlns="" class="divLinkSection">

			<div id="divContainer_sport_1">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 23:28:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_1_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/fussball/0,1518,761274,00.html#ref=rss" onclick="javascript:visit('sport_1');">
				Internationaler Fu&szlig;ball: Milan feiert die italienische Meisterschaft
			</a>
		
						
			<div class="divArticleSummary" id="summary_1">
				Der Titelkampf in der Serie A ist entschieden: Der AC Milan hat Stadtrivalen Inter entthront. Siena und Atalanta Bergamo schafften den Aufstieg in die erste italienische Liga. Real schoss gegen Sevilla sechs�Tore.�Au&szlig;erdem: Thomas Hitzlsperger hat in der Premier League ein wichtiges Tor erzielt.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_2">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 22:13:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_2_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/fussball/0,1518,761273,00.html#ref=rss" onclick="javascript:visit('sport_2');">
				Eintracht Frankfurt: Elend auf dem Platz, Hass auf der Trib&uuml;ne
			</a>
		
						
			<div class="divArticleSummary" id="summary_2">
				Erst blamiert sich das Frankfurter Team�im Heimspiel gegen K&ouml;ln. Dann st&uuml;rmen Dutzende Eintracht-Fans den Platz, eine Hundertschaft Polizisten muss eingreifen.�Dem Verein droht trotz starker Hinrunde der Absturz in die Zweite Liga - selbst Trainer Daum hat kaum noch Hoffnung.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_3">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 21:45:51</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_3_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/sonst/0,1518,761276,00.html#ref=rss" onclick="javascript:visit('sport_3');">
				Basketball-Playoffs: Braunschweig legt vor, Alba schw&auml;chelt
			</a>
		
						
			<div class="divArticleSummary" id="summary_3">
				Die Phantoms Braunschweig haben den zweiten Playoffsieg gegen die Artland Dragons eingefahren und�stehen nun vor dem Einzug ins Halbfinale. Berlin ben&ouml;tigt ebenfalls nur noch einen Sieg, doch Spiel drei�gegen Oldenburg�ging verloren.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_4">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 19:47:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_4_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/fussball/0,1518,761269,00.html#ref=rss" onclick="javascript:visit('sport_4');">
				Abstieg des FC St. Pauli: 1:8 Tore, 18. Platz
			</a>
		
						
			<div class="divArticleSummary" id="summary_4">
				Der FC St. Pauli ist am Tiefpunkt der Saison angekommen: Debakel gegen den FC Bayern, letzter Tabellenplatz, Abstieg - und das alles beim letzten Heimspiel von Trainer Holger Stanislawski. Der Abschied wurde ihm gr&uuml;ndlich versaut.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_5">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 19:12:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_5_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/wintersport/0,1518,761264,00.html#ref=rss" onclick="javascript:visit('sport_5');">
				Eishockey-WM: Deutschland verliert gegen D&auml;nemark
			</a>
		
						
			<div class="divArticleSummary" id="summary_5">
				Zweite Niederlage in Folge f&uuml;r das DEB-Team: Wie schon am Freitag verlor die Mannschaft von Trainer Uwe Krupp auch gegen D&auml;nemark im Penaltyschie&szlig;en. Damit droht Deutschland in der K.o.-Runde das Aufeinandertreffen mit einem der Top-Favoriten.��
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_6">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 18:56:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_6_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/sonst/0,1518,761259,00.html#ref=rss" onclick="javascript:visit('sport_6');">
				Handball-Pokal: THW Kiel trifft im Finale&nbsp;auf Flensburg
			</a>
		
						
			<div class="divArticleSummary" id="summary_6">
				Das Endspiel steht: Der THW Kiel und die SG Flensburg-Handewitt�k&auml;mpfen am Sonntag um den Handball-Pokalsieg. F&uuml;r�den Rekordmeister�ist es die letzte Chance auf einen Titel. 
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_7">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 17:23:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_7_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/fussball/0,1518,761252,00.html#ref=rss" onclick="javascript:visit('sport_7');">
				Fu&szlig;ball: Bayern in der Champions League, St. Pauli in der Zweiten Liga
			</a>
		
						
			<div class="divArticleSummary" id="summary_7">
				Am 33. Spieltag hat sich der Abstiegskampf dramatisch zugespitzt. Lediglich der FC St. Pauli ist nach einem Debakel gegen M&uuml;nchen�bereits sicher abgestiegen. Weil Hannover gleichzeitig gegen Stuttgart�verlor, ist Bayern sicher in der�Champions-League-Qualifikation.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_8">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 16:11:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_8_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/sonst/0,1518,761242,00.html#ref=rss" onclick="javascript:visit('sport_8');">
				Mixed Zone: G&ouml;rges scheitert im Halbfinale, Nadal bezwingt Federer
			</a>
		
						
			<div class="divArticleSummary" id="summary_8">
				Niederlage in Spiel zehn: Wiktoria Asarenka hat beim Tennisturnier in Madrid die Siegesserie von Julia G&ouml;rges beendet.�Rafael Nadal hingegen zog nach einem Sieg gegen Roger Federer ins Finale ein. In Shanghai schafften es zwei deutsche Beachvolleyballer aufs Podest.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sport_9">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 15:11:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_9_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/sport/sonst/0,1518,761249,00.html#ref=rss" onclick="javascript:visit('sport_9');">
				NBA-Playoffs: Dallas f&uuml;hrt Meister LA Lakers vor
			</a>
		
						
			<div class="divArticleSummary" id="summary_9">
				Die Dallas Mavericks sind nicht zu stoppen. In der Playoffs-Serie gegen Titelverteidiger Los Angeles Lakers gewann das Team von Dirk Nowitzki auch die dritte Partie. Nun fehlt nur noch ein Erfolg, um die Sensation zu schaffen.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		<div style="display:none" id="divContainerVisited_sport">
			<div style="width:140px; display:block">
				<hr />
            </div>
		
				<div id="divContainerVisited_sport_1">
				</div>
			
				<div id="divContainerVisited_sport_2">
				</div>
			
				<div id="divContainerVisited_sport_3">
				</div>
			
				<div id="divContainerVisited_sport_4">
				</div>
			
				<div id="divContainerVisited_sport_5">
				</div>
			
				<div id="divContainerVisited_sport_6">
				</div>
			
				<div id="divContainerVisited_sport_7">
				</div>
			
				<div id="divContainerVisited_sport_8">
				</div>
			
				<div id="divContainerVisited_sport_9">
				</div>
			</div></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Wissenschaft</strong><div xmlns="" class="divLinkSection"><div style="display:none" id="divContainerVisited_wissenschaft">
			<div style="width:140px; display:block">
				<hr />
            </div>
		</div></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">

			<div id="divContainer_sonstige_1">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 20:13:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_1_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/panorama/0,1518,761270,00.html#ref=rss" onclick="javascript:visit('sonstige_1');">
				Wochenend-Wetter: Sonne, Sonne, Sonne
			</a>
		
						
			<div class="divArticleSummary" id="summary_1">
				Sein Name ist Uta. Hoch Uta. Es beschert den Menschen in Deutschland Traumwetter - und sie himmeln es daf&uuml;r an.�Tief Norbert ist zwar schon im Anmarsch, aber erst einmal hei&szlig;t es: Der Mai ist da!
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_2">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 19:58:58</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_2_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/kultur/gesellschaft/0,1518,761268,00.html#ref=rss" onclick="javascript:visit('sonstige_2');">
				Augenblick: Kulturterror
			</a>
		
						
			<div class="divArticleSummary" id="summary_2">
				
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_3">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 19:56:21</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_3_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/kultur/kino/0,1518,761258,00.html#ref=rss" onclick="javascript:visit('sonstige_3');">
				Panahi-Film in Cannes: Spezialvorf&uuml;hrung gegen Hausarrest
			</a>
		
						
			<div class="divArticleSummary" id="summary_3">
				Eingesperrt - und trotzdem im Kino pr&auml;sent: Bei den Filmfestspielen von Cannes, die am 11. Mai starten,�wird in einer Spezialvorf&uuml;hrung der neue Film des�gefeierten und verfolgten iranischen Regisseur Jafar Panahi gezeigt.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_4">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 18:58:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_4_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/panorama/leute/0,1518,761260,00.html#ref=rss" onclick="javascript:visit('sonstige_4');">
				Bin Ladens Judo-Vergangenheit: Gotteskrieger mit Schwarzem G&uuml;rtel
			</a>
		
						
			<div class="divArticleSummary" id="summary_4">
				So friedfertig hat man Osama Bin Laden nie gesehen: Bilder aus den fr&uuml;hen achtziger Jahren zeigen�einen jungen Mann, der dem�sp&auml;teren Terroristen sehr &auml;hnlich sieht, im saudi-arabischen Judo-Team. Die Nachrichtenagentur Reuters verbreitet die Aufnahmen, ihre Echtheit konnte bislang�nicht &uuml;berpr&uuml;ft werden.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_5">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 18:14:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_5_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/fotostrecke/fotostrecke-67741.html#ref=rss" onclick="javascript:visit('sonstige_5');">
				33. Spieltag: Bayern blamieren St. Pauli, Hanke wird zum Held
			</a>
		
						
			<div class="divArticleSummary" id="summary_5">
				Was f&uuml;r ein bitterer Abschied f&uuml;r Holger Stanislawski: Der Trainer des FC St. Pauli kassierte mit seinem Team eine 1:8-Heimniederlage gegen Bayern. Stuttgart feierte einen Sieg gegen Hannover, Gladbach k&ouml;nnte sensationell doch noch den Klassenerhalt schaffen.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_6">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 18:00:29</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_6_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/panorama/justiz/0,1518,761246,00.html#ref=rss" onclick="javascript:visit('sonstige_6');">
				Auf der Flucht: Polizei fahndet nach Taxim&ouml;rder vom Bodensee
			</a>
		
						
			<div class="divArticleSummary" id="summary_6">
				Der "Taxim&ouml;rder vom Bodensee" ist aus der geschlossenen Psychiatrie entkommen: Die Polizei hat eine Gro&szlig;fahndung nach Andrej W. eingeleitet. Nach einem Hofgang ist er spurlos verschwunden. Vorsichtshalber warnten die Beh&ouml;rden Autofahrer im Gro&szlig;raum Karlsruhe davor, Anhalter mitzunehmen.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_7">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 16:36:09</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_7_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/kultur/tv/0,1518,760897,00.html#ref=rss" onclick="javascript:visit('sonstige_7');">
				Holocaust-Drama in der ARD: Ein Leben mit Buchenwald
			</a>
		
						
			<div class="divArticleSummary" id="summary_7">
				"Wie sollen wir erz&auml;hlen?" Ruhig, klug und eindringlich portr&auml;tiert die franz&ouml;sische TV-Produktion "Die Zeit der Stille" einen KZ-&Uuml;berlebenden, der versucht, eine Sprache f&uuml;r die Gr&auml;uel zu finden.�Ein Ausnahmefilm: Hinter�der�Historie�werden die Verletzungen in den Seelen der Opfer gezeigt.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_8">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 16:21:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_8_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/panorama/leute/0,1518,761248,00.html#ref=rss" onclick="javascript:visit('sonstige_8');">
				Stress bei &quot;DSDS&quot;: Und tsch&uuml;s!
			</a>
		
						
			<div class="divArticleSummary" id="summary_8">
				Schleudersitz Castingshow: Kurz vor dem Finale von "Deutschland sucht den Superstar"�k&uuml;ndigt Dieter Bohlen an, die Jury�f&uuml;rs n&auml;chste Jahr�auszuwechseln. Moderator Marco Schreyl will offenbar solchen Ad-hoc-Entscheidungen vorbeugen und denkt schon mal &uuml;ber seinen Abschied nach.
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		
			<div id="divContainer_sonstige_9">
				<div class="divArticleItem">
					<div class="divArticleDate">07 May 2011 16:14:00</div>
					<div class="divShowSummary">
			<a onclick="">
            	<img id='summary_9_img' 
                		src="/images/arrow-right.png"
				/>
            </a>
		</div>
					<div class="divArticleLink">
						
			<a target="_blank" href="http://www.betodate.de/show.php?ref=http://www.spiegel.de/panorama/0,1518,761253,00.html#ref=rss" onclick="javascript:visit('sonstige_9');">
				Bundesweiter Bahn-Flashmob: Gruppenreigen am Gleisbett
			</a>
		
						
			<div class="divArticleSummary" id="summary_9">
				Der Zug kommt, die Choreo sitzt:�Freunde der kollektiven K&ouml;rperbewegung haben sich auf mehreren deutschen Bahnh&ouml;fen zu einem�Flashmob zusammengefunden. In Hamburg�tanzten 200 Leute. 
			</div>
		
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
		<div style="display:none" id="divContainerVisited_sonstige">
			<div style="width:140px; display:block">
				<hr />
            </div>
		
				<div id="divContainerVisited_sonstige_1">
				</div>
			
				<div id="divContainerVisited_sonstige_2">
				</div>
			
				<div id="divContainerVisited_sonstige_3">
				</div>
			
				<div id="divContainerVisited_sonstige_4">
				</div>
			
				<div id="divContainerVisited_sonstige_5">
				</div>
			
				<div id="divContainerVisited_sonstige_6">
				</div>
			
				<div id="divContainerVisited_sonstige_7">
				</div>
			
				<div id="divContainerVisited_sonstige_8">
				</div>
			
				<div id="divContainerVisited_sonstige_9">
				</div>
			</div></div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>

