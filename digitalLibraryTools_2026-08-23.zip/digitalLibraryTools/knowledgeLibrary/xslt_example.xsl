<?xml version="1.0" encoding="iso-8859-1" standalone="yes"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
<xsl:output method='html'/>

<xsl:template match="BrowsingSession">
<html>
<head><title>Xslt Data from XmlDataFile</title></head>
<body>
  Content of XmlDataFile:
  <br /><br />
  
  <xsl:for-each select="TextWebResourceItemGroup/TextWebResourceItem">
	<table>
	  <tr>
	    <td>
			<xsl:value-of select="TextDocDate" />
		</td>
		<td>
		  <div style="border:0px solid black">
			<xsl:element name="a">
			<xsl:attribute name="onclick">
				window.location='BrowsingSession_removeNode.php?url=<xsl:value-of select="TextDocURL" />'
			</xsl:attribute>
			<xsl:attribute name="target">_blank</xsl:attribute>
			<xsl:attribute name="href">
				<xsl:value-of select="TextDocURL" />
			</xsl:attribute>
			<xsl:value-of select="TextDocTitle" />
			</xsl:element>
		  </div>
		</td>
	  </tr>
	  <tr>
	    <td></td>
	    <td>
		  <div style="border:0px solid black; width:500px;">
			<xsl:value-of select="TextDocSummary" />
		  </div>
		</td>
	  </tr>
	</table>
    
	<br />
	
  </xsl:for-each>
</body>
</html>
</xsl:template>

</xsl:stylesheet> 
