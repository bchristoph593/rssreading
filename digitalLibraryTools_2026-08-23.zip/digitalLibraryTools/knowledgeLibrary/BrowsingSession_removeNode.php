<?php 
$itemUrl = $_GET["url"];

echo "<html><head><title>BrowsingSession: Remove ArticleItem</title></head>";
echo '<body onload="document.getElementById(\'backToOverview\').click();">';

echo "Removing TWRI_Structure-childNode with TextWebResource-ItemUrl '". $itemUrl. "' from XmlDataFile.<br><br>";

$dom = new DOMDocument();
$dom->formatOutput = true;
$dom->load("BrowsingSession_xmlDataFile.xml");

$structureTWRI = $dom->getElementsByTagName('TextWebResourceItem');

$itemCount = $structureTWRI->length;

echo "itemCount: ". $itemCount. "<br>"; 

foreach ($structureTWRI as $node) {
	
	$textDocUrl = $node->getElementsByTagName("TextDocURL");
	$strTextDocUrl = $textDocUrl->item(0)->nodeValue;
	
	if($strTextDocUrl == $itemUrl) {
		echo "TextWebResouceItem '".$strTextDocUrl. "' removed from XmlDataFile.<br>";
	
		$node->parentNode->removeChild($node);
	}
}

$dom->save('BrowsingSession_xmlDataFile.xml');

/*
echo '<input id="backToOverview" onclick="window.location=\'http://localhost/digitalLibraryTools/knowledgeLibrary/BrowsingSession_xmlDataFile.xml\';"
		type="button" value="Go back to overview page" 
		/>'. '<br>';
*/
echo '<input id="backToOverview" onclick="window.location=\'http://localhost/digitalLibraryTools/rssreading/readingSession/\';"
		type="button" value="Go back to overview page" 
		/>'. '<br>';

echo '<script>console.log("focus for submit-btn"); document.getElementById("backToOverview").focus();</script>';

echo "</body></html>";
?>