<?php
  $xml = xmlwriter_open_memory();
  xmlwriter_set_indent($xml, 'true');
  xmlwriter_set_indent_string ($xml, '  ');
  
  xmlwriter_start_document($xml, '1.0', 'UTF-8');
  
  xmlwriter_start_element($xml,"BrowsingSession");
  xmlwriter_start_element($xml,"TextWebResourceItemGroup");
  // xmlwriter_start_element($xml,"TextWebResourceItem");
  
  /*
  xmlwriter_write_element($xml,"TextDocURL",".");
  xmlwriter_write_element($xml,"TextDocTitle",".");
  xmlwriter_write_element($xml,"TextDocDate",".");
  xmlwriter_write_element($xml,"TextDocSummary",".");
  */
  
  xmlwriter_end_element($xml);
  xmlwriter_end_element($xml);
  xmlwriter_end_element($xml);
  
  xmlwriter_end_document($xml);
  
  $xml_data=xmlwriter_output_memory($xml);
  file_put_contents("BrowsingSession_xmlDataFile.xml",$xml_data);
?>

<?php 
  $variable = <<<htmlDoc
  <html>
    <head><title>Create KnowledgeLibary BrowsingSession-xmlDataFile</title></head>
    <body>
      xmlDataFile 'BrowsingSession-xmlDataFile.xml' created;
    </body>
  </html>
  htmlDoc;
  
  echo $variable;
?>


