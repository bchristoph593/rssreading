<?php 
$dom = new DOMDocument();
$dom->formatOutput = true;
$dom->load("BrowsingSession_xmlDataFile.xml");

$structureTWRI = $dom->getElementsByTagName('TextWebResourceItem');

foreach ($structureTWRI as $node) {
    $node->parentNode->removeChild($node);
}

$dom->save('BrowsingSession_xmlDataFile.xml');

header("Content-Type: text/plain");
$content = file_get_contents("BrowsingSession_xmlDataFile.xml");
  
$content = preg_replace("/\s\s\s\s/", "", $content);
// $content = preg_replace("/>\s*</", "><", $content);

// var_dump($content);
  
file_put_contents("BrowsingSession_xmlDataFile.xml",$content);

echo "Removed all TWRI_Structure-childNodes from XmlDataFile.";

?>