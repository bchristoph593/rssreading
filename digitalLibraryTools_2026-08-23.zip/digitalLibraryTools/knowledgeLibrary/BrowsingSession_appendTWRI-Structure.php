<?php
  $textDocURL = $_POST['txtDocURL'];
  $textDocDate = $_POST['txtDocDate'];
  $textDocTitle = $_POST['txtDocTitle'];
  $textDocSummary = $_POST['txtDocSummary'];
  
  $match = false;
  
  if(! preg_match("/\sUhr/", $textDocDate)  ) {
	  $match = preg_match("/[0-9[0-9]\s[A-Z][a-z][a-z]/", $textDocDate);
	  
	  if($match) {
		$pubDate = $textDocDate;
		// $pubDate = strftime("%Y-%m-%d %H:%M:%S", strtotime($pubDate));
		$pubDate = strftime("%Y-%m-%d %H:%M", strtotime($pubDate));
		$textDocDate = $pubDate. " Uhr";
	  }
  }
  
  $doc = new DOMDocument();
  $doc->load("BrowsingSession_xmlDataFile.xml");

  $itemKnownInArticleItemList = false;

  $structureTWRI = $doc->getElementsByTagName('TextWebResourceItem');

  $itemCount = $structureTWRI->length;
  echo "itemCount: ". $itemCount. "<br>"; 

  foreach ($structureTWRI as $node) {
	
	$articleUrl = $node->getElementsByTagName("TextDocURL");
	$strTextDocUrl = $articleUrl->item(0)->nodeValue;
	
	if($strTextDocUrl == $textDocURL) {
		echo "Input TextWebResouceItem '".$textDocURL. "' known in XmlDataFile.<br>";
		
		$itemKnownInArticleItemList = true;
	}
  }

  if(! $itemKnownInArticleItemList) {
    $itemGroup = $doc->getElementsByTagName('TextWebResourceItemGroup')->item(0);
  
    $newTextWebResourceItem = $doc->createDocumentFragment();
    $newTextWebResourceItem->appendXML("
      <TextWebResourceItem>
	  <TextDocDate>".$textDocDate."</TextDocDate>
	  <TextDocURL>".$textDocURL."</TextDocURL>
	  <TextDocTitle>".$textDocTitle."</TextDocTitle>
	  <TextDocSummary>".$textDocSummary."</TextDocSummary>
	  </TextWebResourceItem>");
    $itemGroup->appendChild($newTextWebResourceItem);
	  
  }
  
  $doc->save('BrowsingSession_xmlDataFile.xml');
?>

<?php 
/*
		<input onclick="window.location='http://localhost/digitalLibraryTools/knowledgeLibrary/BrowsingSession_xmlDataFile.xml';" type="button" value="Go back to overview page." /><br />
*/

  if(! $itemKnownInArticleItemList) {
    $variable = <<<htmlDoc
    <html>
      <head><title>Collect-step: Append Formular with TWRI-Data to 'BrowsingSession-WebResourceItemList-xmlDataFile'</title></head>
      <body onload="document.getElementById('closeWndBtn').click();">
        Appended TWRI-Structure to xmlDataFile 'BrowsingSession-xmlDataFile.xml';<br /><input id="closeWndBtn" onclick="javascript:window.close('','_parent','');" type="button" value="Close browser tab" /><br /><script>console.log('focus for submit-btn'); document.getElementById('closeWndBtn').focus();</script>
      </body>
    </html>
    htmlDoc;
  
    echo $variable;
  } else {
    $variable = <<<htmlDoc
    <html>
      <head><title>Collect-step: Append Formular with TWRI-Data to 'BrowsingSession-WebResourceItemList-xmlDataFile'</title></head>
      <body onload="document.getElementById('closeWndBtn').click();">
        Not appended known TWRI-Structure to xmlDataFile 'BrowsingSession-xmlDataFile.xml'<br /><input id="closeWndBtn" onclick="javascript:window.close('','_parent','');" type="button" value="Close browser tab" /><br /><script>console.log('focus for submit-btn'); document.getElementById('closeWndBtn').focus();</script>
      </body>
    </html>
    htmlDoc;
  
    echo $variable;
  }
?>
