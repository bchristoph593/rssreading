<?php
  function appendToXmlDataFile($textDocURL, $textDocTitle, $textDocDate, $textDocSummary) {
	  $doc = new DOMDocument();
	  $doc->load("BrowsingSession_xmlDataFile.xml");

	  $itemKnownInArticleItemList = false;

	  $structureTWRI = $doc->getElementsByTagName('TextWebResourceItem');

	  $itemCount = $structureTWRI->length;
	  // echo "itemCount: ". $itemCount. "<br>"; 

	  foreach ($structureTWRI as $node) {
		
		$articleUrl = $node->getElementsByTagName("TextDocURL");
		$strTextDocUrl = $articleUrl->item(0)->nodeValue;
		
		if($strTextDocUrl == $textDocURL) {
			echo "Input TextWebResouceItem '".$textDocURL. "' known in XmlDataFile.<br>";
			
			$itemKnownInArticleItemList = true;
		}
	  }

	  if(! $itemKnownInArticleItemList) {
		$itemGroup = $doc->getElementsByTagName('TextWebResourceItemGroup')->item(0);
	  
		$newTextWebResourceItem = $doc->createDocumentFragment();
		$newTextWebResourceItem->appendXML("
		  <TextWebResourceItem>
		  <TextDocDate>".$textDocDate."</TextDocDate>
		  <TextDocURL>".$textDocURL."</TextDocURL>
		  <TextDocTitle>".$textDocTitle."</TextDocTitle>
		  <TextDocSummary>".$textDocSummary."</TextDocSummary>
		  </TextWebResourceItem>");
		$itemGroup->appendChild($newTextWebResourceItem);
		  
	  }
	  
	  $doc->save('BrowsingSession_xmlDataFile.xml');
	
    // echo "Example function.\n";
    // return $retval;
  }
?>

<?php
  $urlListImport = $_POST['importUrlListTxtArea'];
  
  header('Content-Type: text/html; charset=utf-8');
  
  echo '<html>';
  echo '<meta http-equiv="content-type" content="text/html; charset=utf-8" />';
  echo '<body>';
  echo '<title>Import-step / Resolve-step for list of Url</title>';
  
  preg_match_all('/(https.*\s)/', $urlListImport, $matches);
  
  $countMatches = count($matches[0]);
  
  echo "num Url to import: ".$countMatches;
  echo "<br>";
  echo "List of Url to import:";
  echo "<br>";
  
  for($i = 0; $i < $countMatches; $i++){
	$textDocURL = $matches[0][$i];
    
	$textDocURL = trim($textDocURL);
	
	echo "'".$textDocURL."'";
    echo "<br>";
	
	$textDoc_html = file_get_contents($textDocURL);
	
	$textDoc = new DOMDocument();
	@$textDoc->loadHTML($textDoc_html);
    
    $finder = new DomXPath($textDoc);

	$titleNode = $textDoc->getElementsByTagName('title');
	
	// display title of textDoc;
    if ($titleNode->length){
      $textDocTitle = $titleNode->item(0)->nodeValue;
	  
	  // $textDocTitle = preg_replace('/Ã¶/', 'oe', $textDocTitle);
	  $textDocTitle = preg_replace('/Ã¶/', '&#xF6;', $textDocTitle);
	  // $textDocTitle = preg_replace('/Ã¤/', 'ae', $textDocTitle);
	  $textDocTitle = preg_replace('/Ã¤/', '&#xE4;', $textDocTitle);
	  
	  $textDocTitle = preg_replace('/Ã/', '&#223;', $textDocTitle);
	  // $textDocTitle = preg_replace('/Ã/', 'ss', $textDocTitle);
	  
	  // $textDocTitle = preg_replace('/Ã/', 'Oe', $textDocTitle);
	  $textDocTitle = preg_replace('/Ã/', '&#214;', $textDocTitle);
	  
	  // $textDocTitle = preg_replace('/Ã¼/', 'ue', $textDocTitle);
	  $textDocTitle = preg_replace('/Ã¼/', '&#252;', $textDocTitle);
	  
	  echo "- TextDocTitle: ";
      echo "'". $textDocTitle. "'";
      echo '<br/>';	  
    }

	$textDocDate = "";
	$textDocSummary = "";
	
    if (preg_match('/tagesschau\.de/i', $textDocURL)) {
	  // textDocDate = document.getElementsByClassName("metatextline")[0].innerHTML;
      $dateItemList = $finder->query("//*[contains(@class, 'metatextline')]");
	  
	  $index = 0;
	  
	  foreach($dateItemList as $node) {
	    if($index == 0) {
	      $textDocDate = $node->nodeValue;
		}
		
		$index++;
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 7, 10);
	  
	  $strDay = substr($strDate, 0, 2);
	  $strMonth = substr($strDate, 3, 2);
	  $strYear = substr($strDate, 6, 4);
	  
	  $strTime = substr($textDocDate, 22, 5);
	  
	  $textDocDate = $strYear. "-". $strMonth. "-". $strDay;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  
	  // textDocSummary = $("p.article-head__shorttext > strong").text(); 
      $summaryItemList = $finder->query("//p[contains(@class, 'article-head__shorttext')]//strong");
	  
	  $index = 0;
	  
	  foreach($summaryItemList as $node) {
	    if($index == 0) {
	      $textDocSummary = $node->nodeValue;
		}
		
		$index++;
	  }
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "tagesschau";
      echo '<br/>';
	
    } else if (preg_match('/sportschau\.de/i', $textDocURL)) {
	  // textDocDate = document.getElementsByClassName("metatextline")[0].innerHTML;
      $dateItemList = $finder->query("//p[contains(@class, 'metatextline')]");
	  
	  $index = 0;
	  
	  foreach($dateItemList as $node) {
	    if($index == 0) {
	      $textDocDate = $node->nodeValue;
		}
		
		$index++;
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 7, 10);
	  
	  $strDay = substr($strDate, 0, 2);
	  $strMonth = substr($strDate, 3, 2);
	  $strYear = substr($strDate, 6, 4);
	  
	  $strTime = substr($textDocDate, 22, 5);
	  
	  $textDocDate = $strYear. "-". $strMonth. "-". $strDay;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  
	  // textDocSummary = $("p.article-head__shorttext > strong").text(); 
      $summaryItemList = $finder->query("//p[contains(@class, 'article-head__shorttext')]//strong");
	  
	  $index = 0;
	  
	  foreach($summaryItemList as $node) {
	    if($index == 0) {
	      $textDocSummary = $node->nodeValue;
		}
		
		$index++;
	  }
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "sportschau";
      echo '<br/>';
	  
    } else if (preg_match('/n-tv\.de/i', $textDocURL)) {
	  // textDocDate = $("div.article-detail-head_info-wrapper___m8Od > span").text();
      $dateItemList = $finder->query("//div[contains(@class, 'article-detail-head_info-wrapper___m8Od')]//span");
	  $textDocDate = trim($dateItemList->item(0)->nodeValue);
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';

	  $strDate = substr($textDocDate, 0, 10);
	  
	  $strDay = substr($strDate, 0, 2);
	  $strMonth = substr($strDate, 3, 2);
	  $strYear = substr($strDate, 6, 4);
	  
	  $strTime = substr($textDocDate, 12, 9);
	  
	  $textDocDate = $strYear. "-". $strMonth. "-". $strDay;
	  $textDocDate .= " ". $strTime;
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  // textDocSummary = $("div.wrapper-article > p").first().text();
      $summaryItemList = $finder->query("//div[contains(@class, 'wrapper-article')]//p");
	  $textDocSummary = $summaryItemList->item(0)->nodeValue;
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "n-tv.de";
      echo '<br/>';
	
    } else if (preg_match('/zeit\.de/i', $textDocURL)) {
	  // textDocDate = $("time.metadata__date"); 
	  // if(textDocDate.text() == '') {
	  //   textDocDate = $("span.metadata__date > time");
	  // }
	  // textDocDate = textDocDate.attr("datetime");
	  //
      // $dateItemList = $finder->query("//time[contains(@class, 'metadata__date')]");
      $dateItemList = $finder->query("//time[contains(@class, 'metadata__date')]");
	  if($dateItemList->item(0) == null) {
		$dateItemList = $finder->query("//span[contains(@class, 'metadata__date')]//time");
		
  	    if($dateItemList->item(0) == null) {
		  echo 'date not found'. '<br/>';
		  
		} else {
		  echo 'date found'. '<br/>';
	      $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
		}
		
	  } else {
		echo 'date found'. '<br/>';
	    $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  $strTime = substr($textDocDate, 11, 5);
	  
	  $textDocDate = $strDate;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  
	  // textDocSummary = $("div.summary").text().trim();
      $summaryItemList = $finder->query("//div[contains(@class, 'summary')]");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "zeit.de";
      echo '<br/>';
	  
    } else if (preg_match('/handelsblatt\.com/i', $textDocURL)) {
	  // textDocDate = $("hmg-rich-text hmg-rich-text large compact").text().trim(); 
	  // textDocDateStr = textDocDate.substr(0, 10); 
	  // textDocDateTime = textDocDate.substr(13, 9); 

      $dateItemList = $finder->query("//hmg-rich-text[contains(@class, 'hmg-rich-text large compact')]");
	  $textDocDate = trim($dateItemList->item(0)->nodeValue);
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  
	  $strDay = substr($strDate, 0, 2);
	  $strMonth = substr($strDate, 3, 2);
	  $strYear = substr($strDate, 6, 4);
	  
	  $strTime = substr($textDocDate, 13, 9);
	  
	  $textDocDate = $strYear. "-". $strMonth. "-". $strDay;
	  $textDocDate .= " ". $strTime;
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  
	  // textDocSummary = $("hmg-lead-text hmg-lead-text medium").text().trim(); 
      $summaryItemList = $finder->query("//hmg-lead-text[contains(@class, 'hmg-lead-text medium')]");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "handelsblatt.com";
      echo '<br/>';

    } else if (preg_match('/wiwo\.de/i', $textDocURL)) {
	  // textDocDate = $("hmg-rich-text.hmg-rich-text.large.compact").text().trim(); 
	  // textDocDateStr = textDocDate.substr(0, 10); 
	  // textDocDateTime = textDocDate.substr(13, 9); 

      $dateItemList = $finder->query("//hmg-rich-text[contains(@class, 'hmg-rich-text large compact')]");
	  $textDocDate = trim($dateItemList->item(0)->nodeValue);
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  
	  $strDay = substr($strDate, 0, 2);
	  $strMonth = substr($strDate, 3, 2);
	  $strYear = substr($strDate, 6, 4);
	  
	  $strTime = substr($textDocDate, 13, 9);
	  
	  $textDocDate = $strYear. "-". $strMonth. "-". $strDay;
	  $textDocDate .= " ". $strTime;
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  
	  // textDocSummary = $("hmg-lead-text hmg-lead-text medium").text().trim();
      $summaryItemList = $finder->query("//hmg-lead-text[contains(@class, 'hmg-lead-text medium')]");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "wiwo.de";
      echo '<br/>';
	  	
    } else if (preg_match('/spiegel\.de/i', $textDocURL)) {
	  // textDocDate = $("time.timeformat"); 
	  // textDocDate = textDocDate.attr("datetime");
      // $dateItemList = $finder->query("//time[contains(@class, 'timeformat')]");
      $dateItemList = $finder->query("//time[contains(@class, 'timeformat')]");
	  if($dateItemList->item(0) == null) {
		$dateItemList = $finder->query("//span[contains(@class, 'metadata__date')]//time");
		
  	    if($dateItemList->item(0) == null) {
		  echo 'date not found'. '<br/>';
		  
		} else {
		  echo 'date found'. '<br/>';
	      $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
		}
		
	  } else {
		echo 'date found'. '<br/>';
	    $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  $strTime = substr($textDocDate, 11, 5);
	  
	  $textDocDate = $strDate;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  // textDocSummary = $('[data-area="intro"] > div > div > div').first().text(); 
	  // textDocSummary = $("div.summary").text().trim();
      $summaryItemList = $finder->query("//header[contains(@data-area, 'intro')]//div//div//div");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  // $textDocSummary = preg_replace('/Ã¶/', 'oe', $textDocSummary);
	  $textDocTitle = preg_replace('/Ã¶/', '&#xF6;', $textDocSummary);
	  // $textDocTitle = preg_replace('/Ã¤/', 'ae', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¤/', '&#xE4;', $textDocSummary);
	  
	  $textDocSummary = preg_replace('/Ã/', '&#223;', $textDocSummary);
	  // $textDocSummary = preg_replace('/Ã/', 'ss', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã/', 'Oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã/', '&#214;', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã¼/', 'ue', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¼/', '&#252;', $textDocSummary);
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "Der Spiegel";
      echo '<br/>';
	  
    } else if (preg_match('/manager-magazin\.de/i', $textDocURL)) {
	  // textDocDate = $("time.timeformat"); 
	  // textDocDate = textDocDate.attr("datetime");
      // $dateItemList = $finder->query("//time[contains(@class, 'timeformat')]");
      $dateItemList = $finder->query("//time[contains(@class, 'timeformat')]");
	  if($dateItemList->item(0) == null) {
		$dateItemList = $finder->query("//span[contains(@class, 'metadata__date')]//time");
		
  	    if($dateItemList->item(0) == null) {
		  echo 'date not found'. '<br/>';
		  
		} else {
		  echo 'date found'. '<br/>';
	      $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
		}
		
	  } else {
		echo 'date found'. '<br/>';
	    $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  $strTime = substr($textDocDate, 11, 5);
	  
	  $textDocDate = $strDate;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  // textDocSummary = $('[data-area="intro"] > div > div > div').first().text(); 
	  // textDocSummary = $("div.summary").text().trim();
      $summaryItemList = $finder->query("//header[contains(@data-area, 'intro')]//div//div//div");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  // $textDocSummary = preg_replace('/Ã¶/', 'oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¶/', '&#xF6;', $textDocSummary);
	  // $textDocSummary = preg_replace('/Ã¤/', 'ae', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¤/', '&#xE4;', $textDocSummary);
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "manager-magazin.de";
      echo '<br/>';
	
    } else if (preg_match('/faz\.net/i', $textDocURL)) {
	  // textDocDate = $("time"); 
	  // textDocDate = textDocDate.attr("datetime");
      // $dateItemList = $finder->query("//time");
      $dateItemList = $finder->query("//time");
	  if($dateItemList->item(0) == null) {
		$dateItemList = $finder->query("//time");
		
  	    if($dateItemList->item(0) == null) {
		  echo 'date not found'. '<br/>';
		  
		} else {
		  echo 'date found'. '<br/>';
	      $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
		}
		
	  } else {
		echo 'date found'. '<br/>';
	    $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  $strTime = substr($textDocDate, 11, 5);
	  
	  $textDocDate = $strDate;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  // textDocSummary = $('[data-external-selector="header-teaser"]').first().text();
      $summaryItemList = $finder->query("//p[contains(@data-external-selector, 'header-teaser')]");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  // $textDocSummary = preg_replace('/Ã¶/', 'oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¶/', '&#xF6;', $textDocSummary);
	  // $textDocTitle = preg_replace('/Ã¤/', 'ae', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¤/', '&#xE4;', $textDocSummary);
	  
	  $textDocSummary = preg_replace('/Ã/', '&#223;', $textDocSummary);
	  // $textDocSummary = preg_replace('/Ã/', 'ss', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã/', 'Oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã/', '&#214;', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã¼/', 'ue', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¼/', '&#252;', $textDocSummary);
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "faz";
      echo '<br/>';
	  
    } else if (preg_match('/heise\.de/i', $textDocURL)) {
	  // textDocDate = $("time"); 
	  // textDocDate = textDocDate.attr("datetime");
      // $dateItemList = $finder->query("//time");
      $dateItemList = $finder->query("//time");
	  if($dateItemList->item(0) == null) {
		$dateItemList = $finder->query("//time");
		
  	    if($dateItemList->item(0) == null) {
		  echo 'date not found'. '<br/>';
		  
		} else {
		  echo 'date found'. '<br/>';
	      $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
		}
		
	  } else {
		echo 'date found'. '<br/>';
	    $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  $strTime = substr($textDocDate, 11, 5);
	  
	  $textDocDate = $strDate;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  // textDocSummary = $('p.a-article-header__lead').first().text().trim();
      $summaryItemList = $finder->query("//p[contains(@class, 'a-article-header__lead')]");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  // $textDocSummary = preg_replace('/Ã¶/', 'oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¶/', '&#xF6;', $textDocSummary);
	  // $textDocTitle = preg_replace('/Ã¤/', 'ae', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¤/', '&#xE4;', $textDocSummary);
	  
	  $textDocSummary = preg_replace('/Ã/', '&#223;', $textDocSummary);
	  // $textDocSummary = preg_replace('/Ã/', 'ss', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã/', 'Oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã/', '&#214;', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã¼/', 'ue', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¼/', '&#252;', $textDocSummary);
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "heise";
      echo '<br/>';
	  
    } else if (preg_match('/telepolis\.de/i', $textDocURL)) {
	  // textDocDate = $("time"); 
	  // textDocDate = textDocDate.attr("datetime");
      // $dateItemList = $finder->query("//time");
      $dateItemList = $finder->query("//time");
	  if($dateItemList->item(0) == null) {
		$dateItemList = $finder->query("//time");
		
  	    if($dateItemList->item(0) == null) {
		  echo 'date not found'. '<br/>';
		  
		} else {
		  echo 'date found'. '<br/>';
	      $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
		}
		
	  } else {
		echo 'date found'. '<br/>';
	    $textDocDate = trim($dateItemList->item(0)->getAttribute('datetime'));
	  }
	  
	  echo "- TextDocDate: ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  $strDate = substr($textDocDate, 0, 10);
	  $strTime = substr($textDocDate, 11, 5);
	  
	  $textDocDate = $strDate;
	  $textDocDate .= " ". $strTime. " Uhr";
	  
	  echo "- TextDocDate (2): ";
	  echo "'". $textDocDate. "'";
      echo '<br/>';
	  
	  // textDocSummary = $('p.lead.beitraganriss').first().text().trim();
      $summaryItemList = $finder->query("//p[contains(@class, 'lead beitraganriss')]");
	  
	  if($summaryItemList->item(0) == null) {
		  $textDocSummary = 'no summary available.';
		  
	  } else {
		$textDocSummary = trim($summaryItemList->item(0)->nodeValue);
	  }
	  
	  // $textDocSummary = preg_replace('/Ã¶/', 'oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¶/', '&#xF6;', $textDocSummary);
	  // $textDocTitle = preg_replace('/Ã¤/', 'ae', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¤/', '&#xE4;', $textDocSummary);
	  
	  $textDocSummary = preg_replace('/Ã/', '&#223;', $textDocSummary);
	  // $textDocSummary = preg_replace('/Ã/', 'ss', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã/', 'Oe', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã/', '&#214;', $textDocSummary);
	  
	  // $textDocSummary = preg_replace('/Ã¼/', 'ue', $textDocSummary);
	  $textDocSummary = preg_replace('/Ã¼/', '&#252;', $textDocSummary);
	  
	  echo "- TextDocSummary: ";
	  echo "'". $textDocSummary. "'";
      echo '<br/>';
	  
	  echo "telepolis";
      echo '<br/>';
	  
	} else {
      echo '<br/>';
	}
			
    echo "appending to xmlDataFile ...";
    appendToXmlDataFile($textDocURL, $textDocTitle, $textDocDate, $textDocSummary);
    echo " done.". "<br /><br />";
  }
  
  echo "</body></html>";
?>

<?php
	/*
		if(textDocURL.match(/tagesschau\.de/i)) {
		alert("tagesschau; date; summary;"); 
		textDocDate = document.getElementsByClassName("metatextline")[0].innerHTML;
		textDocDate = textDocDate.substr(7,10); dateDay = textDocDate.substr(0,2); dateMonth = textDocDate.substr(3,2); dateYear = textDocDate.substr(6,4); textDocDate = dateYear + "-" + dateMonth + "-" + dateDay; 
		textDocSummary = $("p.article-head__shorttext > strong").text(); 
		}
		
		} else if(textDocURL.match(/sportschau\.de/i)) {
		alert("sportschau; date; summary;"); 
		textDocDate = document.getElementsByClassName("metatextline")[0].innerHTML;
		textDocDate = textDocDate.substr(7,10); dateDay = textDocDate.substr(0,2); dateMonth = textDocDate.substr(3,2); dateYear = textDocDate.substr(6,4); textDocDate = dateYear + "-" + dateMonth + "-" + dateDay; 
		textDocSummary = $("p.article-head__shorttext > strong").text(); 
		}
		
		} else if(textDocURL.match(/n-tv\.de/i)) { 
		alert("n-tv; date; summary;"); 
		textDocDate = $("div.article-detail-head_info-wrapper___m8Od > span").text(); 
		textDocDate = textDocDate.substr(0,10); dateDay = textDocDate.substr(0,2); dateMonth = textDocDate.substr(3,2); dateYear = textDocDate.substr(6,4); textDocDate = dateYear + "-" + dateMonth + "-" + dateDay; 
		textDocSummary = $("div.wrapper-article > p").first().text(); 
		}
		
		} else if(textDocURL.match(/zeit\.de/i)) { 
		alert("zeit; date; summary;"); 
		textDocDate = $("span.metadata__date > time"); 
		if(textDocDate.text() == '') {
		  textDocDate = $("div.metadata > time");
		}
		textDocDate = textDocDate.attr("datetime");
		if(textDocDate != '') { 
		  textDocDate = textDocDate.substr(0,10);
		} 
		textDocSummary = $("div.summary").text().trim(); 
		
		} else if(textDocURL.match(/handelsblatt\.com/i)) { 
		  alert("handelsblatt; date; summary;"); 
		  textDocDate = $("hmg-rich-text.hmg-rich-text.large.compact").text().trim(); 
		  textDocDateStr = textDocDate.substr(0, 10); 
		  textDocDateTime = textDocDate.substr(13, 9); 
		  dateDay = textDocDateStr.substr(0,2); dateMonth = textDocDateStr.substr(3,2); dateYear = textDocDateStr.substr(6,4); 
		  textDocDate = dateYear+ "-"+ dateMonth+ "-"+ dateDay; textDocDate = textDocDate+ " "+ textDocDateTime; 
		  textDocSummary = $("hmg-lead-text.hmg-lead-text.medium").text().trim(); 
		
		} else if(textDocURL.match(/wiwo\.de/i)) { 
		  alert("wirtschaftswoche; date; summary;"); 
		  textDocDate = $("hmg-rich-text.hmg-rich-text.large.compact").text().trim(); 
		  textDocDateStr = textDocDate.substr(0, 10); 
		  textDocDateTime = textDocDate.substr(13, 9); 
		  dateDay = textDocDateStr.substr(0,2); dateMonth = textDocDateStr.substr(3,2); dateYear = textDocDateStr.substr(6,4); 
		  textDocDate = dateYear + "-" + dateMonth + "-" + dateDay; 
		  textDocDate = textDocDate+ " "+ textDocDateTime; 
		  textDocSummary = $("hmg-lead-text.hmg-lead-text.medium").text().trim();
		
		} else if(textDocURL.match(/spiegel\.de/i)) { 
		  alert("Der Spiegel; date; summary;"); 
		  textDocDate = $("time.timeformat"); 
		  textDocDate = textDocDate.attr("datetime");
		  textDocDateStr = textDocDate.substr(0, 10); 
		  textDocDateTime = textDocDate.substr(11, 5); 
		  textDocDate = textDocDateStr;
		  textDocDate = textDocDate+ " "+ textDocDateTime+ " Uhr"; 
		  textDocSummary = $('[data-area="intro"] > div > div > div').first().text(); 
		  
		} else if(textDocURL.match(/manager-magazin\.de/i)) { 
		  alert("manager-magazin; date; summary;"); 
		  textDocDate = $("time.timeformat"); 
		  textDocDate = textDocDate.attr("datetime");
		  textDocDateStr = textDocDate.substr(0, 10); 
		  textDocDateTime = textDocDate.substr(11, 5); 
		  textDocDate = textDocDateStr;
		  textDocDate = textDocDate+ " "+ textDocDateTime+ " Uhr"; 
		  textDocSummary = $('[data-area="intro"] > div > div > div').first().text(); 
		
		} else if(textDocURL.match(/faz\.net/i)) { 
			alert("faz; date; summary;"); 
			textDocDate = $("time"); 
			textDocDate = textDocDate.attr("datetime"); 
			textDocDateStr = textDocDate.substr(0, 10); 
			textDocDateTime = textDocDate.substr(11, 5); 
			textDocDate = textDocDateStr; 
			textDocDate = textDocDate+ " "+ textDocDateTime+ " Uhr"; 
			textDocSummary = $('[data-external-selector="header-teaser"]').first().text();
			
		} else if(textDocURL.match(/heise\.de/i)) { 
			alert("heise; date; summary;"); 
			textDocDate = $("time"); 
			textDocDate = textDocDate.attr("datetime"); 
			textDocDateStr = textDocDate.substr(0, 10); 
			textDocDateTime = textDocDate.substr(11, 5); 
			textDocDate = textDocDateStr; 
			textDocDate = textDocDate+ " "+ textDocDateTime+ " Uhr"; 
			textDocSummary = $('p.a-article-header__lead').first().text().trim();
			
		} else if(textDocURL.match(/telepolis\.de/i)) { 
			alert("telepolis; date; summary;"); 
			textDocDate = $("time"); 
			textDocDate = textDocDate.attr("datetime"); 
			textDocDateStr = textDocDate.substr(0, 10); 
			textDocDateTime = textDocDate.substr(11, 5); 
			textDocDate = textDocDateStr; 
			textDocDate = textDocDate+ " "+ textDocDateTime+ " Uhr"; 
			textDocSummary = $('p.lead.beitraganriss').first().text().trim();
	*/
?>