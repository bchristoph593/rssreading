<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>N-TV Online | Schlagzeilen - crossreading</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><?php 
					// session_start();
					// $var=SID;
					// echo $var;
					if(isset($_SESSION)) {
						echo "+";
					} else {
						// echo "-";
					}
				?><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("NTV");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a></div></div><div class="divContent"><strong style="margin:3px;">
                            Newsletter &gt; n-tv.de - Startseite</strong><br></br><hr></hr><strong xmlns="">&gt; Wirtschaft - Marktberichte</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaftBerichte',
                    	'1',
                    	'17 Feb 2012 21:29:21',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Dow-kurz-vor-13-000-article5530421.html',
                    	'Optimismus bei Hellas: Dow kurz vor 13.000',
                    	'Die New Yorker B�rsen notieren zum Wochenausklang gr��tenteils in der Gewinnzone. Die Indizes profitieren vor allem von der Hoffnung auf eine baldige L�sung der Griechenland-Problematik. Gebremst wird Aufw�rtsbewegung von Anlegern, die vor dem langen Feiertagswochenende nach den starken Kursgewinnen vom Vortag Gewinne mitnehmen wollen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaftBerichte',
                    	'2',
                    	'17 Feb 2012 17:01:07',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Euro-laesst-leicht-nach-article5524726.html',
                    	'Meldung zu IWF-Beitrag: Euro l�sst leicht nach',
                    	'Die Chancen auf ein Ende der H�ngepartie zum Finanzministertreffen am Montag sind etwas gestiegen, aber es bleiben viele offene Fragen. Marktbeobachter �u�ern sich skeptisch �ber die Chancen, dass die Euro-Partner und der IWF die 130 Milliarden Euro schwere Kredite am Montag wirklich abnicken werden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaftBerichte',
                    	'3',
                    	'17 Feb 2012 16:37:45',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Dax-macht-in-Optimismus-article5523516.html',
                    	'Durchbruch nach oben: Dax macht in Optimismus',
                    	'Trotz der noch keineswegs sicheren Griechenland-Rettung l�sst sich die B�rse die gute Stimmung zum Wochenausklang nicht vermiesen. Am Markt �berwiegen die Optimisten, die an eine baldige L�sung f�r Athens Schuldenprobleme hoffen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaftBerichte',
                    	'4',
                    	'17 Feb 2012 16:14:19',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Oelpreise-klettern-auf-Rekordhochs-article5525316.html',
                    	'WTI folgt Brent nach oben: �lpreise klettern auf Rekordhochs',
                    	'Gute US-Konjunkturdaten und eine Entspannung in der Euro-Schuldenkrise treiben die �lpreise nach oben. Allerdings geben Experten zu bedenken, dass Rohstoffe wegen der erwarteten Rezession in der Eurozone wohl &#034;kein allzu attraktives Investment&#034; sind. Auch Gas wird teurer.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaftBerichte',
                    	'5',
                    	'17 Feb 2012 07:08:25',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Nikkei-schliesst-im-Plus-article5523016.html',
                    	'Optimistische Anleger: Nikkei schlie�t im Plus',
                    	'An den asiatischen B�rsen geben zum Wochenschluss die Optimisten den Takt vor. Nicht nur solide Konjunkturdaten aus den USA bewegen viele Anleger zu K�ufen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaftBerichte',
                    	'6',
                    	'16 Feb 2012 21:34:12',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Wall-Street-legt-zu-article5516081.html',
                    	'Anleger setzen auf Athen-Rettung: Wall Street legt zu ',
                    	'An den US-B�rsen herrscht am Donnerstag eine deutlich bessere Stimmung: In Europa verst�rken sich die Anzeichen, dass es hinsichtlich Griechenlands zu einer Einigung zur Rettung gibt. Dazu werden in den USA ordentlichen Konjunkturzahlen vorgelegt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaftBerichte',
                    	'7',
                    	'16 Feb 2012 17:00:12',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Dax-schliesst-knapp-im-Minus-article5511936.html',
                    	'Erst Athen-Angst, dann US-Hoffnung: Dax schlie�t knapp im Minus',
                    	'Gut erholt vom Tagestief rettet sich der deutsche Aktienmarkt knapp unterhalb der Gewinnzone in den Feierabend. Unerwartet ermutigende Konjunkturdaten aus den USA nehmen den Anlegern die schlimmsten Sorgen von der Brust.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaftBerichte',
                    	'7'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Wirtschaft - Arbeitsmarkt</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'wirtschaftArbeitsmarkt',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Wirtschaft - Finanzmarkt</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaftFinanzmarkt',
                    	'1',
                    	'17 Feb 2012 17:01:07',
                    	'http://www.n-tv.de/wirtschaft/marktberichte/Euro-laesst-leicht-nach-article5524726.html',
                    	'Meldung zu IWF-Beitrag: Euro l�sst leicht nach',
                    	'Die Chancen auf ein Ende der H�ngepartie zum Finanzministertreffen am Montag sind etwas gestiegen, aber es bleiben viele offene Fragen. Marktbeobachter �u�ern sich skeptisch �ber die Chancen, dass die Euro-Partner und der IWF die 130 Milliarden Euro schwere Kredite am Montag wirklich abnicken werden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaftFinanzmarkt',
                    	'2',
                    	'17 Feb 2012 06:34:55',
                    	'http://www.n-tv.de/wirtschaft/Deutschland-soll-mehr-ausgeben-article5521926.html',
                    	'US-Experte skizziert Euro-L�sung: Deutschland soll mehr ausgeben',
                    	'Mit einem Einwurf von au�en mischt sich ein Wirtschaftswissenschaftler in den Streit der Europ�er um einen Ausweg aus der Schuldenkrise ein: Barry Eichengreen h�lt es f�r absolut notwendig, dass Deutschland mehr gegen absehbare Konjunktureinbr�che tut und sich st�rker zu seiner Rolle als St�tze der W�hrungsgemeinschaft bekennt.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaftFinanzmarkt',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><div xmlns="">
<strong>&gt; Wirtschaft</strong><div class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'1',
                    	'17 Feb 2012 18:28:48',
                    	'http://www.n-tv.de/wirtschaft/UPS-blitzt-bei-TNT-ab-article5532131.html',
                    	'Feindliche �bernahme m�glich: UPS blitzt bei TNT ab',
                    	'UPS l�uft bei seinem ersten �bernahmeversuchbei TNT Express ins Leere. Die Niederl�nder schlagen eine Offerte des amerikanischen Paketdienst-Branchenprimus&#039; aus. UPS will nun sein Angebot �berarbeiten.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'2',
                    	'17 Feb 2012 17:14:27',
                    	'http://www.n-tv.de/wirtschaft/EZB-tauscht-Athen-Bonds-um-article5531916.html',
                    	'Weidmann stimmt dagegen: EZB tauscht Athen-Bonds um',
                    	'Die EZB wechselt griechische Schuldpapiere in neue Anleihen um. Allerdings geschieht das nicht mit dem Votum aller Mitglieder des EZB-Rats. So spricht sichBundesbank-Pr�sident Weidmann gegen diese Aktion aus. Er bef�rchtet, dass sich die Notenbankangreifbar f�r m�gliche private Gl�ubiger macht.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'3',
                    	'17 Feb 2012 16:35:38',
                    	'http://www.n-tv.de/wirtschaft/Murdoch-geht-in-Offensive-article5531566.html',
                    	'"Sun of Sunday" kommt: Murdoch geht in Offensive',
                    	'Obwohl das britische Krawallblatt &#034;Sun&#034; im Zusammenhang mit dem Abh�rskandal in Verruf geraten ist, l�sst es Verleger Murdoch nicht fallen. Im Gegenteil: Er will nun die &#034;Sun of Sunday&#034; herausbringen. Die &#034;Sun&#034; ist die auflagenst�rkste Zeitung Gro�britanniens.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'4',
                    	'17 Feb 2012 16:09:42',
                    	'http://www.n-tv.de/wirtschaft/GdF-droht-mit-weiteren-Streiks-article5521776.html',
                    	'Keine Entwarnung am Airport Frankfurt: GdF droht mit weiteren Streiks',
                    	'Seit zwei Tagen herrscht am Frankfurter Flughafen Ausnahmezustand. Und ein Ende ist nicht in Sicht. Die Fronten zwischen der Gewerkschaft GdF, die die streikenden Flugfeld-Mitarbeiter vertritt, un der Flughafengesellschaft Fraport sind verh�rtet. Ab Montag k�nnte es zu weiteren Streikaktionen kommen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'5',
                    	'17 Feb 2012 15:53:30',
                    	'http://www.n-tv.de/wirtschaft/Staatsmanager-verdienen-weniger-article5531256.html',
                    	'Spaniens Regierung streicht: Staatsmanager verdienen weniger',
                    	'Den Managern der spanischen Staatsbetriebe geht es ans Geld. Die Regierung Rajoy k�rzt deren Geh�lter um durchschnittlich 25 bis 30 Prozent. Damit d�rfen sie im Jahr nicht mehr als 105.000 Euro verdienen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'6',
                    	'17 Feb 2012 14:37:16',
                    	'http://www.n-tv.de/wirtschaft/Griechen-brauchen-mehr-Geld-article5530046.html',
                    	'Hilfspaket wohl zu klein: Griechen brauchen mehr Geld',
                    	'Griechenland liegt - finanziell gesehen - im Koma. In Br�ssel und Athen wird intensiv gerechnet. Aus EU-Kreisen verlautet, dass das Hilfspaket, das die internationalen Geldgeber schn�ren, nicht ausreichend ist. EU-Partner und IWF k�nnten die Zinsmarge f�r die R�ckzahlungen aus dem ersten Hilfspaket f�r Athen senken.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'7',
                    	'17 Feb 2012 12:18:10',
                    	'http://www.n-tv.de/wirtschaft/Paris-warnt-vor-Hellas-Crash-article5526561.html',
                    	'Letzter Ausweg Staatspleite?: Paris warnt vor Hellas-Crash',
                    	'Kommende Woche entscheiden die Euro-Minister �ber das Schicksal Griechenlands. Viel Zeit f�r eine Einigung bleibt nicht. Ob die Rettung gelingt, ist vollkommen ungewiss. Zweifel kommen auf, ob die Hilfe ausreicht. Sch�uble spielt angeblich bereits ein ganz anderes Szenario durch. Berlin dementiert. Paris sendet schrille T�nen aus.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'8',
                    	'17 Feb 2012 12:16:54',
                    	'http://www.n-tv.de/wirtschaft/Mehr-Geld-fuer-die-Metaller-article5527586.html',
                    	'�konomen-Barometer: Mehr Geld f�r die Metaller',
                    	'Trotz der europ�ischen Schuldenkrise blicken viele �konomen wieder optimistischer in die Zukunft. Vor diesem Hintergrund sto�en die Forderungen der Gewerkschaften in den Tarifverhandlungen der Metall- und Elektroindustrie auf Verst�ndnis.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'9',
                    	'17 Feb 2012 10:59:58',
                    	'http://www.n-tv.de/wirtschaft/MTU-heimst-Auftraege-ein-article5526191.html',
                    	'Luftfahrtmesse in Singapur: MTU heimst Auftr�ge ein',
                    	'Der Aufwand f�r einen Messeauftritt in Asien zahlt sich f�r MTU Aero Engines ordentlich aus: Die Au�endienstmitarbeiter des Triebwerksherstellers schicken prall gef�llten Auftragsmappen nach Hause.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'10',
                    	'17 Feb 2012 10:09:59',
                    	'http://www.n-tv.de/wirtschaft/Siemens-setzt-auf-Ebbe-und-Flut-article5524856.html',
                    	'Strom aus der Kraft der Gezeiten: Siemens setzt auf Ebbe und Flut',
                    	'Die Neuausrichtung in der deutschen Energiepolitik verbessert die Erfolgschancen von Nischenanbietern im Markt f�r Erneuerbare Energien. Der Dax-Konzern Siemens prescht mit einer �bernahme vor und sichert sich so Knowhow f�r Gezeitenkraftwerke.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'11',
                    	'17 Feb 2012 09:10:53',
                    	'http://www.n-tv.de/wirtschaft/Air-Australia-ist-pleite-article5523921.html',
                    	'Kein Geld mehr f�r Flug-Sprit: Air Australia ist pleite',
                    	'Die australische Air Australia muss aufgeben: Finanzielle Schwierigkeiten zwingen die Billigfluggesellschaft dazu, den Flugbetrieb ohne Vorank�ndigung einzustellen. F�r einzelne Maschine reicht das Geld nicht einmal mehr f�r den R�ckflug. Die Piloten bekommen keinen Treibstoff. Tausende Passagiere h�ngen in Phuket, Bali und Honolulu fest.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'12',
                    	'16 Feb 2012 19:00:18',
                    	'http://www.n-tv.de/wirtschaft/Opel-packt-Rotstift-wieder-aus-article5518061.html',
                    	'Tiefrote Zahlen im Schlussquartal : Opel packt Rotstift wieder aus',
                    	'Opel bleibt das Sorgenkind von General Motors. W�hrend der Mutterkonzern nach seiner schweren Krise w�chst und gedeiht, schreiben die R�sselsheimer weiter Verluste. Ein Grund mehr f�r den Opel-Betriebsrat, den Zugang f�r die R�sselsheimer zu wichtigen Exportmarken zu verlangen. Dennoch werden auch harte Einschnitte vollzogen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'13',
                    	'16 Feb 2012 18:26:05',
                    	'http://www.n-tv.de/wirtschaft/Athen-Bonds-werden-umgetauscht-article5520786.html',
                    	'Erster Schritt zum Schuldenschnitt: Athen-Bonds werden umgetauscht',
                    	'Die nationalen Notenbanken der Eurozone tauschen einem Medienbericht zufolge derzeit die griechischen Anleihen in ihrem Besitz gegen neue Anleihen Athens. Bis Montag soll angeblich die ganze Aktion abgeschlossen sein. EZB und Notenbanken w�rden dabei Gewinn machen, hei�t es.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'14',
                    	'16 Feb 2012 17:39:35',
                    	'http://www.n-tv.de/wirtschaft/Mueller-Brot-ist-am-Ende-article5520666.html',
                    	'M�usekot bricht das Genick: M�ller-Brot ist am Ende',
                    	'Der Hygieneskandal erweist sich f�r M�ller-Brot als Sargnagel. Die bayerische Gro�b�ckerei geht in die Insolvenz. Rund 1100 Menschen m�ssen um ihren Job bangen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'15',
                    	'16 Feb 2012 16:46:32',
                    	'http://www.n-tv.de/wirtschaft/GdF-erhoeht-Schlagzahl-article5514651.html',
                    	'Ausstand am Airport Frankfurt: GdF erh�ht Schlagzahl',
                    	'Die Mitarbeiter auf dem Vorfeld des Frankfurter Flughafens machen ernst - sie streiken. Zahlreiche Fl�ge fallen aus. Am Freitag droht den Flugg�sten noch gr��eres Ungemach. Die Lufthansa streicht bereits 250 Fl�ge. Aber auch den rund 200 Streikenden weht rauer Wind entgegen. So erntet die kleine Gewerkschaft GdF herbe Kritik durch Verdi.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'16',
                    	'16 Feb 2012 16:21:55',
                    	'http://www.n-tv.de/wirtschaft/Athen-streitet-mit-Partnern-article5513261.html',
                    	'Pl�ne verringern Schulden nicht : Athen streitet mit Partnern',
                    	'Die Griechenland-Rettung ist zumindest erst einmal auf dem Weg. Dennoch h�lt das verbale Gepl�nkel zwischen Athen und den Geldgebern an. Pr�sident Papoulias attackiert Bundesfinanzminister Sch�uble. Die Niederlande wollen ohne ausreichende Garantien keine weiteren Notkredite zuzusagen. Bis zum kommenden Montag gibt es noch viel zu tun.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'17',
                    	'16 Feb 2012 15:05:26',
                    	'http://www.n-tv.de/wirtschaft/SocGen-mit-Gewinneinbruch-article5519221.html',
                    	'2012 wird sehr schwierig: SocGen mit Gewinneinbruch',
                    	'F�r die Societe Generale ist die Finanzkrise noch nicht ausgestanden. So belasten sogenannte Giftpapiere auf das Ergebnis des vierten Quartals. Die Sparte Investmentbanking und Firmenkunden schw�chelt und befindet sich in der Verlustzone. Laut Konzernchef Ouadea bleibt das laufende Jahr f�r die franz�sische Gro�bank volatil.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'18',
                    	'16 Feb 2012 14:02:01',
                    	'http://www.n-tv.de/wirtschaft/kolumnen/Die-Griechen-haben-einen-Plan-article5514701.html',
                    	'Per Saldo - die Wirtschaftskolumne: Die Griechen haben einen Plan',
                    	'Das Verhalten der politischen Klasse Griechenlands tr�gt mitunter bizarre Z�ge. W�hrend sich der Staatspr�sident den deutschen Finanzminister vorkn�pft, hofft das Land auf die dringend ben�tigte Milliardenhilfe. Irrational? Weit gefehlt!'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'18'
                    	);
			?>
</div>
<div style="clear:both"></div>
</div>
<br></br><strong xmlns="">&gt; Politik - Europa</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'politikEuropa',
                    	'1',
                    	'17 Feb 2012 05:21:58',
                    	'http://www.n-tv.de/politik/Pomp-und-PR-in-Baku-article5505216.html',
                    	'Eurovision Song Contest in Aserbaidschan: Pomp und PR in Baku',
                    	'Aserbaidschan ist beides, Unterdr�ckung und Moderne. Deutsche Firmen verdienen daran, und in Berlin feiert Bettina Wulff mit der aserbaidschanischen First Lady. Schlie�lich hat das Land �l und Gas. Beim Eurovision Song Contest in Baku soll die Fassade den Blick auf die korrupte Realit�t verstellen.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'politikEuropa',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Politik</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'politik',
                    	'1',
                    	'17 Feb 2012 19:31:53',
                    	'http://www.n-tv.de/politik/pressestimmen/Wulff-war-kein-Ruhmesblatt-article5532091.html',
                    	'R�cktritt von Bundespr�sident Wulff: "Wulff war kein Ruhmesblatt"',
                    	'Christian Wulff gibt auf. Zum zweiten Mal binnen zwei Jahren tritt damit ein deutsches Staatsoberhaupt von seinem Amt zur�ck. Die Demission war �berf�llig und ist zugleich Chance, dem Amt des Bundespr�sidenten W�rde zur�ckzugeben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'2',
                    	'17 Feb 2012 16:15:50',
                    	'http://www.n-tv.de/politik/Merkel-sucht-die-grosse-Loesung-article5531386.html',
                    	'Suche nach Wulffs Nachfolger beginnt: Merkel sucht die gro�e L�sung',
                    	'Das Ende der �ra Wulff ist der Auftakt f�r die Suche nach einem neuen Staatsoberhaupt. Dabei dr�ckt die Kanzlerin aufs Tempo. Weil die Mehrheiten knapp sind, will Merkel SPD und Gr�ne bei der Suche einbinden. Die FDP f�hlt sich d�piert und pocht auf eine schwarz-gelbe L�sung innerhalb der Bundesversammlung. SPD und Gr�ne stellen umgehend klar, dass sie kein Mitglied der schwarz-gelben Bundesregierung akzeptieren werden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'3',
                    	'17 Feb 2012 15:58:57',
                    	'http://www.n-tv.de/politik/Bekommt-Wulff-den-Ehrensold-article5531101.html',
                    	'Ex-Bundespr�sident muss bangen: Bekommt Wulff den "Ehrensold"?',
                    	'Normalerweise muss sich ein ehemaliger Bundespr�sident keine Sorgen um seinen Lebensabend machen - er bekommt einen &#034;Ehrensold&#034;. Doch bei Ex-Amtsinhaber Wulff liegt der Fall anders, sagt Verfassungsrechtler von Arnim. Zudem hat der CDU-Politiker noch ein As aus der Vergangenheit im �rmel - und kann es wohl auch ausspielen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'4',
                    	'17 Feb 2012 15:36:44',
                    	'http://www.n-tv.de/politik/SPD-und-Gruene-Niemand-aus-dem-Kabinett-article5523661.html',
                    	'Liveticker Wulff, 20.54 Uhr: +++ SPD und Gr�ne: Niemand aus dem Kabinett +++',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'5',
                    	'17 Feb 2012 14:54:29',
                    	'http://www.n-tv.de/politik/US-Wahl/Romney-und-die-Totentaeufer-article5521641.html',
                    	'Bizarres Ritual der Mormonen in der Kritik: Romney und die Totent�ufer',
                    	'Der Friedensnobelpreistr�ger und Auschwitz-�berlebende Elie Wiesel hat Romneys Glauben zum Thema gemacht. Romney soll sich gegen die umstrittene Taufe von Toten einsetzen, wie sie die Mormonen betreiben. Doch Romney weicht aus. Dabei kann er sich mit Blick auf die aktuellen Umfragen keine religi�se Kontroverse leisten.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'6',
                    	'17 Feb 2012 13:43:26',
                    	'http://www.n-tv.de/politik/Das-Ende-des-System-Wulff-article5528641.html',
                    	'Staatsanwaltschaft darf ermitteln: Das Ende des "System Wulff"',
                    	'Es war abzusehen, aber am Ende ist es kurz und knapp - Bundespr�sident Wulff erkl�rt seinen R�cktritt, sein &#034;System&#034; ist beendet. Kanzlerin Merkel reagiert unterk�hlt. Derweil hat hinter den Kulissen das Gezerre um einen gemeinsamen Kandidaten von Bundesregierung und Opposition begonnen, erste Listen kursieren. Die Linke wird nicht zu Gespr�chen eingeladen und reagiert leicht pikiert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'7',
                    	'17 Feb 2012 12:35:42',
                    	'http://www.n-tv.de/politik/Wer-wird-Merkels-Dritter-article5527946.html',
                    	'Kandidaten-Check: Wer wird Merkels Dritter?',
                    	'Wulff ist als Bundespr�sident Geschichte, jetzt steht Kanzlerin Merkel vor einem Scherbenhaufen. Um die Suche nach dem dritten Staatsoberhaupt w�hrend ihrer Kanzlerschaft zu beschleunigen, l�sst die Unionsfrau SPD und Gr�ne mitreden. Im Kopf wird sie schon die Kandidaten durchgehen. Welche Namen stehen im Raum?'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'8',
                    	'17 Feb 2012 12:08:41',
                    	'http://www.n-tv.de/politik/Das-sind-Ihre-Favoriten-article5527606.html',
                    	'Gauck, Gottschalk, "kein Politiker": Das sind Ihre Favoriten!',
                    	'Bislang ist v�llig offen, wer als Nachfolger von Christian Wulff ins Schloss Bellevue einziehen wird. Wir fragten Sie: Wen w�nschen Sie sich als Staatsoberhaupt? Viele antworten: keinen Politiker. Der Name Gauck f�llt h�ufig, doch auch Beckenbauer oder die Hohenzollern werden genannt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'9',
                    	'17 Feb 2012 11:35:37',
                    	'http://www.n-tv.de/politik/politik_kommentare/Wandel-der-Union-faellt-aus-article5525536.html',
                    	'Wulff ist zur�ckgetreten: Wandel der Union f�llt aus',
                    	'Die Aff�re um Kredite und Drohungen, die Posse aus Reumut und Geheimniskr�merei haben Ex-Bundespr�sident Wulff das Amt gekostet. Damit katapultiert sich der zweite &#034;junge&#034; Kopf der Unionsparteien aus der politischen Spitze. Und entbl��t die Hoffnungen der Konservativen als Fassade.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'10',
                    	'17 Feb 2012 11:23:52',
                    	'http://www.n-tv.de/politik/Merkels-Reaktion-im-Wortlaut-article5526641.html',
                    	'"Eine St�rke unseres Rechtstaats": Merkels Reaktion im Wortlaut',
                    	'Bundeskanzlerin Merkel hat den R�cktritt von Bundespr�sident Wulff &#034;mit gr��tem Respekt&#034; zur Kenntnis genommen. Merkel betonte, Wulff habe &#034;seine �berzeugung, rechtlich korrekt gehandelt zu haben, hinter das Amt&#034; zur�ckgestellt. &#034;Ich zolle dieser Haltung ausdr�cklich meinen Respekt.&#034;'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'11',
                    	'17 Feb 2012 11:03:22',
                    	'http://www.n-tv.de/politik/Wulffs-Erklaerung-im-Wortlaut-article5526506.html',
                    	'"Um den Weg frei zu machen": Wulffs Erkl�rung im Wortlaut',
                    	'Bundespr�sident Wulff hat seinen R�cktritt erkl�rt. Dabei zeigt er sich �berzeugt, dass die staatsanwaltlichen Ermittlungen gegen ihn &#034;zu einer vollst�ndigen Entlastung&#034; f�hren werden. Er habe sich in seinen �mtern &#034;stets rechtlich korrekt verhalten&#034;.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'12',
                    	'17 Feb 2012 10:50:02',
                    	'http://www.n-tv.de/politik/Wulff-tritt-zurueck-article5521876.html',
                    	'Merkel sucht Konsenspr�sidenten: Wulff tritt zur�ck',
                    	'Bundespr�sident Wulff wirft das Handtuch. Damit zieht er nach wochenlanger Diskussion die Konsequenzen aus drohenden Ermittlungen der Staatsanwaltschaft und der immer heftigeren Kritik an ihm. Bundeskanzlerin Merkel spricht sich daf�r aus, gemeinsam mit der Opposition einen Kandidaten f�r die Nachfolge zu suchen. Bundesratspr�sident Seehofer �bernimmt die Vertretung Wulffs. Der Bund der Steuerzahler fordert bei n-tv eine Reform des Ehrensolds f�r Bundespr�sidenten.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'13',
                    	'17 Feb 2012 09:51:28',
                    	'http://www.n-tv.de/politik/Vier-Raketen-pro-Minute-auf-Homs-article5525086.html',
                    	'Angriffe "heftig wie noch nie": Vier Raketen pro Minute auf Homs',
                    	'Das Assad-Regime scheint sich von der Resolution der Uno-Vollversammlung wenig beeindrucken zu lassen. Die Armee beschie�t die Rebellenhochburg Homs st�rker denn je. Auch aus anderen Teilen des Landes werden neue Gefechte gemeldet.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'14',
                    	'17 Feb 2012 08:51:30',
                    	'http://www.n-tv.de/politik/Ermittler-suchen-Drahtzieher-article5523926.html',
                    	'Explosionen in Bangkok: Ermittler suchen Drahtzieher',
                    	'Noch immer sind die Hintergr�nde der Explosionen in Bangkok unklar. Nach Festnahme der drei beteiligten Iraner suchen die Beh�rden nach zwei weiteren M�nnern. Derweil wird mehr �ber die bereits Inhaftierten bekannt. Einer von ihnen soll kurz vor der Tat in Pattaya von einer Thail�nderin auf sein Hotelzimmer begleitet worden sein.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'15',
                    	'17 Feb 2012 07:54:27',
                    	'http://www.n-tv.de/politik/Schaeuble-laesst-Bahr-nachsitzen-article5523311.html',
                    	'Ministerium zerpfl�ckt Pflegereform: Sch�uble l�sst Bahr nachsitzen',
                    	'Mit &#034;schweren Vorbehalten&#034; l�sst das Finanzministerium den Entwurf f�r eine Pflegereform an das Gesundheitsministerium zur�ckgehen. Das CDU-gef�hrte Ressort sieht erhebliche Rechenfehler in dem Papier, das im Haus des FDP-Politikers Bahr entstanden ist.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'16',
                    	'17 Feb 2012 07:23:32',
                    	'http://www.n-tv.de/politik/Feldlager-mit-Millionen-saniert-article5523056.html',
                    	'Kurz vor Abzug aus Kundus: Feldlager mit Millionen saniert',
                    	'In die Infrastruktur des Bundeswehr-Camps in Kundus werden 2013 noch einmal mehrere Millionen Euro gepumpt. So sollen etwa neue Unterk�nfte entstehen, ein neues Rettungstzentrum eingerichtet werden. Und das, obwohl im darauffolgenden Jahr bereits der Abzug der Soldaten aus Afghanistan vorgesehen ist.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'17',
                    	'17 Feb 2012 06:37:01',
                    	'http://www.n-tv.de/politik/pressestimmen/Zeitpunkt-verpasst-article5521956.html',
                    	'Pressestimmen: "Zeitpunkt verpasst"',
                    	'Die Staatsanwaltschaft nimmt die Verbindungen des Bundespr�sidenten zu dem Unternehmer Groenewold genauer unter die Lupe. Dabei droht Wulff die Immunit�t abhanden zu kommen - und das Amt, wie die Presse unisono vorhersagt. In den Zeitungen der Republik zeichnen die Kommentatoren ein verheerendes Bild vom Umgang des Niedersachsen mit der Aff�re.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'18',
                    	'17 Feb 2012 05:47:54',
                    	'http://www.n-tv.de/politik/Al-Kaida-unterstuetzt-Opposition-article5521796.html',
                    	'Sorge �ber Lage in Syrien: Al-Kaida unterst�tzt Opposition',
                    	'Wenn es um Syrien geht, sind im Westen die Sympathien klar verteilt. Die Opposition steht f�r die Freiheit, der autorit�re Machthaber Assad f�r Unterdr�ckung und Gewalt. Doch die Wahrheit ist wohl vielschichtiger: Der US-Geheimdienst sieht Zeichen daf�r, dass Al-Kaida-K�mpfer vom Irak aus in das Land einreisen und sich den Oppositionskr�ften anschlie�en.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'19',
                    	'16 Feb 2012 21:47:06',
                    	'http://www.n-tv.de/politik/Berlin-erwartet-Wulffs-Ruecktritt-article5520886.html',
                    	'Staatsanwaltschaft will ermitteln: Berlin erwartet Wulffs R�cktritt',
                    	'Nachdem die Staatsanwaltschaft Hannover die Aufhebung der Immunit�t von Christian Wulff beantragt hat, fallen Vertreter der Berliner Politik reihenweise vom Bundespr�sidenten ab. Viele �u�ern sich besorgt und aufgeregt �ber die aktuelle Entwicklung und erwarten einen R�cktritt Wulffs zur Schadensbegrenzung bereits an diesem Freitag. Die FDP setzt offenbar darauf, gemeinsam mit der Union ein neues Staatsoberhaupt zu w�hlen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'20',
                    	'16 Feb 2012 21:09:19',
                    	'http://www.n-tv.de/politik/Lebenslang-fuer-Nigerianer-article5521356.html',
                    	'"Unterhosenbomber" verurteilt: Lebenslang f�r Nigerianer',
                    	'In seiner Unterhose versteckt Umar Farouk Abdulmutallab  zu Weihnachten 2009 eine Bombe. Er will ein Flugzeug auf dem Weg von Amsterdam nach Detroit in die Luft sprengen. Dies gelingt ihm nicht, aber f�r seine Terrorpl�ne muss er lebenslang hinter Gitter.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'21',
                    	'16 Feb 2012 20:25:48',
                    	'http://www.n-tv.de/politik/politik_kommentare/Wulff-muss-ausziehen-article5521176.html',
                    	'Zu klein f�r Schloss Bellevue: Wulff muss ausziehen',
                    	'Kann sich Christian Wulff noch halten? Wohl kaum. Die Beantragung der Aufhebung der Immunit�t des Staatsoberhaupts durch die Staatsanwaltschaft Hannover ist ein noch nie dagewesener Vorgang in der bundesdeutschen Geschichte. Einmal mehr wird deutlich: F�r Bellevue ist Wulff der falsche Hausherr. Ein Kommentar von Wolfram Neidhard.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'22',
                    	'16 Feb 2012 19:52:03',
                    	'http://www.n-tv.de/politik/Elterngeld-funktioniert-article5521036.html',
                    	'Durch Studie belegt: Elterngeld funktioniert',
                    	'Als das Elterngeld das Erziehungsgeld abl�ste, sollte es Familien in der Babypause ein h�heres Einkommen erm�glichen und den Wiedereinstieg der M�tter in den Beruf erleichtern. Eine DIW-Studie im Auftrag des Familienministeriums kommt zu dem Schluss, dass diese Ziele erreicht werden. Es gibt jedoch auch ein Aber.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'23',
                    	'16 Feb 2012 19:11:59',
                    	'http://www.n-tv.de/politik/pressestimmen/Waere-das-falsche-Signal-article5520766.html',
                    	'Vorsto� f�r "Veteranentag" in Deutschland: "W�re das falsche Signal"',
                    	'Verteidigungsminister de Maizi�re will den Veteranen der Bundeswehr mehr Aufmerksamkeit und Anerkennung verschaffen: Er regt die Einrichtung eines &#034;Veteranentages&#034;, wie er in zahlreichen anderen L�ndern �blich ist, an. Braucht Deutschland eine derartige &#034;Respektbekundung vor den Soldaten und ihren Angeh�rigen&#034;? Die deutsche Presse diskutiert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'24',
                    	'16 Feb 2012 17:57:55',
                    	'http://www.n-tv.de/politik/Cameron-kaempft-wie-ein-Koenig-article5520756.html',
                    	'Schottland will die Scheidung: Cameron k�mpft wie ein K�nig',
                    	'Nach 300 Jahren als Teil der Krone sieht die schottische Nationalpartei die Chance einer Abspaltung gekommen. Der britische Premier Cameron k�mpft vehement dagegen an und verspricht den Schotten weitere Befugnisse. Die bei�en nicht recht an und schielen stattdessen auf die Steuereinnahmen aus dem Nordsee�l.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'25',
                    	'16 Feb 2012 16:47:34',
                    	'http://www.n-tv.de/politik/UN-verurteilen-Syrien-article5520431.html',
                    	'Neue Verfassung st�rkt Assad: UN verurteilen Syrien',
                    	'Nach der gescheiterten Resolution im Sicherheitsrat verurteilen die Vereinten Nationen mit gro�er Mehrheit das brutale Vorgehen des Assad-Regimes gegen die syrische Bev�lkerung. Das Regime geht weiter mit aller H�rte gegen die Aufst�ndischen vor. Wieder werden Dutzende Aktivisten get�tet.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'26',
                    	'16 Feb 2012 15:47:44',
                    	'http://www.n-tv.de/politik/Einsatz-in-Talokan-beendet-article5519886.html',
                    	'Afghanistan-Kapitel geschlossen: Einsatz in Talokan beendet',
                    	'Das erste Bundeswehrcamp in Afghanistan wird geschlossen. Der St�tzpunkt Talokan in der Provinz Tachar hat keinen milit�rischen Auftrag mehr und wird abgerissen. Die Schlie�ung des Lagers ist das erste sichtbare Zeichen des Bundeswehrabzugs aus Afghanistan, f�r den der Bundestag Ende Januar gr�nes Licht gegeben hatte.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'27',
                    	'16 Feb 2012 15:46:23',
                    	'http://www.n-tv.de/politik/Griechenland-rueckt-nach-links-article5519516.html',
                    	'Sonntagsfrage in Zeiten der Krise: Griechenland r�ckt nach links',
                    	'Die Griechen haben das Vertrauen in die beiden gro�en Parteien offenbar verloren. Vor allem die Sozialisten brechen laut einer Umfrage ein. W�rde jetzt gew�hlt, h�tten Konservative und Sozialisten, die derzeit die Regierung des parteilosen Finanzexperten Papademos st�tzen, keine gemeinsame Mehrheit.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'28',
                    	'16 Feb 2012 15:15:23',
                    	'http://www.n-tv.de/politik/U-Ausschuss-laedt-Zschaepe-vor-article5519271.html',
                    	'Aufkl�rungsbem�hungen in Erfurt: U-Ausschuss l�dt Zsch�pe vor',
                    	'Die Zwickauer Terrorzelle stammte aus Jena. Nicht nur im Bundestag, auch im Th�ringer Landtag kl�rt nun ein Untersuchungsausschuss, warum die Neonazis so lange untertauchen und morden konnten. Die ersten Fragen gehen direkt an Beate Zsch�pe.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'29',
                    	'16 Feb 2012 14:03:03',
                    	'http://www.n-tv.de/politik/politik_kommentare/Deutschland-braucht-keinen-Veteranentag-article5514926.html',
                    	'De Maizi�re, Krieg, Ruhm und Ehre: Deutschland braucht keinen "Veteranentag"',
                    	'�ffentliches Gedenken f�r deutsche Soldaten, Verleihung von Orden f�r den Einsatz des Lebens im Ausland? Verteidigungsminister de Maizi�re will einen &#034;Veteranentag&#034; einrichten. Der Vorsto� wirft die Frage nach unserer gesellschaftlichen Ausrichtung auf. Die Antwort darauf sollte klar sein. Ein Kommentar von Roland Peters.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'politik',
                    	'29'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Technik</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'technik',
                    	'1',
                    	'17 Feb 2012 15:57:34',
                    	'http://www.n-tv.de/technik/Abmahn-Abzocker-verurteilt-article5530866.html',
                    	'Gru�karten an sich selbst geschickt: Abmahn-Abzocker verurteilt',
                    	'Das Landgericht Osnabr�ck verurteilt Abmahn-Abzocker Michael B. wegen gewerbsm��igen Betrugs zu einer Haftstrafe von 18 Monaten auf Bew�hrung. Au�erdem muss er 120.000 Euro an eine gemeinn�tzige Einrichtung zahlen. Der mitangeklagte Anwalt Bernhard S. erh�lt eine Bew�hrungsstrafe von 15 Monaten.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'technik',
                    	'2',
                    	'17 Feb 2012 14:37:09',
                    	'http://www.n-tv.de/technik/Google-schmuggelt-Cookies-article5528286.html',
                    	'Sperre von Safari-Browser ausgetrickst: Google schmuggelt Cookies',
                    	'Wieder Aufregung um Google und den Datenschutz: Der Internet-Konzern hebelt angeblich die Datenschutz-Einstellungen in Apples Browser Safari aus, um Tracking-Cookies von Werbefirmen setzen zu k�nnen. Google spricht von einem Versehen. Unterdessen kn�pft sich Stiftung Warentest die neuen Datenschutzbestimmungen des US-Unternehmens vor.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'technik',
                    	'3',
                    	'17 Feb 2012 05:12:34',
                    	'http://www.n-tv.de/technik/Loescht-Youtube-nicht-genug-article5521756.html',
                    	'Streit mit Gema bald entschieden: L�scht Youtube nicht genug?',
                    	'Der Rechtsstreit zwischen der Gema und Youtube steht kurz vor einer Entscheidung: Das Landgericht Hamburg will am 20. April sein Urteil verk�nden. Dann ist gekl�rt, ob die Videoplattform Rechteinhabern genug M�glichkeiten in die Hand gibt, ihre Werke zu sch�tzen oder zu vermarkten.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'technik',
                    	'4',
                    	'16 Feb 2012 14:50:57',
                    	'http://www.n-tv.de/technik/Apple-laesst-den-Puma-los-article5518776.html',
                    	'OS X Mountain Lion vorgestellt: Apple l�sst den Puma los',
                    	'Apple-Chef Tim Cook will Microsoft zuvorkommen und noch vor Windows 8 ein neues PC-Betriebssystem ver�ffentlichen. Deshalb stellt er �berraschend schon jetzt Mac OS X 10.8 Mountain Lion vor. Entwickler k�nnen das neue Betriebssystem sofort herunterladen, Normal-Nutzer m�ssen sich noch bis zum Sommer gedulden.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'technik',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Wissen</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wissen',
                    	'1',
                    	'17 Feb 2012 15:05:41',
                    	'http://www.n-tv.de/wissen/Schlaf-Gen-nachgewiesen-article5530291.html',
                    	'Angeborene M�digkeit: Schlaf-Gen nachgewiesen',
                    	'Wenn jemand regelm��ig mehr Schlaf braucht, kann das angeboren sein. Ursache ist das sogenannte &#034;Schlaf-Gen&#034;. Es bewirkt, dass manche Menschen fast eine halbe Stunde am Tag l�nger schlafen als andere.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wissen',
                    	'2',
                    	'17 Feb 2012 14:36:55',
                    	'http://www.n-tv.de/wissen/Menschen-mit-Echos-manipuliert-article5529746.html',
                    	'Geheime Klangwelt des Altertums: Menschen mit Echos manipuliert',
                    	'Herrscher des Altertums wussten sich auch ohne Mikrofon Geh�r zu verschaffen. Echos waren ein beliebtes Mittel, um Untertanen zu beeindrucken und zu manipulieren. Selbst beim Bau von Stonehenge soll die Akustik den Ausschlag gegeben haben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wissen',
                    	'3',
                    	'16 Feb 2012 19:16:24',
                    	'http://www.n-tv.de/wissen/Mikro-Chip-setzt-Medikamente-frei-article5518686.html',
                    	'Erfolgreiche Tests: Mikro-Chip setzt Medikamente frei',
                    	'Bei Osteoporose bemerken Patienten es nicht direkt, dass ein Medikament hilft - die Einnahme wird deshalb �fter mal vergessen. Ein Chip, der das Mittel automatisch ins Gewebe abgibt, k�nnte Abhilfe schaffen. Einige Frauen bekamen nun so ein Ger�t eingesetzt.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wissen',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport - Fussball</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'1',
                    	'17 Feb 2012 21:30:43',
                    	'http://www.n-tv.de/sport/fussball/Auch-mit-Babbel-nur-Remis-article5532596.html',
                    	'Hoffenheim gegen Mainz 1:1: Auch mit Babbel nur Remis',
                    	'Schon wieder nur Unentschieden! 1899 Hoffenheim kommt beim Heimspiel-Deb�t seines neuen Trainers Markus Babbel nur zu einem Remis. Die Kraichgauer m�ssen sich gegen Mainz 05 mit einem 1:1 (1:1) zufriedengeben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'2',
                    	'17 Feb 2012 20:38:14',
                    	'http://www.n-tv.de/sport/fussball/Hertha-holt-Rehhagel-article5531356.html',
                    	'R�ckkehr zu Altbew�hrtem: Hertha holt Rehhagel',
                    	'Interessante Entwicklung bei der &#034;alten Dame&#034; Hertha: Mit Otto Rehhagel heuert ein auch nicht mehr ganz junger Trainer bei den Berlinern an. Sowohl das Hertha-Pr�sidium als auch der 73-J�hrige selbst segnen die �berraschende Personalie ab. Rehhagel wurde mit Bremen und Kaiserslautern Meister, mit Griechenland holte er 2004 den EM-Titel.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'3',
                    	'17 Feb 2012 19:14:43',
                    	'http://www.n-tv.de/sport/fussball/St-Pauli-an-der-Spitze-article5532211.html',
                    	'Paderborn rettet Punkt: St. Pauli an der Spitze',
                    	'Mit dem sechsten Ausw�rtssieg in dieser Saison �bernimmt St. Pauli vorerst die Tabellenspitze, der SC Paderborn droht hingegen die Aufstiegspl�tze aus den Augen zu  verlieren. Im Tabellenkeller erk�mpfte der Karlsruher SC zwei wichtige Punkte mit dem 2:0 (0:0) gegen Energie Cottbus.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'4',
                    	'17 Feb 2012 15:56:08',
                    	'http://www.n-tv.de/sport/fussball/Mertesacker-bangt-um-die-EM-article5531291.html',
                    	'Verteidiger f�llt doch l�nger aus: Mertesacker bangt um die EM',
                    	'Schwerer R�ckschlag f�r Fu�ball-Nationalspieler Per Mertesacker: Der Verteidiger vom englischen Erstligisten FC Arsenal wird nach seiner B�nderverletzung operiert und muss nach Angaben seines TrainerArs�ne Wenger weitaus l�nger pausieren als gedacht.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'5',
                    	'17 Feb 2012 12:59:06',
                    	'http://www.n-tv.de/sport/fussball/Cooler-Kunstschuetze-Schlaudraff-article5528661.html',
                    	'Hannover auf dem Weg ins Achtelfinale: Cooler Kunstsch�tze Schlaudraff ',
                    	'Sie tanzen am Abgrund, aber schie�en sich doch noch zum Sieg. Nach dem in der Schlussphase erzwungenen Erfolg gegen den FC Br�gge k�nnte der Weg von Hannover 96 bis ins Achtelfinale der Fu�ball-Europaliga f�hren. Auch dank Jan Schlaudraff.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'6',
                    	'17 Feb 2012 12:48:58',
                    	'http://www.n-tv.de/sport/fussball/Schalker-sorgen-sich-um-Ra-l-article5528396.html',
                    	'Er qu�lt sich mit einer Verletzung: Schalker sorgen sich um Ra�l',
                    	'Das Remis bei Viktoria Pilsen dank Torsch�tze Huntelaar er�ffnet Schalke gute Chancen auf den Achtelfinaleinzug in der Fu�ball-Europaliga. Spielerisch gibt es aber kaum Fortschritte. Und Sorgen bereitet vor allem der am Oberschenkel verletzte Superstar Ra�l. Er br�uchte eine Pause.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'7',
                    	'17 Feb 2012 11:07:49',
                    	'http://www.n-tv.de/sport/fussball/United-Fan-blockiert-ManCity-article5526541.html',
                    	'Kreativ gegen Bau des Scheichklubs: United-Fan blockiert ManCity',
                    	'Es ist ein Kampf David gegen Goliath, und weil der David in diesem Fall eine besonders charmante Idee hat, ist die Geschichte so sch�n. Shaun O\'Brien, Fan des Fu�ballklubs Manchester United, sabotiert ein Bauvorhaben des ungeliebten Stadtrivalen Manchester City. Und das durchaus kreativ.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'8',
                    	'16 Feb 2012 22:15:00',
                    	'http://www.n-tv.de/sport/fussball/Hannover-96-entzaubert-Daum-article5521466.html',
                    	'FC Br�gge f�hrt - und verliert: Hannover 96 entzaubert Daum',
                    	'Hannover 96  darf in der Europa League weiter auf den Einzug ins Achtelfinale  hoffen. Die Niedersachsen schlagen im Zwischenrunden-Hinspiel den FC Br�gge mit Trainer Christoph Daum. Dabei lassen sie sich auch von der G�stef�hrung sowie nicht gegebenen Elfmetern und Eigentoren nicht beirren.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'9',
                    	'16 Feb 2012 20:01:50',
                    	'http://www.n-tv.de/sport/fussball/FC-Schalke-stoesst-in-Pilsen-an-article5521046.html',
                    	'Gute Achtelfinalchancen nach Remis: FC Schalke st��t in Pilsen an',
                    	'Der FC Schalke kommt besser ins Europa-League-Spiel bei Viktoria Pilsen, doch die Tschechen schie�en das erste Tor. Der Treffer hemmt die Offensivbem�hungen der &#034;K�nigsblauen&#034;, zum vierten Mal in Folge gehen sie mit einem R�ckstand in die Pause. Doch weil Klaas-Jan Huntelaar ein Torj�ger ist, sind die Perspektiven f�r das R�ckspiel letztlich doch gl�nzend.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'10',
                    	'16 Feb 2012 19:58:25',
                    	'http://www.n-tv.de/sport/fussball/Klose-trifft-und-scheitert-wohl-article5520796.html',
                    	'Manchester-Duo siegt ausw�rts: Klose trifft und scheitert wohl',
                    	'F�r Nationalst�rmer Miroslav Klose d�rfte die internationale Saison bald beendet sein. Mit seinem Verein Lazio Rom kassiert er in der Europa League eine empfindliche Heimpleite, obwohl er die R�mer gegen Atletico Madrid sogar in F�hrung bringt. Der Sieg von Man United in Amsterdam wird von 76 Festnahmen begleitet.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'11',
                    	'16 Feb 2012 14:51:30',
                    	'http://www.n-tv.de/sport/fussball/BVB-ohne-Kagawa-in-Berlin-article5518786.html',
                    	'Dortmund gehen Spielmacher aus: BVB ohne Kagawa in Berlin',
                    	'Der deutsche Fu�ball-Meister Borussia Dortmund muss im Spiel bei Hertha BSC in Berlin am Samstag auf Shinji Kagawa verzichten. Der Japaner zieht sich im Training einen Au�enbandanriss im linken Sprunggelenk zu und f�llt bis Anfang M�rz aus.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'12',
                    	'16 Feb 2012 14:15:54',
                    	'http://www.n-tv.de/sport/fussball/Voeller-nimmt-Profis-Trikots-weg-article5518181.html',
                    	'Messis Hemd wichtiger als das Spiel: V�ller nimmt Profis Trikots weg',
                    	'Es hat auch etwas R�hrendes, wie sich die Profis von Bayer Leverkusen benehmen, als sie in der Champions League gegen den FC Barcelona spielen d�rfen. Ein wenig scheint es so, als h�tten sie nur eins im Sinn: das Trikot von Lionel Messi. Sportdirektor Rudi V�ller st��t das sauer auf.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sportFussball',
                    	'12'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sport',
                    	'1',
                    	'17 Feb 2012 11:51:56',
                    	'http://www.n-tv.de/sport/Boxer-Chisora-toent-vor-WM-Kampf-article5527471.html',
                    	'Klitschko "in den Hintern treten": Boxer Chisora t�nt vor WM-Kampf',
                    	'Boxweltmeister Vitali Klitschko steigt wieder in den Ring. Gegner Dereck Chisora will ihn in der M�nchner Olympiahalle entthronen. Zuerst aber geht er rodeln und k�ndigt an, den Ukrainer in der achten Runde k.o. zu schlagen. Klitschko staunt. &#034;Ein verr�ckter Hund.&#034;'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sport',
                    	'2',
                    	'16 Feb 2012 17:35:22',
                    	'http://www.n-tv.de/sport/DHB-drohen-stuermische-Zeiten-article5520471.html',
                    	'Neue Verbalattacke im Handball: DHB drohen st�rmische Zeiten',
                    	'Es war f�r kurze Zeit ruhig geworden um die deutsche Handball-Nationalmannschaft. Nun folgt die n�chste Attacke auf den Deutschen Handball-Bund: Ex-Nationalspieler Frank von Behren unterstreicht die Kritik von Silvio Heinevetter. Der DHB gebe ein &#034;erb�rmliches Bild ab&#034;.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'17 Feb 2012 20:48:41',
                    	'http://www.n-tv.de/panorama/Nazis-faelschten-Pfundscheine-article5532476.html',
                    	'Geheimbericht belegt: Nazis f�lschten Pfundscheine',
                    	'Jahrzehnte nach dem Ende des Zweiten Weltkrieges offenbaren Berichte des MI5, mit welchen Strategien die Nazis gegen Gro�britannien vorgehen wollten.  Deutsche Agenten verteilten Bl�ten im gro�en Stil, allerdings fiel ihnen die Idee auf die F��e.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'17 Feb 2012 15:24:19',
                    	'http://www.n-tv.de/panorama/Johan-Friso-in-Lebensgefahr-article5531011.html',
                    	'Von Lawine versch�ttet: Johan Friso in Lebensgefahr',
                    	'Im �sterreichischen Lech geht eine Lawine ab und begr�bt den niederl�ndischen Prinzen Johan Friso. Erst nach 20 Minuten kann er aus den Schneemassen befreit und wiederbelebt werden. Sein Zustand ist kritisch, aber stabil.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'17 Feb 2012 14:48:38',
                    	'http://www.n-tv.de/panorama/Leiche-in-Brunnen-entdeckt-article5530146.html',
                    	'Vermisster belgischer Schlossherr: Leiche in Brunnen entdeckt',
                    	'Aus dem schrecklichen Verdacht wird furchtbare Gewissheit. Der vermisste belgische Familienvater ist tot. Offenbar wird seine Leiche in einem Wald bei Br�gge gefunden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'17 Feb 2012 14:35:09',
                    	'http://www.n-tv.de/ratgeber/40-000-Konten-gekuendigt-article5529856.html',
                    	'Finanzagentur macht ernst: 40.000 Konten gek�ndigt',
                    	'Die Finanzagentur des Bundes hat 40.000 Konten von Privatkunden gek�ndigt. Die betroffenen Besitzer von Bundesschatzbriefen und anderen Bundeswertpapieren h�tten auch nach dem wiederholten Aufruf der Schuldenverwalter die angeforderten Unterlagen nicht eingereicht, teilte die Bundesrepublik Deutschland - Finanzagentur GmbH mit.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'17 Feb 2012 14:30:58',
                    	'http://www.n-tv.de/leute/Rosenstolz-schweigen-article5529886.html',
                    	'Trennungsger�chte um Anna und Peter : Rosenstolz schweigen',
                    	'Gerade sind sie wieder da und k�nnten m�glicherweise schon bald wieder verstummen. Rosenstolz sagen alle Fernseh- und Interviewtermine ab und n�hren damit Ger�chte, die Band k�nnte sich aufl�sen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'6',
                    	'17 Feb 2012 14:09:05',
                    	'http://www.n-tv.de/auto/Peugeot-208-GTi-ist-zurueck-article5529531.html',
                    	'Back To The 80s: Peugeot 208 GTi ist zur�ck',
                    	'Nicht nur der VW kann GTI. Schon in den 80er-Jahren war Peugeots schnelle 205-Variante dem deutschen Konkurrenten ebenb�rtig. Nun legen die Franzosen den kleinen Kraftzwerg neu auf.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'7',
                    	'17 Feb 2012 13:30:58',
                    	'http://www.n-tv.de/incoming/Airbus-muss-A380-nachbessern-article5528526.html',
                    	'Kleinere M�ngel an der Nase: Airbus muss A380 nachbessern',
                    	'Mit einer Sicherheitsanweisung lenkt die europ�ische Flugsicherheitsbeh�rde EASA erneut Aufmerksamkeit auf das wichtigste Prestigeobjekt des europ�ischen Flugzeugbaus. Ein paar Nieten in der Nasenspitze des riesigen Flugzeugs entsprechen nicht den Erwartungen. Airbus muss sie in allen Maschinen vom Typ A380 austauschen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'8',
                    	'17 Feb 2012 13:07:03',
                    	'http://www.n-tv.de/leute/Ein-Lob-fuer-den-ESC-article5528111.html',
                    	'Einer f�r alle und alles auf null: Ein Lob f�r den ESC',
                    	'Wie hei�t es so sch�n: Man soll den Tag nicht vor dem Abend loben. Es hei�t aber auch: No jokes with names. Sagen wir es also schlicht: Deutschlands Vertreter beim Eurovision Song Contest hei�t Roman Lob. Das war zu erwarten. So wie es das Ergebnis in Baku ist.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'9',
                    	'17 Feb 2012 11:41:36',
                    	'http://www.n-tv.de/panorama/Kaeltewelle-setzt-Kolosseum-zu-article5527086.html',
                    	'Restaurierung noch umstritten: K�ltewelle setzt Kolosseum zu',
                    	'Heftige Schneef�lle verursachen viele Sch�den an Kirchen in Mittelitalien und besch�digen auch das ber�hmte Kolosseum in Rom. Aufgrund der Witterungsbedingungen brechen Bruchst�cke aus dem antiken Amphitheater, das seit einiger Zeit f�r Touristen geschlossen ist. Im M�rz sollen lang angek�ndigte Restaurierungsarbeiten an dem Monument beginnen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'10',
                    	'17 Feb 2012 11:41:31',
                    	'http://www.n-tv.de/auto/Der-boese-Blick-macht-an-article5518346.html',
                    	'Autos haben ein Gesicht: Der b�se Blick macht an',
                    	'Die Scheinwerfer sind Augen, K�hlergrill und Logo bilden die Nase und die Lufteinl�sse unter dem Sto�f�nger sind der Mund: Autos haben ein Gesicht. Und das l�st Emotionen aus. Emotionen, die das Kaufverhalten, die Fahrweise und die Identifikation mit dem Wagen beeinflussen k�nnen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'11',
                    	'17 Feb 2012 11:12:43',
                    	'http://www.n-tv.de/auto/Mehr-Qualitaet-dank-Krise-article5526531.html',
                    	'Die besten Autos seit 20 Jahren: Mehr Qualit�t dank Krise',
                    	'Das Krisenjahr 2009 hat die Automobilbranche stark gebeutelt: Doch  eine Studie hat jetzt ergeben, dass gerade die in der Krise gebauten Fahrzeuge eine so hohe Qualit�t haben wie in den letzten 20 Jahren nicht mehr. Ein deutscher Hersteller schneidet besonders gut ab.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'12',
                    	'17 Feb 2012 11:02:31',
                    	'http://www.n-tv.de/panorama/Karnevalisten-reagieren-prompt-article5526466.html',
                    	'Wulff-Wagen wird umgestaltet: Karnevalisten reagieren prompt',
                    	'F�r die Rosenmontagsumz�ge im Karneval ist der nunmehr ehemalige Pr�sident Wulff ein gefundenes Fressen. Doch dass seine Amtszeit kurz vor dem n�rrischen Treiben zu Ende gehen w�rde, konnte niemand wissen. In Mainz stehen jetzt Sonderschichten an, um die Motivwagen auf R�cktritt zu trimmen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'13',
                    	'17 Feb 2012 09:10:53',
                    	'http://www.n-tv.de/panorama/Khedira-Foto-zu-anstoessig-article5524226.html',
                    	'Tunesische Journalisten verhaftet: Khedira-Foto zu anst��ig',
                    	'In Tunesien regiert seit dem Sturz Ben Alis eine islamistische Partei. Und die geht hart gegen Verst��e gegen die �ffentliche Moral vor: Weil sie in ihrer Zeitung ein Foto des deutsch-tunesischen Fu�ballers Khedira mit seiner nackten Freundin zeigen, m�ssen drei Journalisten eine lange Haftstrafe bef�rchten.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'14',
                    	'17 Feb 2012 08:37:38',
                    	'http://www.n-tv.de/panorama/Akihito-kommt-ins-Krankenhaus-article5523561.html',
                    	'Japans Kaiser braucht Bypass: Akihito kommt ins Krankenhaus',
                    	'Japan sorgt sich um Kaiser Akihito. Der 78-j�hrige Monarch muss am Herzen operiert werden. Zur Vorbereitung des Eingriffs ist er nun ins Krankenhaus gekommen. Er bekommt einen Bypass gelegt. Wenn alles gut geht, ist er in zwei Wochen wieder auf dem Damm.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'15',
                    	'17 Feb 2012 07:48:32',
                    	'http://www.n-tv.de/panorama/Moderatoren-werden-abgestraft-article5523281.html',
                    	'Houston als "Crackhure" beschimpft: Moderatoren werden abgestraft',
                    	'Gemeinhin gilt: �ber Tote nur Gutes. Weil zwei bekannte Radiomoderatoren in den USA diese Regel verletzen und die verstorbene Pop-Diva Whitney Houston beleidigen, werden sie nun erstmal zum Schweigen verdonnert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'16',
                    	'17 Feb 2012 05:00:16',
                    	'http://www.n-tv.de/reise/Oesterreich-hat-laengsten-Rodelspass-article5516796.html',
                    	'Alpenl�nder-Bahnen im Test: �sterreich hat l�ngsten Rodelspa�',
                    	'Auf die Schlitten, fertig, los! Wer viel vom Rodeln haben will, f�hrt nach �sterreich. Die l�ngste Rodelbahn der Alpen findet man dort, im Salzburger Land. In den Top 5 ist �sterreich gleich viermal vertreten.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'17',
                    	'16 Feb 2012 21:43:50',
                    	'http://www.n-tv.de/leute/Roman-Lob-singt-fuer-Deutschland-article5521416.html',
                    	'Unser Star f�r Baku: Roman Lob singt f�r Deutschland',
                    	'Die neue Lena hei�t Roman. Roman Lob aus Rheinland-Pfalz. Er f�hrt f�r Deutschland zum Eurovision Song Contest nach Baku. Der 21-J�hrige war von Anfang an der Favorit beim deutschen Vorentscheid.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'18',
                    	'16 Feb 2012 19:12:52',
                    	'http://www.n-tv.de/panorama/Uni-Koeln-raeumt-auf-article5520946.html',
                    	'"Bestattungsr�ckstand" in Anatomie: Uni K�ln r�umt auf',
                    	'Viele Universit�ten sind f�r die Lehre darauf angewiesen, dass Menschen nach dem Tod ihre K�rper zur Verf�gung stellen. Die Universit�t in K�ln verliert dabei ein wenig den �berblick und kommt mit der Bestattung kaum noch hinterher. Nun muss sie Ordnung in das System bringen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'19',
                    	'16 Feb 2012 18:41:12',
                    	'http://www.n-tv.de/panorama/E-Zigarette-explodiert-im-Mund-article5520826.html',
                    	'Schrank und Kissen in Flammen: E-Zigarette explodiert im Mund',
                    	'Elektronische Zigaretten erfreuen sich zunehmend als Ersatz f�r traditionelle Glimmst�ngel. Die Ger�te rauchen nicht, sondern dampfen, sind batteriebetrieben und offenbar nicht ganz ungef�hrlich. Diese Erfahrung muss jetzt ein Raucher in der USA machen, dessen E-Zigarette in die Luft fliegt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'20',
                    	'16 Feb 2012 14:20:57',
                    	'http://www.n-tv.de/panorama/Richter-lassen-Brueder-laufen-article5518231.html',
                    	'Laserattacke auf Airbus-Jet: Richter lassen Br�der laufen',
                    	'Aufgrund einer cleveren Verteidigungsstrategie muss das Amtsgericht Neuss zwei Br�der laufen lassen, die eine Laserattacke auf ein Flugzeug bei D�sseldorf zugegeben hatten. Das Gericht kann nicht zweifelsfrei kl�ren, wer von den Br�dern den Pointer in der Hand gehalten hatte. Am Ende hei�t es: Im Zweifel f�r den Angeklagten. Die Staatsanwaltschaft nimmt das nicht hin.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'21',
                    	'16 Feb 2012 14:17:21',
                    	'http://www.n-tv.de/auto/Baby-Cayenne-Macan-kommt-2013-article5518101.html',
                    	'Raubkatze von Porsche: Baby-Cayenne Macan kommt 2013',
                    	'Modellnamen haben bei Porsche eine tiefere Bedeutung. Insofern verwundert es nicht, dass die Zuffenhausener dem kleinen Bruder des Cayenne den Namen Macan geben, was im Indonesischen nicht weniger als Tiger bedeutet. Die Raubkatze soll ab 2013 in Leipzig gebaut werden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'22',
                    	'16 Feb 2012 14:12:14',
                    	'http://www.n-tv.de/panorama/Stil-Ikone-kollabiert-am-Laufsteg-article5518141.html',
                    	'Tod bei der Fashion Week: Stil-Ikone kollabiert am Laufsteg',
                    	'Ihr Leben waren die Mode, Lifestyle, und Parties mit Menschen, die ihre Urenkel h�tten sein k�nnen. Am Ende stirbt Zelda Kaplan wo sie am gl�cklichsten war, w�hrend einer Modenschau.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'23',
                    	'16 Feb 2012 14:03:51',
                    	'http://www.n-tv.de/ratgeber/Hier-gibt-s-mehr-fuers-Geld-article5508676.html',
                    	'Budgethotels im Test: Hier gibt\'s mehr f�rs Geld',
                    	'Der Markt der Budget-Hotels w�chst. Und das verdanken die Anbieter nicht nur der Sparmentalit�t der Deutschen. Die Konzepte wurden weiterentwickelt, so dass die H�user f�r viele Kunden attraktiv werden. Niemand muss eigene Handt�cher mitbringen und freundliches Personal ist auch bei g�nstigen Preisen drin. Nur beim Fr�hst�ck gibt es offenbar Verbesserungsbedarf.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'23'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>

