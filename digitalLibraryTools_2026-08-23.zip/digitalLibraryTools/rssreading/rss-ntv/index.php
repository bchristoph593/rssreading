<?php
	include("../uc/header_imports.php");
	
	$xslPath = "xsl-sheets/rss-ntv.xsl";

	$portal = "ntv";
		
	$url_newsengine = "http://newsengine.v232681353.yourvserver.net"; 
	$url = $url_newsengine . "/ressourceBuilder.php?";
	$url .= "portal=".$portal;
		
	$rssPath = $url;

	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	@include("temp.php");
?>
