<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>N-TV Online | Schlagzeilen - crossreading</title>
                <link rel="shortcut icon" href="/images/favicon/fav-ntv.ico" />
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
						
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
				<xsl:processing-instruction name="php">
					// session_start();
					// $var=SID;
					// echo $var;
					if(isset($_SESSION)) {
						echo "+";
					} else {
						// echo "-";
					}
				?</xsl:processing-instruction>
							
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("NTV");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                            Newsletter &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="WirtschaftBerichte" />
                        <br />
						<xsl:call-template name="WirtschaftArbeitsmarkt" />
                        <br />
						<xsl:call-template name="WirtschaftFinanzmarkt" />
                        <br />
						<xsl:call-template name="Wirtschaft" />
                        <br />
						<xsl:call-template name="PolitikEuropa" />
                        <br />
						<xsl:call-template name="Politik" />
                        <br />
						<xsl:call-template name="Technik" />
                        <br />
						<xsl:call-template name="Wissen" />
                        <br />
						<xsl:call-template name="SportFussball" />
                        <br />
						<xsl:call-template name="Sport" />
                        <br />
						<xsl:call-template name="Sonstige" />
                        <br />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
                
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="WirtschaftBerichte">
		<strong>&gt; Wirtschaft - Marktberichte</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wirtschaft/marktberichte/'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaftBerichte'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="WirtschaftArbeitsmarkt">
		<strong>&gt; Wirtschaft - Arbeitsmarkt</strong>
		
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wirtschaft'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaftArbeitsmarkt'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									and (
										contains(title, 'Job-Chancen')
										or contains(title, 'Arbeitsmarkt')
										or contains(title, 'Stellenabbau')
										or contains(title, 'K�ndigungen')
										or contains(title, 'Kollegensuche')
										or contains(title, 'neue Jobs')
										or contains(title, 'neue Stellen')
										or contains(title, 'Jobs streichen')
										or contains(title, 'Jobabbau')
										or contains(title, 'arbeiter streiken')
									)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(link, $searchFor)
									and (
										contains(title, 'Job-Chancen')
										or contains(title, 'Arbeitsmarkt')
										or contains(title, 'Stellenabbau')
										or contains(title, 'K�ndigungen')
										or contains(title, 'Kollegensuche')
										or contains(title, 'neue Jobs')
										or contains(title, 'neue Stellen')
										or contains(title, 'Jobs streichen')
										or contains(title, 'Jobabbau')
										or contains(title, 'arbeiter streiken')
									)
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="WirtschaftFinanzmarkt">
		<strong>&gt; Wirtschaft - Finanzmarkt</strong>
		
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wirtschaft'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaftFinanzmarkt'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									and (
										contains(title, 'Euro ')
										or contains(title, 'bond')
										or contains(title, 'Devise')
										or contains(title, 'Staatsanleihe')
										or contains(title, 'IWF')
									)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
											contains(link, $searchFor)
											and (
												contains(title, 'Euro ')
												or contains(title, 'bond')
												or contains(title, 'Devise')
												or contains(title, 'Staatsanleihe')
												or contains(title, 'IWF')
											)
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Wirtschaft">
	<!--
		comment:
		- create the section-object here
		- set (name="Wirtschaft", title="wirtschaft")
		- foreach item matching the xsl-rules:
		  - create item-object
		  - set (pubDate, link, title, description)
		  - add item-object to section-object
		- generate section- html
		  - check for each item against database- table:
		    - if not contained in table, add to first container "unknown"
		    - if contained in table, add to second container "known / visited before"
		- output section- html
		  - only, if at least 1 item contained in section
	-->
	<div>
		<strong>&gt; Wirtschaft</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wirtschaft'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaft'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									and contains(link, '/marktberichte/')=false
									and (
										contains(title, 'Job-Chancen')
										or contains(title, 'Arbeitsmarkt')
										or contains(title, 'Stellenabbau')
										or contains(title, 'K�ndigungen')
										or contains(title, 'Kollegensuche')
										or contains(title, 'neue Jobs')
										or contains(title, 'neue Stellen')
										or contains(title, 'Jobs streichen')
										or contains(title, 'Jobabbau')
										or contains(title, 'arbeiter streiken')
									)=false
									and (
										contains(title, 'Euro')
										or contains(title, 'bond')
										or contains(title, 'Devise')
										or contains(title, 'Staatsanleihe')
										or contains(title, 'IWF')
									)=false
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(link, $searchFor)
									and contains(link, '/marktberichte/')=false
									and (
										contains(title, 'Job-Chancen')
										or contains(title, 'Arbeitsmarkt')
										or contains(title, 'Stellenabbau')
										or contains(title, 'K�ndigungen')
										or contains(title, 'Kollegensuche')
										or contains(title, 'neue Jobs')
										or contains(title, 'neue Stellen')
										or contains(title, 'Jobs streichen')
										or contains(title, 'Jobabbau')
										or contains(title, 'arbeiter streiken')
									)=false
									and (
										contains(title, 'Euro')
										or contains(title, 'bond')
										or contains(title, 'Devise')
										or contains(title, 'Staatsanleihe')
										or contains(title, 'IWF')
									)=false
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
	</div>
    </xsl:template>
    
	<xsl:template name="PolitikEuropa">
		<strong>&gt; Politik - Europa</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik-Europa'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									and (
										contains(title, 'Euro')
										or contains(title, 'EZB')
										or contains(title, 'Merkozy')
										or contains(title, 'ESM')
										or contains(title, 'EFSF')
										or contains(title, 'EU')
										or contains(title, 'Griechen')
										or contains(title, 'Griechenland')
										or contains(title, 'Frankreich')
										or contains(title, 'Spanien')
										or contains(title, 'Italien')
										or contains(title, 'Berlusconi')
									)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(link, $searchFor)
									and (
										contains(title, 'Euro')
										or contains(title, 'EZB')
										or contains(title, 'Merkozy')
										or contains(title, 'ESM')
										or contains(title, 'EFSF')
										or contains(title, 'EU')
										or contains(title, 'Griechen')
										or contains(title, 'Griechenland')
										or contains(title, 'Frankreich')
										or contains(title, 'Spanien')
										or contains(title, 'Italien')
										or contains(title, 'Berlusconi')
									)
								])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Politik">
		<strong>&gt; Politik</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									and (
										contains(title, 'Euro')
										or contains(title, 'EZB')
										or contains(title, 'Merkozy')
										or contains(title, 'ESM')
										or contains(title, 'EFSF')
										or contains(title, 'EU')
										or contains(title, 'Griechen')
										or contains(title, 'Griechenland')
										or contains(title, 'Frankreich')
										or contains(title, 'Spanien')
										or contains(title, 'Italien')
										or contains(title, 'Berlusconi')
									)=false
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(link, $searchFor)
									and (
										contains(title, 'Euro')
										or contains(title, 'EZB')
										or contains(title, 'Merkozy')
										or contains(title, 'ESM')
										or contains(title, 'EFSF')
										or contains(title, 'EU')
										or contains(title, 'Griechen')
										or contains(title, 'Griechenland')
										or contains(title, 'Frankreich')
										or contains(title, 'Spanien')
										or contains(title, 'Italien')
										or contains(title, 'Berlusconi')
									)=false
								])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Technik">
		<strong>&gt; Technik</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/technik/'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'technik'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(link, $searchFor)
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Wissen">
		<strong>&gt; Wissen</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wissen/'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wissen'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(link, $searchFor)
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="SportFussball">
		<strong>&gt; Sport - Fussball</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/sport/fussball'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sportFussball'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(link, $searchFor)
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sport">
		<strong>&gt; Sport</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/sport'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									and contains(link, '/fussball')=false
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(link, $searchFor)
												and contains(link, '/fussball')=false
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
            						contains(link, '/wirtschaft')=false
                                    and contains(link, '/politik')=false
                                    and contains(link, '/technik')=false
                                    and contains(link, '/wissen')=false
                                    and contains(link, '/sport')=false
                                    ]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
        	
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
            									contains(link, '/wirtschaft')=false
                                                and contains(link, '/politik')=false
                                                and contains(link, '/technik')=false
                                                and contains(link, '/wissen')=false
			                                    and contains(link, '/sport')=false
                                            	]
											)"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
