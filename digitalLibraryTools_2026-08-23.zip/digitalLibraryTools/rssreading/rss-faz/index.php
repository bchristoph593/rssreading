<?php
	include("../uc/header_imports.php");
	
	$xslPath = "xsl-sheets/rss-faz.xsl";

	$portal = "faz";
		
	$url_newsengine = "http://localhost/digitalLibraryTools/newsengine"; 
	$url = $url_newsengine . "/ressourceBuilder.php?";
	$url .= "portal=".$portal;
		
	$rssPath = $url;

	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	@$newsPortal->doProcessing();
	
	@include("temp.php");
?>
