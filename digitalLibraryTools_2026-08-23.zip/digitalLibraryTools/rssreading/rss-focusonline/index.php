<?php
	include("../uc/header_imports.php");
	
	$xslPath = "xsl-sheets/rss-focusonline.xsl";
	$rssPath = "http://rss.focus.de/fol/XML/rss_folnews.xml";
	
	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	@include("temp.php");	
?>