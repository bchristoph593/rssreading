<?xml version="1.0" encoding="ISO-8859-1"?>
<!-- DWXMLSource="http://www.spiegel.de/schlagzeilen/index.rss" -->
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Handelsblatt | Schlagzeilen - crossreading</title>
                <link rel="shortcut icon" href="/images/favicon/fav-handelsblatt.ico" />
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            			
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("Handelsblatt");
						?</xsl:processing-instruction>
                    </div>
                                        
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                            <br />
                                                                                    
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                            Newsletter &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Finanzen</xsl:with-param>
                            <xsl:with-param name="sectionName">finanzen</xsl:with-param>
                            <xsl:with-param name="searchFor">.com/finanzen</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="Unternehmen" />
                        <br />
						<xsl:call-template name="PolitikEuropa" />
                        <br />
						<xsl:call-template name="Politik" />
                        <br />
						<xsl:call-template name="Technologie" />
                        <br />
						<xsl:call-template name="Sport-Fussball" />
                        <br />
						<xsl:call-template name="Sport" />
                        <br />
						<xsl:call-template name="Sonstige" />
                        <br />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
			</body>
			
		</html>	
	</xsl:template>
    	
	<xsl:template name="generateSection">
    	<xsl:param name="sectionTitle" />
    	<xsl:param name="sectionName" />
    	<xsl:param name="searchFor" />
    
		<strong>&gt; <xsl:value-of select="$sectionTitle" /></strong>
                
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
	<xsl:template name="Unternehmen">
		<strong>&gt; Unternehmen</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.com/unternehmen'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'unternehmen'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="EcoBusFin">
		<strong>&gt; Economy, Business &amp; Finance</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'Economy, Business &amp; Finance'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'ecobusfin'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(title, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="substring(title, 30)" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(title, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Technologie">
		<strong>&gt; Technologie</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.com/technologie'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'technologie'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>

        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="PolitikEuropa">
		<strong>&gt; Politik - Europa</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.com/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik-europa'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										and (
											contains(title, 'Griechenland')
											or contains(title, 'Frankreich')
											or contains(title, 'Sarkozy')
											or contains(title, 'Italien')
											or contains(title, 'Spanien')
											or contains(title, 'Spanisch')
											or contains(title, 'EZB')
											or contains(title, 'griechisch')
											or contains(title, 'Berlusconi')
										)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										and (
											contains(title, 'Griechenland')
											or contains(title, 'Frankreich')
											or contains(title, 'Sarkozy')
											or contains(title, 'Italien')
											or contains(title, 'Spanien')
											or contains(title, 'Spanisch')
											or contains(title, 'EZB')
											or contains(title, 'griechisch')
											or contains(title, 'Berlusconi')
										)
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>

        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Politik">
		<strong>&gt; Politik</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.com/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										and (
											contains(title, 'Griechenland')
											or contains(title, 'Frankreich')
											or contains(title, 'Sarkozy')
											or contains(title, 'Italien')
											or contains(title, 'Spanien')
											or contains(title, 'Spanisch')
											or contains(title, 'EZB')
											or contains(title, 'griechisch')
											or contains(title, 'Berlusconi')
										)=false
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										and (
											contains(title, 'Griechenland')
											or contains(title, 'Frankreich')
											or contains(title, 'Sarkozy')
											or contains(title, 'Italien')
											or contains(title, 'Spanien')
											or contains(title, 'Spanisch')
											or contains(title, 'EZB')
											or contains(title, 'griechisch')
											or contains(title, 'Berlusconi')
										)=false
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>

        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Newsticker">
		<strong>&gt; Newsticker</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.com/newsticker'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'newsticker'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Sport-Fussball">
		<strong>&gt; Sport - Fussball</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.com/sport/fussball'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport-fussball'"/>
		</xsl:variable>
        
		<div class="divLinkSection">
			<xsl:for-each select="item[
						contains(link, $searchFor)
						or contains(title, 'Fu&#223;ball')
						]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
							contains(link, $searchFor)
							or contains(title, 'Fu&#223;ball')
							])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sport">
		<strong>&gt; Sport</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport'"/>
		</xsl:variable>
        
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Handball')
									or contains(title, 'Tennis')
									or contains(title, 'Olympia')
									or contains(title, 'Paralympics')
									or contains(title, 'Funsport')
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(title, 'Handball')
									or contains(title, 'Tennis')
									or contains(title, 'Olympia')
									or contains(title, 'Paralympics')
									or contains(title, 'Funsport')
								])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
        
	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
        
		<div class="divLinkSection">
			<xsl:for-each select="item[
            							contains(link, '.com/unternehmen')=false
                                        and contains(link, '.com/finanzen')=false
                                        and contains(title, 'Economy, Business &amp; Finance')=false
                                        and contains(link, '.com/politik')=false
                                        and contains(link, '.com/technologie')=false
                                        and contains(link, '.com/newsticker')=false
                                        and (
                                        	contains(link, '.com/sport/fussball')
	                                        or contains(title, 'Fu&#223;ball')
                                        )=false
                                        and (
											contains(title, 'Handball')
											or contains(title, 'Tennis')
											or contains(title, 'Olympia')
											or contains(title, 'Paralympics')
											or contains(title, 'Funsport')
                                        )=false
										]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
                                		contains(link, '.com/unternehmen')=false
                                        and contains(link, '.com/finanzen')=false
                                        and contains(title, 'Economy, Business &amp; Finance')=false
                                        and contains(link, '.com/politik')=false
                                        and contains(link, '.com/technologie')=false
                                        and contains(link, '.com/newsticker')=false
                                        and (
	                                        contains(link, '.com/sport/fussball')
	                                        or contains(title, 'Fu&#223;ball')
                                        )=false
                                        and (
											contains(title, 'Handball')
											or contains(title, 'Tennis')
											or contains(title, 'Olympia')
											or contains(title, 'Paralympics')
											or contains(title, 'Funsport')
                                        )=false
                						])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
            
</xsl:stylesheet>
