<?php
	include("../uc/header_imports.php");
	
	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet("xsl-sheets/rss-handelsblatt.xsl");
	$newsPortal->setRSSFile("http://www.handelsblatt.com/contentexport/feed/top-themen");
	$newsPortal->doProcessing();
	
	@include("temp.php");
	
?>
