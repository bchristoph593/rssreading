<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

   <html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Handelsblatt | Schlagzeilen - crossreading</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Handelsblatt");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a><br></br></div></div><div class="divContent"><strong style="margin:3px;">
                            Newsletter &gt; Handelsblatt Online Top-Themen</strong><br></br><hr></hr><strong xmlns="">&gt; Finanzen</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'finanzen',
                    	'1',
                    	'17 Feb 2012 15:59:59',
                    	'http://www.handelsblatt.com/finanzen/boerse-maerkte/marktberichte/wall-street-us-boersen-uneinheitlich-vor-feiertag/6224182.html',
                    	'Wall Street: US-B�rsen uneinheitlich vor Feiertag',
                    	'Die M�rkte in New York rechnen mit einer Billigung des zweiten Hellas-Rettungspakets. Verunsichert waren die H�ndler allerdings vom bevorstehenden langen Wochenende.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'finanzen',
                    	'2',
                    	'17 Feb 2012 14:34:31',
                    	'http://www.handelsblatt.com/finanzen/boerse-maerkte/anlagestrategie/dax-pensionen-teure-versprechen/6223450.html',
                    	'Dax-Pensionen: Teure Versprechen',
                    	'Dax-Konzerne haben ihren Mitarbeitern gro�z�gige Pensionen versprochen. Doch was den Pension�ren zugute kommt, macht Aktion�re misstrauisch. Sie meiden Firmen, die hohe Pensionslasten in den B�chern stehen haben.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'finanzen',
                    	'3',
                    	'17 Feb 2012 15:54:00',
                    	'http://www.handelsblatt.com/finanzen/boerse-maerkte/anleihen/privatkunden-finanzagentur-sperrt-40-000-konten/6224510.html',
                    	'Privatkunden: Finanzagentur sperrt 40.000 Konten',
                    	'Die Finanzagentur des Bundes hat 40.000 Konten von Privatkunden gesperrt. Wegen der Ausweitung des Geldw�schegesetzes waren diese wiederholt vergeblich aufgerufen worden, beglaubigte Kopien von Dokumenten einzureichen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'finanzen',
                    	'4',
                    	'17 Feb 2012 17:52:58',
                    	'http://www.handelsblatt.com/finanzen/boerse-maerkte/marktberichte/boerse-frankfurt-dax-schliesst-auf-sechs-monatshoch/6221428.html',
                    	'B�rse Frankfurt: Dax schlie�t auf Sechs-Monatshoch',
                    	'Am letzten Handelstag der Woche  hat der deutsche Leitindex von der wachsenden Hoffnung der Anleger auf eine Rettung Griechenlands profitiert. Vor allem Finanzwerte waren gefragt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'finanzen',
                    	'5',
                    	'17 Feb 2012 12:41:35',
                    	'http://www.handelsblatt.com/finanzen/boerse-maerkte/anlegerakademie/zusatzversicherung-besser-vorsorgen-fuer-den-ernstfall/6190208.html',
                    	'Zusatzversicherung: Besser vorsorgen f�r den Ernstfall',
                    	'Die Menschen werden immer �lter und damit steigt auch die Zahl der Pflegebed�rftigen. Doch das Thema Pflege vernachl�ssigen viele. Dabei d�rfte das Ersparte in den wenigstens F�llen ausreichen. Wie man vorsorgt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'finanzen',
                    	'6',
                    	'17 Feb 2012 15:21:31',
                    	'http://www.handelsblatt.com/finanzen/rohstoffe-devisen/rohstoffe/oelpreis-schwacher-euro-macht-tanken-so-teuer-wie-nie/6222072.html',
                    	'�lpreis: Schwacher Euro macht Tanken so teuer wie nie',
                    	'Der Preis f�r Erd�l steigt kr�ftig. Die Verbraucher sp�ren es schon an der Tankstelle. Ein Liter Superbenzin kostet mehr als 1,60 Euro. Schuld daran ist jedoch nicht nur der Iran, sondern auch die Euro-Krise.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'finanzen',
                    	'6'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Unternehmen</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'1',
                    	'17 Feb 2012 18:32:19',
                    	'http://www.handelsblatt.com/unternehmen/handel-dienstleister/ups-bietet-fuer-tnt-kampf-der-paketboten-braun-will-orange-kaufen-/6225574.html',
                    	'UPS bietet f�r TNT: Kampf der Paketboten: Braun will Orange kaufen',
                    	'Der US-Fracht- und Paketdienst UPS will den vor allem in Europa pr�senten Rivalen TNT Express �bernehmen und hat knapp f�nf Milliarden geboten. Doch die Niederl�nder wehren sich.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'2',
                    	'17 Feb 2012 21:18:25',
                    	'http://www.handelsblatt.com/unternehmen/industrie/windenergie-haengepartie-um-offshore-windparks/6223170.html',
                    	'Windenergie: H�ngepartie um Offshore-Windparks',
                    	'Bis 2020 will die Bundesregierung durch Offshore-Windparks rund 10.000 Megawatt Energie generieren, doch der Zeitplan ist gef�hrdet. F�r Verz�gerungen sorgen vor allem gro�e Engp�sse in der Netzanbindung.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'3',
                    	'17 Feb 2012 21:21:24',
                    	'http://www.handelsblatt.com/unternehmen/banken/chef-der-berenberg-bank-wir-haben-nicht-mal-anleihen-aus-frankreich/6206870.html',
                    	'Chef der Berenberg Bank: "Wir haben nicht mal Anleihen aus Frankreich"',
                    	'In seinem Ausbau des Investment-Bankings sieht Hans-Walter Peters, Chef der Berenberg Bank, kein Risiko. Trotz Kritik einiger Mitbewerber ist Peters �berzeugt: Seine Bank hat sich eine gute Position erarbeitet.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'4',
                    	'18 Feb 2012 20:01:10',
                    	'http://www.handelsblatt.com/unternehmen/industrie/autobauer-hilfe-fuer-die-helferlein/6212514.html',
                    	'Autobauer: Hilfe f�r die Helferlein',
                    	'Die Produktionsengp�sse nach der Katastrophe von Fukushima waren den Automobilkonzernen eine Lehre. Das Verh�ltnis zu ihren Lieferanten ist heute enger denn je.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'5',
                    	'17 Feb 2012 18:59:00',
                    	'http://www.handelsblatt.com/unternehmen/handel-dienstleister/neckermann-der-schrittweise-abschied-vom-kataloggeschaeft/6225692.html',
                    	'Neckermann: Der schrittweise Abschied vom Kataloggesch�ft',
                    	'Der Versandhandel bei Neckermann verlagert sich immer mehr ins Internet. Aus diesem Grund wird der klassische gedruckte Katalog schrittweise verkleinert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'6',
                    	'17 Feb 2012 12:42:47',
                    	'http://www.handelsblatt.com/unternehmen/handel-dienstleister/urlaub-in-krisenzeiten-wie-gefaehrlich-die-unruhen-fuer-griechenland-urlauber-sind/6212876.html',
                    	'Urlaub in Krisenzeiten: Wie gef�hrlich die Unruhen f�r Griechenland-Urlauber sind',
                    	'Krawalle, Demonstrationen und Streiks: War\'s das mit dem Sommerurlaub in Griechenland? Viele Urlauber sind verunsichert - angesichts der Situation in dem beliebten Ferienziel und m�glicher Beeintr�chtigungen auf Reisen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'7',
                    	'17 Feb 2012 15:20:59',
                    	'http://www.handelsblatt.com/unternehmen/handel-dienstleister/flughafen-frankfurt-gewerkschaft-erhoeht-im-tarifstreit-die-forderungen/6224158.html',
                    	'Flughafen Frankfurt: Gewerkschaft erh�ht im Tarifstreit die Forderungen',
                    	'Der Tarifkonflikt am Frankfurter Flughafen gewinnt an Sch�rfe. Die Parteien scheinen heillos zerstritten. Beide Seiten sehen den Ball auf der jeweils anderen Seite - und glauben einander nichts mehr.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'unternehmen',
                    	'7'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Politik</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'politik',
                    	'1',
                    	'17 Feb 2012 16:41:11',
                    	'http://www.handelsblatt.com/politik/deutschland/wulff-nachfolge-wer-darf-hier-bald-einziehen/6224180.html',
                    	'Wulff-Nachfolge: Wer darf hier bald einziehen?',
                    	'Der Bundespr�sident r�umt das Schloss Bellevue - und hinterl�sst der Kanzlerin ein dickes Problem. Unter hohem Zeitdruck muss sie einen konsensf�higen Kandidaten finden. Eine Krisensitzung jagt die n�chste.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'2',
                    	'17 Feb 2012 17:05:25',
                    	'http://www.handelsblatt.com/politik/deutschland/joachim-gauck-der-demokratie-streiter/6224882.html',
                    	'Joachim Gauck: Der Demokratie-Streiter',
                    	'Joachim Gauck erntete schon 2010 partei�bergreifende Sympathien. Nun steht der Mecklenburger Pfarrer wieder in vorderen Reihe, wenn es um die Wulff-Nachfolge geht. Handelsblatt-Online wirft ein Blick in sein neues Buch.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'3',
                    	'17 Feb 2012 22:17:12',
                    	'http://www.handelsblatt.com/politik/deutschland/umfrage-zur-nachfolge-des-bundespraesidenten-schlechte-karten-fuer-kabinettsmitglieder/6225992.html',
                    	'Umfrage zur Nachfolge des Bundespr�sidenten: Schlechte Karten f�r Kabinettsmitglieder',
                    	'Der R�cktritt des Bundespr�sidenten hat nach Ansicht der H�lfte der Deutschen keine Folgen f�r die Regierung. Ein Kabinettsmitglied als Staatsoberhaupt k�nnen sich aber nur wenige vorstellen - auch SPD und Gr�ne nicht.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'4',
                    	'17 Feb 2012 13:08:00',
                    	'http://www.handelsblatt.com/politik/deutschland/wie-geht-es-jetzt-weiter-die-wichtigsten-fragen-zum-amt-des-bundespraesidenten/6222224.html',
                    	'Wie geht es jetzt weiter?: Die wichtigsten Fragen zum Amt des Bundespr�sidenten',
                    	'Der R�cktritt von Christian Wulff er�ffnet neue Fragen. Wie geht es jetzt weiter?  Wer w�hlt den Nachfolger? Was bekommt Wulff nach seinem R�cktritt? Handelsblatt Online beantwortet die wichtigsten Fragen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'5',
                    	'17 Feb 2012 12:30:33',
                    	'http://www.handelsblatt.com/politik/deutschland/kampf-um-bellevue-die-heissesten-kandidaten-fuer-die-wulff-nachfolge/6060392.html',
                    	'Kampf um Bellevue: Die hei�esten Kandidaten f�r die Wulff-Nachfolge',
                    	'Nach dem R�cktritt Christian Wulffs geht die Debatte um seinen Nachfolger im Schloss Bellevue in die entscheidende Phase. Welche Namen im Spiel sind.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'6',
                    	'17 Feb 2012 11:15:00',
                    	'http://www.handelsblatt.com/politik/deutschland/wulffs-letzter-auftritt-das-abrupte-ende-eines-quaelend-langen-dramas/6222298.html',
                    	'Wulffs letzter Auftritt: Das abrupte Ende eines qu�lend langen Dramas',
                    	'Getrieben von den Medien und der Staatsanwaltschaft trat Christian Wulff an das Pult des Pr�sidialamtes - ein letztes Mal. Nach dem schnellen Abgang hat nun die Kanzlerin das Problem: In 30 Tagen muss Ersatz her.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'7',
                    	'17 Feb 2012 23:29:00',
                    	'http://www.handelsblatt.com/politik/international/us-arbeitsmarkt-regierung-rechnet-mit-staerkerem-stellenaufbau/6226130.html',
                    	'US-Arbeitsmarkt: Regierung rechnet mit st�rkerem Stellenaufbau',
                    	'Im Januar ist die US-Arbeitslosenquote auf den niedrigsten Stand seit fast drei Jahren gefallen. Auch die Aussichten f�r die n�chsten Monate sind positiv. Das k�nnte Obama bei der Wiederwahl zugute kommen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'8',
                    	'17 Feb 2012 15:28:09',
                    	'http://www.handelsblatt.com/politik/international/zitate-der-woche-wir-brauchen-im-schloss-bellevue-keinen-heiligen/6222732.html',
                    	'Zitate der Woche: "Wir brauchen im Schloss Bellevue keinen Heiligen"',
                    	'Christian Wulff beschreibt, was f�r einen Pr�sidenten Deutschland braucht, Griechenlands Regierungschef Lucas Papademos will den Staat neu gr�nden und die K�lner Karnevalisten planen ihre Rosenmontags-Wagen um.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'9',
                    	'17 Feb 2012 18:13:00',
                    	'http://www.handelsblatt.com/politik/deutschland/schuldenbremse-schaeuble-will-defizit-schneller-senken/6225544.html',
                    	'Schuldenbremse: Sch�uble will Defizit schneller senken',
                    	'Bundesfinanzminister Wolfgang Sch�uble (CDU) will die Vorgaben der gesetzlichen Schuldenbremse fr�her erreichen als geplant. So soll die Neuverschuldung zwei Jahre fr�her auf acht Milliarden Euro gesenkt werden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'10',
                    	'17 Feb 2012 21:43:00',
                    	'http://www.handelsblatt.com/politik/international/zoellick-nachfolge-weltbank-will-bis-april-neuen-praesidenten-suchen/6225990.html',
                    	'Zoellick-Nachfolge: Weltbank will bis April neuen Pr�sidenten suchen',
                    	'Bis Mitte April will die Weltbank einen Nachfolger f�r Robert Zoellick gefunden haben. Als Anw�rter f�r den Chefposten werden unter anderem Hillary Clinton und Timothy Geithner genannt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'11',
                    	'17 Feb 2012 19:40:00',
                    	'http://www.handelsblatt.com/politik/international/sozialabgaben-gesetz-demokraten-und-republikaner-finden-kompromiss/6225756.html',
                    	'Sozialabgaben-Gesetz: Demokraten und Republikaner finden Kompromiss',
                    	'Harmonie im US-Kongress: Die zerstrittenen Parteien haben ein Sozialabgaben-Gesetz verl�ngert, um das es zuletzt einen heftigen politischen Kampf gab. Die Republikaner wollten nicht wieder zu Buhm�nnern werden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'12',
                    	'17 Feb 2012 18:27:00',
                    	'http://www.handelsblatt.com/politik/international/euro-rettungsfonds-teilkaskoversicherung-steht-bereit/6225580.html',
                    	'Euro-Rettungsfonds: Teilkaskoversicherung steht bereit',
                    	'Die Teilkaskoversicherung f�r den Euro-Rettungsfonds EFSF steht. Neu ausgegebene Anleihen von Euro-Mitgliedsstaaten werden so teilweise abgesichert. Durch die Hebelwirkung gewinnt der EFSF an Feuerkraft.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'politik',
                    	'12'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Technologie</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'technologie',
                    	'1',
                    	'17 Feb 2012 12:49:34',
                    	'http://www.handelsblatt.com/technologie/it-tk/it-internet/mac-os-x-10-8-was-apples-mountain-lion-neues-bietet/6222022.html',
                    	'Mac OS X 10.8: Was Apples "Mountain Lion" Neues bietet',
                    	'Apples kommender Windows-8-Konkurrent "Mountain Lion" bietet mehr als rein kosmetische Ver�nderungen gegen�ber der derzeit aktuellen Version "Lion". Wir zeigen, was Mac OS X 10.8 alles kann.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'technologie',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport - Fussball</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sport-fussball',
                    	'1',
                    	'17 Feb 2012 22:11:00',
                    	'http://www.handelsblatt.com/sport/fussball/nachrichten/bundesliga-22-spieltag-auch-mit-babbel-reicht-es-nur-zum-remis/6226006.html',
                    	'Bundesliga, 22. Spieltag: Auch mit Babbel reicht es nur zum Remis',
                    	'Auch mit dem neuen Trainer Markus Babbel bleibt die TSG Hoffenheim eine Remis-Mannschaft. Gegen den FSV Mainz 05 reichte es nur zu einem 1:1 (1:1). Und selbst die beiden Tore gingen aufs Konto der G�ste.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sport-fussball',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'17 Feb 2012 12:17:51',
                    	'http://www.handelsblatt.com/meinung/kommentare/kommentar-der-praesident-tritt-ab-es-lebe-der-praesident/6223064.html',
                    	'Kommentar: Der Pr�sident tritt ab, es lebe der Pr�sident',
                    	'Christian Wulff ist Geschichte. Drei Minuten haben gereicht, um ein unw�rdiges Schauspiel zu beenden, das viel zu lange gedauert hat. Nun ist der Weg frei f�r einen Nachfolger. Der braucht alles - aber kein Parteibuch.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'17 Feb 2012 17:46:39',
                    	'http://www.handelsblatt.com/meinung/kolumnen/kurz-und-schmerzhaft/kolumne-dutschke-spricht-merkel-kann-sich-keinen-fehltritt-mehr-leisten/6224214.html',
                    	'Kolumne: Dutschke spricht: Merkel kann sich keinen Fehltritt mehr leisten',
                    	'Bundeskanzlerin Angela Merkel hat das Amt des Bundespr�sidenten wie kein Kanzler vor ihr missbraucht. Sie hat nichts aus dem K�hler-Debakel gelernt. Nach dem R�cktritt von Christian Wulff bl�st ihr der Wind ins Gesicht.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'01 Jan 1972 00:00:00',
                    	'http://www.handelsblatt.com/themen/Top-Thema',
                    	'Lorem ipsum: Debatte um Schuldenschnitt in der letzten Runde',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'17 Feb 2012 19:19:30',
                    	'http://www.handelsblatt.com/meinung/kolumnen/was-vom-tage-bleibt/was-vom-tage-bleibt-ein-amt-schafft-sich-ab/6225722.html',
                    	'Was vom Tage bleibt: Ein Amt schafft sich ab',
                    	'Wulffs Nachfolger wird es schwer haben zu beweisen, wof�r das Amt gut ist. Und der Streik in Frankfurt ist erstmal vorbei, weil Wochenende ist.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'17 Feb 2012 18:09:05',
                    	'http://www.handelsblatt.com/video/video-news/wirtschaft/zukunft-nach-insolvenz-schlecker-koennte-komplett-verschwinden/6223732.html',
                    	'Wirtschaft: Mitarbeiter k�mpfen um Marke Schlecker',
                    	'Die Zukunft von Schlecker ist ungewiss, die Marke k�nnte sogar komplett verschwinden. Eine kleine Gruppe von Mitarbeitern ruft nun zu einer Image-Offensive auf.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'5'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>

