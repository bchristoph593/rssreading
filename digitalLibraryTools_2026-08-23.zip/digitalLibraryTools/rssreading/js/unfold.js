// JavaScript Document
	function toggleSummary(sectionName, nr) {
		var summaryImg = 'summary_'+ sectionName+ '_'+ nr+ '_img';
		var summaryDiv = 'summary_'+ sectionName+ '_'+ nr;
		
		// alert(summaryImg);
		
		var imgElement = document.getElementById(summaryImg);
		var imgElementSrc = imgElement.src;
		
		if( imgElementSrc.match(/arrow-right.png/) ) {
			imgElement.src = '../images/arrow-down.png';
			
		} else if( imgElementSrc.match(/arrow-down.png/) ) {
			imgElement.src = '../images/arrow-right.png';
		}
		
		// alert(summaryDiv);
		
		var divSummaryElement = document.getElementById(summaryDiv);
		divSummaryElementClass = divSummaryElement.className;
		
		if(divSummaryElementClass == 'divArticleSummary') {
			divSummaryElement.className = 'divArticleSummaryUnfolded';
			
		} else if( divSummaryElementClass == 'divArticleSummaryUnfolded' ) {
			divSummaryElement.className = 'divArticleSummary';
		}
		
		// ID-Attribute for SubmitBtn-TableRow: 'submitRow_<sectionName>_<nr>'
		var submitRowId = "submitRow_"+ sectionName+ "_"+ nr;
		var submitRowDisplay = document.getElementById(submitRowId).style.display;
		
		if(submitRowDisplay == "none") {
			document.getElementById(submitRowId).style.display = "block";
			// alert("focus");
			// document.getElementById(submitRowId).focus();
			
		} else if(submitRowDisplay == "block") {
			document.getElementById(submitRowId).style.display = "none";
		}
		
		// alert(divSummaryElement.className);
	}






	function outline(ID) {
		if(document.all(ID).style.display='block') {
			document.all(ID).style.display='none';
		}
		else
		{
			document.all(ID).style.display='block';
		}
	}

	function blocking(nr)
	{
		if (document.getElementById)
		{
			// alert("elementById");
			// alert('summary_' + nr);
			// alert('summary_' + nr + '_img');
			
			vista = (document.getElementById('summary_' + nr).style.display == 'none') ? 'block' : 'none';
			document.getElementById('summary_' + nr).style.display = vista;
			
			if(vista == 'block') {
				document.getElementById('summary_' + nr + '_img').src = '/images/arrow-down.png';
				
			} else {
				document.getElementById('summary_' + nr + '_img').src = '/images/arrow-right.png';
			}
			
		}
		else if (document.layers)
		{
			// alert("layers");
			
			current = (document.layers['summary_' + nr].display == 'none') ? 'block' : 'none';
			
			document.layers['summary_' + nr].display = current;
			document.layers['summary_' + nr].name = "LAYER";
			
			if(current == 'block') {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-down.png';
				
			} else {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-right.png';
			}
			
		}
		else if (document.all)
		{
			// alert("all");
			
			current = (document.all['summary_' + nr].style.display == 'none') ? 'block' : 'none';
			document.all['summary_' + nr].style.display = current;
			document.all['summary_' + nr].name = "ALL";
			
			if(current == 'block') {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-down.png';
				
			} else {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-right.png';
			}

		}
	}

	function doBlocking(nr)
	{
		if (document.getElementById)
		{
			// alert("elementById");
			// alert('summary_' + nr);
			// alert('summary_' + nr + '_img');
			
			vista = 'block';
			document.getElementById('summary_' + nr).style.display = vista;
			
			if(vista == 'block') {
				document.getElementById('summary_' + nr + '_img').src = '/images/arrow-down.png';
				
			} else {
				document.getElementById('summary_' + nr + '_img').src = '/images/arrow-right.png';
			}
			
		}
		else if (document.layers)
		{
			// alert("layers");
			
			current = 'block';
			
			document.layers['summary_' + nr].display = current;
			document.layers['summary_' + nr].name = "LAYER";
			
			if(current == 'block') {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-down.png';
				
			} else {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-right.png';
			}
			
		}
		else if (document.all)
		{
			// alert("all");
			
			current = 'block';
			document.all['summary_' + nr].style.display = current;
			document.all['summary_' + nr].name = "ALL";
			
			if(current == 'block') {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-down.png';
				
			} else {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-right.png';
			}

		}
	}

	function doUnblocking(nr)
	{
		if (document.getElementById)
		{
			// alert("elementById");
			// alert('summary_' + nr);
			// alert('summary_' + nr + '_img');
			
			vista = 'none';
			document.getElementById('summary_' + nr).style.display = vista;
			
			if(vista == 'block') {
				document.getElementById('summary_' + nr + '_img').src = '/images/arrow-down.png';
				
			} else {
				document.getElementById('summary_' + nr + '_img').src = '/images/arrow-right.png';
			}
			
		}
		else if (document.layers)
		{
			// alert("layers");
			
			current = 'none';
			
			document.layers['summary_' + nr].display = current;
			document.layers['summary_' + nr].name = "LAYER";
			
			if(current == 'block') {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-down.png';
				
			} else {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-right.png';
			}
			
		}
		else if (document.all)
		{
			// alert("all");
			
			current = 'none';
			document.all['summary_' + nr].style.display = current;
			document.all['summary_' + nr].name = "ALL";
			
			if(current == 'block') {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-down.png';
				
			} else {
				document.images['summary_' + nr + '_img'].src = '/images/arrow-right.png';
			}

		}
	}
