// JavaScript Document
function visit(id) {
	var complexId = id;
	var sectionName;
	
	pos = complexId.indexOf('_');
	sectionName = complexId.substring(0, pos);
	
	pos_begin = pos+1;
	//pos_end = pos_begin+1;
	pos_end = complexId.length;
	
	nr = complexId.substring(pos_begin, pos_end);
	
	// alert(sectionName);
	// alert(complexId+ " "+ nr );
	
	content = document.getElementById("divContainer_"+id).innerHTML;
	document.getElementById("divContainer_"+id).innerHTML = "";
	document.getElementById("divContainerVisited_"+id).innerHTML = content;

	var containerVisited = document.getElementById("divContainerVisited_"+id);
	
	document.getElementById("divContainerVisited_"+id).getElementsByClassName("divArticleLink")[0].removeAttribute("onclick");
	document.getElementById("divContainerVisited_"+id).getElementsByClassName("divArticleLink")[0].getElementsByTagName("a")[0].removeAttribute("onclick");
	
	document.getElementById("divContainerVisited_"+sectionName).style.display = "block";

	var strSubmitBtn = "submitBtn_"+id;
	// document.getElementById(strSubmitBtn).removeAttribute("onclick");
	// document.getElementById(strSubmitBtn).onclick = "toggleSummary(\''.$sectionName.'\', \''.$position.'\');";
	// toggleSummary('ausland', '4')
	document.getElementById(strSubmitBtn).setAttribute( "onClick", "javascript: toggleSummary(\'"+ sectionName+"\', \'"+nr +"\');" );
	
	document.getElementById(strSubmitBtn).value = "Collect ArticleItem to BrowsingSession";
	
}

function getStyle(x, styleProp) {
    if (x.currentStyle)
      var y = x.currentStyle[styleProp];
    else if (window.getComputedStyle)
      var y = document.defaultView.getComputedStyle(x, null).getPropertyValue(styleProp);
    return y;
  }
  
function displayVisited() {
	var arrArticleLink = document.getElementsByClassName("divArticleLink");
	
	for(var i=0; i<arrArticleLink.length; i++) {
		var anchor = arrArticleLink[i].getElementsByTagName("a")[0];
		
		// For security reasons, some lookup for visited anchor is not possible.;
		// console.log(arrArticleLink[i].getElementsByTagName("a:visited")[0] );
		
		var color = getStyle(anchor, "text-decoration-color");
		// arrArticleLink[i].getElementsByTagName("a")[0].style.border = '1px solid black';
		
		// var color = document.defaultView.getComputedStyle(anchor, null).getPropertyValue('color');       
		console.log("anchor num: "+ i + "; url: "+ anchor.href + "; color: "+color);
		
		// check for visited
		if (color == "rgb(0, 0, 255)") {           
			console.log(anchor.href + ' has been visited');
}		
		}
}