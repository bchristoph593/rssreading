// JavaScript Document
function lookupArticleLinkAmount() {
	// Further UseCase:
	// - Lookup at LocalStorage, if linkUrl is known there.;
	// - If linkUrl is known, invoke 'click'-function
				//     to move 'divArticleItem' to 'divContainerVisited_<section>_<position>'.;			
				
	// Actually:
	// + (1) Visit the actual link:
	//   - Move div 'divArticleItem'
	//      to container 'divContainerVisited_sonstige_<position>'.;
	//   - Open textWebResourceUrl in new webBrowserTab.;
	// + (2) Move div:
	//   - Add 'onlick'-invocation for div 'divArticleLink'.;
	//     -> do not open the div-url in a new webBrowserTab.;
				
	var arrArticleLink = document.getElementsByClassName('divArticleLink');
	// alert('links: '+ arrArticleLink.length);
	
	for(var i=0; i<arrArticleLink.length; i++) {
		var arrAnchor = arrArticleLink[i].getElementsByTagName('a');
		var url = arrAnchor[0].href;
	
		// Lookup url in LocalStorage:
		var retValue = wndLocalStorage_lookupArticleLinkUrl(url);
					
		if(retValue == true) {
			// console.log('ArticleLink known: '+ retValue + '; url: '+ url);
						
			arrArticleLink[i].click();
		}
	}
}


function wndLocalStorage_lookupArticleLinkUrl(url) {
	// console.log(url);
	
	var itemKey = 'urlLen_'+ url.length;
	var itemValue = JSON.parse(localStorage.getItem(itemKey) );
	
	if(itemValue === null) {
		return false;
		
	} else {
		var arrDocUrl = JSON.parse(localStorage.getItem(itemKey));
		
		// console.log("searchfor url:'"+ url+ "'");
		// console.log("(key, value): ("+ itemKey+ ", '"+ itemValue+  "'");
		
		// check if url is known in localStorage
		var urlFound = false;
		for(var i = 0; i <arrDocUrl.length; i++) {
	
			if(arrDocUrl[i].length == url.length) {
				if(arrDocUrl[i] === url) {
					urlFound = true;
					
					console.log("Url found in localStorage: "+url);
					
					return urlFound;
					
				} else {
					urlFound = false;
				}
				
				// alert("compare ''"+ arrDocUrl+ "'; "+ "'"+ url+ "'");
				// alert(url === arrDocUrl[i]);
			}
			
		}
		
		if(urlFound == true) {
			// console.log('ArticleLink known in localStorage: '+ url);
			
			return true;
			
		} else {
			console.log("Url unknown in localStorage.");
			
			return false;
		}
	}
}


function wndLocalStorage_appendArticleLinkUrl(url) {
	// alert('Append url to wndLocalStorage');
	// alert(url);
	// alert("url-length: "+ url.length);
	
	var itemKey = 'urlLen_'+ url.length;
	var itemValue = JSON.parse(localStorage.getItem(itemKey) );
	
	// alert('Append: (Key: '+ itemKey+ ', value: '+ itemValue+ ')' );
	
	if(itemValue === null) {
		// alert('key not found in wndLocalStorage');
		
		var arrDocUrl = [];
		arrDocUrl[0] = url;
		
		localStorage.setItem(itemKey, JSON.stringify(arrDocUrl) );
		
	} else {
		// alert('key known in wndLocalStorage: '+ itemKey);
		
		var arrDocUrl = JSON.parse(localStorage.getItem(itemKey));
		
		// alert(arrDocUrl.length+ " urls found.");
		
		var urlFound = false;
		for(var i = 0; i <arrDocUrl.length; i++) {
			if(arrDocUrl[i].length == url.length) {
				if(arrDocUrl[i] === url) {
					urlFound = true;
					
					return urlFound;
				}
			}
		}
		
		if(urlFound == false) {
			// append new value to the array
			arrDocUrl.push(url );
			localStorage.setItem(itemKey, JSON.stringify(arrDocUrl) );
			
			// console.log(arrDocUrl);
			
			return urlFound;
		}
	}
}