<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
        
        <meta name="ROBOTS" content="All" />
        <meta name="revisit-after" content="2 days" />
        <meta name="google-site-verification" content="1g3uRVPHtVvDzElMh-vWuoHbEq7Wf3ISIxSrIW78Uy8" />	
                                
        <title>
        	&Uuml;bersicht
        	- rssreading
        </title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />                
	</head>
	
	<body>
		<script type="text/javascript" src="js/wz_tooltip.js"></script>
		<script type="text/javascript" src="js/unfold.js"></script>
                
		<div class="divContainer">
			<div style="display:block;">
            	<strong>&Uuml;bersicht</strong>
                <hr><br>                
			</div>
                    
			<div class="divMenuIndex">
				<div class="">
					<strong>
                    	Navigation
                    </strong>
				</div>
                        
				<hr />
                        
				<div class="divMenuLinks">
					<a class="linkSelected" href="index.php">&gt; Alle Portale</a>
					<br />
				</div>
			</div>
			
			<div class="divContent">
				<strong>
					&nbsp;
				</strong>
				
				<br />
				<hr />
				
                <div class="divPortal" style="float:left">
                	<a href="readingSession/">
                		<img style="border:0px;" width="55" src="images/readingSession_03.jpg" title="Aktuelle Webnews-Schlagzeilen">
                    </a>
                </div>
                <div class="divPortal" style="float:left">
                	<a href="rss-tagesschau/">
                		<img style="border:0px;" width="55" src="images/tagesschau-logo.jpg" title="Aktuelle Schlagzeilen aus dem Online- Angebot der Tagesschau">
                    </a>
                </div>
                <div class="divPortal" style="float:left;">
                	<a href="rss-zeit/">
                		<img style="border:0px;" width="55" src="images/zeit-logo.jpg" title="Aktuelle Schlagzeilen aus dem Online- Angebot der ZEIT">
                    </a>
				</div>
				
				<!--
                <div class="divPortal" style="float:left;">
                	<a href="rss-faz/">
                		<img style="border:0px;" width="55" src="images/faz-logo.jpg" title="Aktuelle Schlagzeilen aus dem Online- Angebot der Frankfurter Allgemeinen Zeitung">
                    </a>
				</div>
                <div class="divPortal" style="float:left;">
                	<a href="rss-spiegel/">
                		<img style="border:0px;" width="55" src="images/spiegelonline-logo.jpg" title="Aktuelle Schlagzeilen aus dem Online- Angebot des SPIEGEL">
                    </a>
				</div>
                <div class="divPortal" style="float:left;">
                	<a href="rss-ntv/">
                		<img style="border:0px;" width="55" src="images/ntv-logo.jpg" title="Aktuelle Schlagzeilen aus dem Online- Angebot von N-TV">
                    </a>
				</div>
                <div class="divPortal" style="float:left">
                	<a href="rss-golem/">
                		<img style="border:0px;" width="55" src="images/golem-logo.jpg" title="Aktuelle Schlagzeilen aus dem Online- Angebot der Golem Redaktion">
                    </a>
                </div>
                <div class="divPortal" style="float:left">
                	<a href="rss-sport1/">
                		<img style="border:0px;" width="55" src="images/sport1-logo.jpg" title="Aktuelle Schlagzeilen aus dem Online- Angebot von Sport1">
                    </a>
                </div>
                <div class="divPortal" style="float:left">
                	<a href="rss-financialtimes/">
                		<img style="border:0px;" width="55" src="images/ftd-logo.png" title="Aktuelle Schlagzeilen aus dem Online- Angebot der Financial Times Deutschland">
                    </a>
                </div>
                <div class="divPortal">
                	<a href="rss-handelsblatt/">
                		<img style="border:0px;" width="55" src="images/handelsblatt-logo.png" title="Aktuelle Schlagzeilen aus dem Online- Angebot des Handelsblatts">
					</a>
                </div>
				-->
			</div>
            <div style="clear:both"></div>
		</div>
	</body>
</html>
