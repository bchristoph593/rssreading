<?php
	include("../uc/header_imports.php");
	
	$xslPath = "xsl-sheets/rss-n24.xsl";
	$rssPath = "http://www.n24.de/2/index.rss";
	
	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	@include("temp.php");	
?>