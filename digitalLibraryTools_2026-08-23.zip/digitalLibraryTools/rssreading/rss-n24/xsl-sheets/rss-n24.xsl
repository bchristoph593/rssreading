<?xml version="1.0" encoding="ISO-8859-1"?>
<!-- DWXMLSource="http://www.spiegel.de/schlagzeilen/index.rss" -->
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>RSS N24 | Schlagzeilen</title>
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            			
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("N24");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                            <br />
                                                                                    
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong>
                            RSS Newsletter: <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                                                                                                
                        <strong>&gt; Sonstige</strong>
                        <div class="divLinkSection">
                            <xsl:for-each select="item">
                                <xsl:if test="contains(link, '.de/politik')=false
                                                ">
                                    <div class="divArticleItem">
                                        <div class="divArticleDate">
                                            <xsl:value-of select="substring(pubDate, 6, 20)" />
                                        </div>
                                        <div class="divShowSummary">
                                            <xsl:processing-instruction name="php">
                                                getShowSummary(<xsl:value-of select="position()"/>);
                                            ?</xsl:processing-instruction>
                                                                                    
                                        </div>
                                        <div class="divArticleLink">
                                        	<xsl:processing-instruction name="php">
                                            	getAnker('<xsl:value-of select="link" />', '<xsl:value-of select="title" />');
											?</xsl:processing-instruction>
                                            
                                            <xsl:processing-instruction name="php">
                                                getSummary02('<xsl:value-of select="position()"/>',
                                                            '<xsl:value-of select="description"/>');
                                            ?</xsl:processing-instruction>
                                            
                                        </div>
                                        <div style="clear:both"></div>

                                    </div>
                                    
                                </xsl:if>	
                            </xsl:for-each>
                        </div>
                        <div style="clear:both">
                        </div>
                        
                        <br />
                                                                        
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
			</body>
			
		</html>	
	</xsl:template>
    	
</xsl:stylesheet>
