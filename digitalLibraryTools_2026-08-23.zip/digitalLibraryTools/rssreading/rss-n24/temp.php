<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>RSS N24 | Schlagzeilen</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("N24");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a><br></br></div></div><div class="divContent"><strong>
                            RSS Newsletter: 
N24 - Wir kommen zur Sache.
</strong><br></br><hr></hr><strong>&gt; Sonstige</strong><div class="divLinkSection"><div class="divArticleItem"><div class="divArticleDate"> 16 Nov 2011 19:40:2</div><div class="divShowSummary"><?php 
                                                getShowSummary(1);
                                            ?></div><div class="divArticleLink"><?php 
                                            	getAnker('
http://www.N24.de/news/newsitem_7424232.html
', '
Neonazi-Morde - 
Panne auch bei Ermittlungen in Heilbronn?
');
											?><?php 
                                                getSummary02('1',
                                                            '
Offenbar haben die Ermittler auch bei der Fahndung nach dem Mord an der Heilbronner Polizistin gepatzt. Ein Wohnmobil, das auf Holger G. zugelassen war, fiel anscheindend durchs Raster.
');
                                            ?></div><div style="clear:both"></div></div><div class="divArticleItem"><div class="divArticleDate"> 16 Nov 2011 18:54:1</div><div class="divShowSummary"><?php 
                                                getShowSummary(2);
                                            ?></div><div class="divArticleLink"><?php 
                                            	getAnker('
http://www.N24.de/news/newsitem_7423748.html
', '
M�rkte beruhigen sich - 
Monti vereidigt - Vertrauen f�r Papademos
');
											?><?php 
                                                getSummary02('2',
                                                            '
In Italien und Griechenland etablieren sich neue Regierungen, die M�rkte reagieren mit etwas mehr Ruhe. Doch die Krise ist noch nicht �berstanden, mahnt Kanzlerin Angela Merkel und dr�ngt zur Eile.
');
                                            ?></div><div style="clear:both"></div></div><div class="divArticleItem"><div class="divArticleDate"> 16 Nov 2011 21:29:1</div><div class="divShowSummary"><?php 
                                                getShowSummary(3);
                                            ?></div><div class="divArticleLink"><?php 
                                            	getAnker('
http://www.N24.de/news/newsitem_7424569.html
', '
Assad v�llig isoliert - 
Arabische Liga schlie�t Syrien endg�ltig aus
');
											?><?php 
                                                getSummary02('3',
                                                            '
Um Syriens Regime von Baschar al-Assad wird es einsam. Die Arabische Liga beschloss den endg�ltigen Ausschluss des Landes. Indessen kommt es zu immer gewagteren Aktionen syrischer Deserteure.
');
                                            ?></div><div style="clear:both"></div></div><div class="divArticleItem"><div class="divArticleDate"> 16 Nov 2011 18:49:5</div><div class="divShowSummary"><?php 
                                                getShowSummary(4);
                                            ?></div><div class="divArticleLink"><?php 
                                            	getAnker('
http://www.N24.de/news/newsitem_7424207.html
', '
Gigantische Magnetfelder - 
Forscher entdecken stellare Geburtshelfer
');
											?><?php 
                                                getSummary02('4',
                                                            '
Astronomen aus Heidelberg haben eine bahnbrechende Entdeckung gemacht: Sie haben an einer Nachbargalaxie der Milchstra�e zeigen k�nnen, wie Riesenmagnetfelder neue Sterne entstehen lassen.
');
                                            ?></div><div style="clear:both"></div></div><div class="divArticleItem"><div class="divArticleDate"> 16 Nov 2011 20:57:0</div><div class="divShowSummary"><?php 
                                                getShowSummary(5);
                                            ?></div><div class="divArticleLink"><?php 
                                            	getAnker('
http://www.N24.de/news/newsitem_7424532.html
', '
Neuer Job f�r van Gaal - 
"Tulpengeneral" wird Ajax-Generaldirektor
');
											?><?php 
                                                getSummary02('5',
                                                            '
Nach seinem Aus beim FC Bayern hat Louis van Gaal wieder einen neuen Job in Aussicht. Ab Sommer 2012 soll der Holl�nder Generaldirektor bei Ajax Amsterdam werden.
');
                                            ?></div><div style="clear:both"></div></div><div class="divArticleItem"><div class="divArticleDate"> 16 Nov 2011 21:28:2</div><div class="divShowSummary"><?php 
                                                getShowSummary(6);
                                            ?></div><div class="divArticleLink"><?php 
                                            	getAnker('
http://www.N24.de/news/newsitem_7424259.html
', '
Papst k�sst Imam - 
Benetton zieht Plakatmotiv zur�ck
');
											?><?php 
                                                getSummary02('6',
                                                            '
Benetton sorgt mit einem Werbeplakat abermals f�r einen Skandal: Das Motiv zeigt Papst Benedikt XVI., der den �gyptischen Imam Ahmed el Tajjeb k�sst. Das Modehaus zog das Bild nun zur�ck.
');
                                            ?></div><div style="clear:both"></div></div></div><div style="clear:both"></div><br></br></div><div style="clear:both"></div></div></body></html>

