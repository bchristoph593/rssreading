<?php
	include("../uc/header_imports.php");
	
	$xslPath = "xsl-sheets/rss-sport1.xsl";

//	$url_newsengine = "http://newsengine.v232681353.yourvserver.net/rss-news"; 
//	$url = $url_newsengine . "/spiegelonline/".$section."/index.rss";

	$portal = "sport1";
	$section = "schlagzeilen";
	
	$url_newsengine = "http://newsengine.v232681353.yourvserver.net"; 
	$url = $url_newsengine . "/ressourceBuilder.php?";
	$url .= "portal=".$portal;
	$url .= "&section=".$section;
	
	$rssPath = $url;

	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	@include("temp.php");
?>
