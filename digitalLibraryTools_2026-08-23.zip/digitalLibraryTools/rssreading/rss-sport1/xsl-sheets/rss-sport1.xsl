<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Sport1 Online | Schlagzeilen - crossreading</title>
                <link rel="shortcut icon" href="/images/favicon/fav-sport1.ico" />
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            			
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("Sport1");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong>
                            RSS Newsletter: <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="Fussball-Bundesliga" />
                        <br />
						<xsl:call-template name="Fussball-ChampionsLeague" />
                        <br />
						<xsl:call-template name="Fussball" />
                        <br />
						<xsl:call-template name="Tennis" />
                        <br />
						<xsl:call-template name="Handball" />
                        <br />
						<xsl:call-template name="Basketball" />
                        <br />
						<xsl:call-template name="Eishockey" />
                        <br />
						<xsl:call-template name="Formel1" />
                        <br />
						<xsl:call-template name="Turnen" />
                        <br />
						<xsl:call-template name="Motorsport" />
                        <br />
						<xsl:call-template name="Sonstige" />
                        <br />
                         
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
                
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="Fussball-Bundesliga">
		<strong>&gt; Fussball - Bundesliga</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cfussball0Ibundesliga'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'fussball-bundesliga'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Fussball-ChampionsLeague">
		<strong>&gt; Fussball - Champions League</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cfussball0Ichampionsleague0C'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'fussball-championsleague'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Fussball">
		<strong>&gt; Fussball</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cfussball'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'fussball'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									and contains(link, '0Cfussball0Ibundesliga')=false
									and contains(link, '0Cfussball0Ichampionsleague0C')=false
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(link, $searchFor)
												and contains(link, '0Cfussball0Ibundesliga')=false
												and contains(link, '0Cfussball0Ichampionsleague0C')=false
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Tennis">
		<strong>&gt; Tennis</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Ctennis'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'tennis'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Handball">
		<strong>&gt; Handball</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Chandball'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'handball'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Basketball">
		<strong>&gt; Basketball</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cbasketball'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'basketball'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)
						]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Eishockey">
		<strong>&gt; Eishockey</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Ceishockey'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'eishockey'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Formel1">
		<strong>&gt; Formel 1</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cformel1'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'formel1'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Turnen">
		<strong>&gt; Turnen</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cturnen'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'turnen'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Motorsport">
		<strong>&gt; Motorsport</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cmotorsport'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'motorsport'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>


	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
            						contains(link, '0Cfussball')=false
                                    and contains(link, '0Ctennis')=false
                                    and contains(link, '0Chandball')=false
                                    and contains(link, '0Cbasketball')=false
                                    and contains(link, '0Ceishockey')=false
                                    and contains(link, '0Cformel1')=false
                                    and contains(link, '0Cturnen')=false
                                    and contains(link, '0Cmotorsport')=false
                                    ]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 21)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
			            						contains(link, '0Cfussball')=false
			                                    and contains(link, '0Ctennis')=false
			                                    and contains(link, '0Chandball')=false
			                                    and contains(link, '0Cbasketball')=false
			                                    and contains(link, '0Ceishockey')=false
			                                    and contains(link, '0Cformel1')=false
			                                    and contains(link, '0Cturnen')=false
			                                    and contains(link, '0Cmotorsport')=false
                                            	]
											)"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
