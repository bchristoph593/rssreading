<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Sport1 Online | Schlagzeilen - crossreading</title><link rel="shortcut icon" href="/images/sport1-favicon.ico"></link><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Sport1");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a></div></div><div class="divContent"><strong>
                            RSS Newsletter: SPORT1 News</strong><br></br><hr></hr><strong xmlns="">&gt; Fussball - Bundesliga</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'fussball-bundesliga',
                    	'1',
                    	'Sun, 29 Jan 2012 19:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3c3ea1/l/0L0Ssport10Bde0Cde0Cfussball0Cfussball0Ibundesliga0Cnewspage0I512890A0Bhtml0TRSS/story01.htm',
                    	'Sammer r�t Ballack zu Abgang',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball-bundesliga',
                    	'2',
                    	'Sun, 29 Jan 2012 17:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3c2170/l/0L0Ssport10Bde0Cde0Cfussball0Cfussball0Ibundesliga0Cartikel0I5127850Bhtml0TRSS/story01.htm',
                    	'3:0! Gladbach kontert Stuttgart aus',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball-bundesliga',
                    	'3',
                    	'Sun, 29 Jan 2012 17:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bdae2/l/0L0Ssport10Bde0Cde0Cfussball0Cfussball0Ibundesliga0Cnewspage0I5128640Bhtml0TRSS/story01.htm',
                    	'Gladbach h�lt Kontakt zur Spitze',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball-bundesliga',
                    	'4',
                    	'Sun, 29 Jan 2012 16:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bc8ac/l/0L0Ssport10Bde0Cde0Cfussball0Cfussball0Ibundesliga0Cartikel0I5128370Bhtml0TRSS/story01.htm',
                    	'"Bayern kann Dortmund nicht kopieren"',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball-bundesliga',
                    	'5',
                    	'Sun, 29 Jan 2012 15:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3b6b2c/l/0L0Ssport10Bde0Cde0Cfussball0Cfussball0Ibundesliga0Cnewspage0I5128420Bhtml0TRSS/story01.htm',
                    	'Heynckes �berholt Rehhagel',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball-bundesliga',
                    	'6',
                    	'Sun, 29 Jan 2012 15:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3b6257/l/0L0Ssport10Bde0Cde0Cfussball0Cfussball0Ibundesliga0Cnewspage0I5128280Bhtml0TRSS/story01.htm',
                    	'Mainz gewinnt gegen Freiburg',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'fussball-bundesliga',
                    	'6'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Fussball - Champions League</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'fussball-championsleague',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Fussball</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'fussball',
                    	'1',
                    	'Sun, 29 Jan 2012 19:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3c3ba3/l/0L0Ssport10Bde0Cde0Cfussball0Cfus0Iinternational0Cfus0Iint0Iafrika0Icup0Cnewspage0I5128620Bhtml0TRSS/story01.htm',
                    	'Hey mit Libyen ausgeschieden',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball',
                    	'2',
                    	'Sun, 29 Jan 2012 17:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bc8a8/l/0L0Ssport10Bde0Cde0Cfussball0Cfus0Iinternational0Cfussball0Iinternational0Ipremierleague0Cnewspage0I5128620Bhtml0TRSS/story01.htm',
                    	'Arsenal nach Aufholjagd weiter',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball',
                    	'3',
                    	'Sun, 29 Jan 2012 17:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bdae3/l/0L0Ssport10Bde0Cde0Cfussball0Cfus0Iinternational0Cfussball0Iinternational0Ipremierleague0Cnewspage0I5128630Bhtml0TRSS/story01.htm',
                    	'Arsenal im FA-Cup-Achtelfinale',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'fussball',
                    	'4',
                    	'Sun, 29 Jan 2012 15:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bc8b0/l/0L0Ssport10Bde0Cde0Cfussball0Cfus0Iinternational0Cfussball0Iinternational0Iserie0Ia0Cartikel0I5127580Bhtml0TRSS/story01.htm',
                    	'Klose-Show: Lazio h�lt den Anschluss',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'fussball',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Tennis</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'tennis',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Handball</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'handball',
                    	'1',
                    	'Sun, 29 Jan 2012 16:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bd18a/l/0L0Ssport10Bde0Cde0Chandball0Cnewspage0I5128470Bhtml0TRSS/story01.htm',
                    	'D�nemark l�st Olympia-Ticket',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'handball',
                    	'2',
                    	'Sun, 29 Jan 2012 16:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bd18c/l/0L0Ssport10Bde0Cde0Chandball0Chandball0Iem0Cnewspage0I5128460Bhtml0TRSS/story01.htm',
                    	'D�nemark gewinnt EM-Titel',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'handball',
                    	'3',
                    	'Sun, 29 Jan 2012 16:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bc8ae/l/0L0Ssport10Bde0Cde0Chandball0Chandball0Iem0Cartikel0I51280A70Bhtml0TRSS/story01.htm',
                    	'D�nemark zur�ck auf Europas Thron',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'handball',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Basketball</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'basketball',
                    	'1',
                    	'Sun, 29 Jan 2012 19:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3c310e/l/0L0Ssport10Bde0Cde0Cbasketball0Cbasketball0Ibundesliga0Cnewspage0I5128950Bhtml0TRSS/story01.htm',
                    	'Trier gewinnt Kellerduell',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'basketball',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Eishockey</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'eishockey',
                    	'1',
                    	'Sun, 29 Jan 2012 19:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3b6253/l/0L0Ssport10Bde0Cde0Ceishockey0Ceishockey0Idel0Cnewspage0I512830A0Bhtml0TRSS/story01.htm',
                    	'D�sseldorf gewinnt Rheinderby',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'eishockey',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Formel 1</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'formel1',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Turnen</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'turnen',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Motorsport</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'motorsport',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'Sun, 29 Jan 2012 19:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3c3ba2/l/0L0Ssport10Bde0Cde0Cwintersport0Cwin0Ieisschnelllauf0Cnewspage0I5128860Bhtml0TRSS/story01.htm',
                    	'Wolf verliert Weltrekord',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'Sun, 29 Jan 2012 18:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3c216f/l/0L0Ssport10Bde0Cde0Cwintersport0Cwin0Ieisschnelllauf0Cnewspage0I512870A0Bhtml0TRSS/story01.htm',
                    	'Neue Vorw�rfe gegen Pechstein',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'Sun, 29 Jan 2012 17:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bc8a9/l/0L0Ssport10Bde0Cde0Cwintersport0Cnewspage0I5128610Bhtml0TRSS/story01.htm',
                    	'Shorttracker holen EM-Bronze',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'Sun, 29 Jan 2012 17:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bc8aa/l/0L0Ssport10Bde0Cde0Cschwimmen0Cnewspage0I512860A0Bhtml0TRSS/story01.htm',
                    	'Deibler schneller als Thorpe',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'Sun, 29 Jan 2012 17:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bc8ab/l/0L0Ssport10Bde0Cde0Creiten0Cnewspage0I5128590Bhtml0TRSS/story01.htm',
                    	'Kutscher triumphiert in Z�rich',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'6',
                    	'Sun, 29 Jan 2012 16:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bd18d/l/0L0Ssport10Bde0Cde0Cmehrsport0Cnewspage0I5128450Bhtml0TRSS/story01.htm',
                    	'Fechter-Team macht Punkte gut',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'7',
                    	'Sun, 29 Jan 2012 16:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3bbee6/l/0L0Ssport10Bde0Cde0Cwasserball0Cnewspage0I5128440Bhtml0TRSS/story01.htm',
                    	'Serbien holt EM-Titel',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'8',
                    	'Sun, 29 Jan 2012 15:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3b6b2a/l/0L0Ssport10Bde0Cde0Cleichtathletik0Cnewspage0I5128430Bhtml0TRSS/story01.htm',
                    	'Titel f�r Kahlert und Schwerdtner',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'9',
                    	'Sun, 29 Jan 2012 15:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3b6252/l/0L0Ssport10Bde0Cde0Chockey0Cnewspage0I5128310Bhtml0TRSS/story01.htm',
                    	'DHB-Frauen starten mit Sieg',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'10',
                    	'Sun, 29 Jan 2012 15:',
                    	'http://sport1.de.feedsportal.com/c/33415/f/587333/s/1c3b6f47/l/0L0Ssport10Bde0Cde0Creiten0Cnewspage0I5128260Bhtml0TRSS/story01.htm',
                    	'Ready Cash verteidigt Titel',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'10'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>
