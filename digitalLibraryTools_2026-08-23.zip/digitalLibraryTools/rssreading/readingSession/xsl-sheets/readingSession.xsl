<?xml version="1.0" encoding="ISO-8859-1" ?>
<!-- DWXMLSource="http://www.spiegel.de/schlagzeilen/index.rss" -->
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
	<!-- <!ENTITY apos   "&#039;"> -->
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" 
	  encoding="UTF-8" 
	  doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" 
	  doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"
	/>
	
	<xsl:template match="TextWebResourceItemGroup">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
				
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
				
                <title>Reading Session | Schlagzeilen - rssreading</title>
                <link rel="shortcut icon" href="../images/favicon/xml_02.png" />
                <link href="../css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            
<!--			
			<body onload="lookupArticleLinkAmount(); ">
-->
			<body>
			<!--
                <script type="text/javascript" src="../js/jquery-latest.min.js">
				</script>
			-->
			
                <script type="text/javascript" src="../js/unfold.js"></script>
                <script type="text/javascript" src="../js/visitLink.js"></script>
                <script type="text/javascript" src="../js/wndLocalStorage.js"></script>
        
		<script type="text/javascript">
		  <![CDATA[
          ]]>
        </script>
		
				<xsl:processing-instruction name="php">
					include("../uc/header_imports_02.php");
				?</xsl:processing-instruction>
				
				<xsl:processing-instruction name="php">
					include("../uc/readingSession_articleItem.php");
				?</xsl:processing-instruction>
				
				<xsl:processing-instruction name="php">
					include("../uc/readingSession_articleLink.php");
				?</xsl:processing-instruction>
				
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("ReadingSession");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
						<xsl:variable name="linkCounter_all">
							<xsl:value-of select="count(TextWebResourceItem)"/>
						</xsl:variable>
			
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="../readingSession/">
							  &gt; Alle Nachrichten (<xsl:processing-instruction name="php">
								  echo '<xsl:value-of select="$linkCounter_all" />';
								?</xsl:processing-instruction>)</a>
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <!-- <br /> -->
                        <hr />
                        
						<xsl:call-template name="Sonstige" />
                        <!-- <br /> -->
						
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
				
				<div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div>
				
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="string-replace-all">
		<xsl:param name="text" />
		<xsl:param name="replace" />
		<xsl:param name="by" />
		<xsl:choose>
			<xsl:when test="$text = '' or $replace = ''or not($replace)" >
				<!-- Prevent this routine from hanging -->
				<xsl:value-of select="$text" />
			</xsl:when>
			<xsl:when test="contains($text, $replace)">
				<xsl:value-of select="substring-before($text,$replace)" />
				<xsl:value-of select="$by" />
				<xsl:call-template name="string-replace-all">
					<xsl:with-param name="text" select="substring-after($text,$replace)" />
					<xsl:with-param name="replace" select="$replace" />
					<xsl:with-param name="by" select="$by" />
				</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$text" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	
	<xsl:template name="Sonstige">
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_sonstige">
				<xsl:value-of select="count(TextWebResourceItem)"/>
			</xsl:variable>

		<strong>&gt; Sonstige (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_sonstige" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="TextWebResourceItem
									">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="TextDocDate" />',
                    	'<xsl:value-of select="TextDocURL" />',
                    	'<xsl:value-of select="TextDocTitle" />',
                    	'<xsl:value-of select="TextDocSummary"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(TextWebResourceItem
									)"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
