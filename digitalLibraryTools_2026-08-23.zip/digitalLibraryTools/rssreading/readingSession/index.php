<?php
	include("../../newsengine/uc/newsPortal_01.php");
	
	include("../uc/header_imports_01.php");
	
	$xslPath = "http://localhost/digitalLibraryTools/rssreading/";
   	$xslPath .= "readingSession/xsl-sheets/readingSession.xsl";
	
	// echo "xslPath: ". $xslPath."<br />";
	
//	$url_newsengine = "http://newsengine.v232681353.yourvserver.net/rss-news"; 
//	$url = $url_newsengine . "/spiegelonline/".$section."/index.rss";
	
	$portal = "";
	$section = "browsingSession";
	
	$url_newsengine = "http://localhost/digitalLibraryTools/newsengine/"; 
	$url = $url_newsengine . "ressourceBuilder.php?";
	$url .= "section=".$section;
	
	$rssPath = $url;

	// echo "rssPath: ". $rssPath."<br />";
	
	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	include("temp.php");
?>
