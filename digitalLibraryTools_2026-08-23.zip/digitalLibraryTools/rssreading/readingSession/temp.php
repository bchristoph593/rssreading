<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

  <html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta><meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Reading Session | Schlagzeilen - rssreading</title><link rel="shortcut icon" href="../images/favicon/xml_02.png"></link><link href="../css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="../js/unfold.js"></script><script type="text/javascript" src="../js/visitLink.js"></script><script type="text/javascript" src="../js/wndLocalStorage.js"></script><script type="text/javascript">
          </script><?php 
					include("../uc/header_imports_02.php");
				?><?php 
					include("../uc/readingSession_articleItem.php");
				?><?php 
					include("../uc/readingSession_articleLink.php");
				?><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("ReadingSession");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="../readingSession/">
							  &gt; Alle Nachrichten (<?php 
								  echo '0';
								?>)</a></div></div><div class="divContent"><strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; ReadingSession - Alle Nachrichten</strong><hr></hr><strong xmlns="">&gt; Sonstige (<?php 
		  echo '0';
		?>)
		</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div></div><div style="clear:both"></div></div><div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div></body></html>

