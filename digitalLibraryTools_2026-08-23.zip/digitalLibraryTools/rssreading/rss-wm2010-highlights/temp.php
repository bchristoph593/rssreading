<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Youtube-Channel: FifaWM2010Suedafrika | Alle Highlights</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("WM2010-HighLights");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Alle Highlights</a><br></br><a href="index-A.php">&gt; Highlights: Gruppe A</a><a href="index-B.php">&gt; Highlights: Gruppe B</a><a href="index-C.php">&gt; Highlights: Gruppe C</a><a href="index-D.php">&gt; Highlights: Gruppe D</a><a href="index-E.php">&gt; Highlights: Gruppe E</a><a href="index-F.php">&gt; Highlights: Gruppe F</a><a href="index-G.php">&gt; Highlights: Gruppe G</a><a href="index-H.php">&gt; Highlights: Gruppe H</a></div></div><div class="divContent"><strong>
                            RSS Newsletter: Uploads by username: "FifaWM2010Suedafrika"
</strong><br></br><hr></hr><strong xmlns="">&gt; Spiele 29.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele29-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 28.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele28-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 27.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele27-06',
                    	'1',
                    	'28 Jun 2010 12:25:15',
                    	'http://www.youtube.com/watch?v=O5cZosH9QjI&feature=youtube_gdata',
                    	'Argentinien 3:1 Mexiko WM 2010 - Highlights 27.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=O5cZosH9QjI&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/O5cZosH9QjI/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=O5cZosH9QjI&feature=youtube_gdata">Argentinien 3:1 Mexiko WM 2010 - Highlights 27.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Achtelfinale: 52. Spiel Argentinien - Mexiko am 27.06.2010 um 20:30 Uhr in Johannesburg. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
35387</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_empty_11x11.gif"></div>
<div style="font-size: 11px;">27
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">01:59</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '1';
            	echo getContainerListVisited(
                		'spiele27-06',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 26.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele26-06',
                    	'1',
                    	'26 Jun 2010 21:34:51',
                    	'http://www.youtube.com/watch?v=YosM3Z2CO_Y&feature=youtube_gdata',
                    	'Uruguay 2:1 S�dkorea WM 2010 - Highlights 26.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=YosM3Z2CO_Y&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/YosM3Z2CO_Y/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=YosM3Z2CO_Y&feature=youtube_gdata">Uruguay 2:1 S&uuml;dkorea WM 2010 - Highlights 26.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Achtelfinale: 49. Spiel Uruguay - S&uuml;dkorea am 26.06.2010 um 16:00 Uhr in Nelson Mandela Bay/Port Elizabeth. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
17313</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">25
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:03</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '1';
            	echo getContainerListVisited(
                		'spiele26-06',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 25.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele25-06',
                    	'1',
                    	'26 Jun 2010 11:02:44',
                    	'http://www.youtube.com/watch?v=1JuX3W9jWrs&feature=youtube_gdata',
                    	'Schweiz 0:0 Honduras WM 2010 - Highlights 25.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=1JuX3W9jWrs&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/1JuX3W9jWrs/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=1JuX3W9jWrs&feature=youtube_gdata">Schweiz 0:0 Honduras WM 2010 - Highlights 25.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe H: 48. Spiel Schweiz - Honduras am 25.06.2010 um 20:30 Uhr in Mangaung / Bloemfontein. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
5059</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_empty_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_empty_11x11.gif"></div>
<div style="font-size: 11px;">10
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">01:59</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele25-06',
                    	'2',
                    	'26 Jun 2010 10:50:06',
                    	'http://www.youtube.com/watch?v=Kj9bsKd1KI4&feature=youtube_gdata',
                    	'Chile 1:2 Spanien WM 2010 - Highlights 25.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=Kj9bsKd1KI4&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/Kj9bsKd1KI4/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=Kj9bsKd1KI4&feature=youtube_gdata">Chile 1:2 Spanien WM 2010 - Highlights 25.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe H: 47. Spiel Chile - Spanien am 25.06.2010 um 20:30 Uhr in Tshwane/Pretoria. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
34074</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">20
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:05</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele25-06',
                    	'3',
                    	'25 Jun 2010 20:49:01',
                    	'http://www.youtube.com/watch?v=d5itRjGAlQM&feature=youtube_gdata',
                    	'Nordkorea 0:3 Elfenbeink�ste WM 2010 - Highlights 25.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=d5itRjGAlQM&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/d5itRjGAlQM/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=d5itRjGAlQM&feature=youtube_gdata">Nordkorea 0:3 Elfenbeink&uuml;ste WM 2010 - Highlights 25.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe G: 46. Spiel Nordkorea - Elfenbeink&uuml;ste am 25.06.2010 um 16:00 Uhr in Nelspruit. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
13804</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">21
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:14</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele25-06',
                    	'4',
                    	'25 Jun 2010 20:33:47',
                    	'http://www.youtube.com/watch?v=_hzYvZal4DI&feature=youtube_gdata',
                    	'Portugal 0:0 Brasilien WM 2010 - Highlights 25.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=_hzYvZal4DI&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/_hzYvZal4DI/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=_hzYvZal4DI&feature=youtube_gdata">Portugal 0:0 Brasilien WM 2010 - Highlights 25.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe G: 45. Spiel Portugal - Brasilien am 25.06.2010 um 16:00 Uhr in Durban. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
20170</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">23
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:15</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '4';
            	echo getContainerListVisited(
                		'spiele25-06',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 24.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele24-06',
                    	'1',
                    	'25 Jun 2010 13:21:58',
                    	'http://www.youtube.com/watch?v=BlsSmCehejc&feature=youtube_gdata',
                    	'Kamerun 1:2 Niederlande WM 2010 - Highlights 24.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=BlsSmCehejc&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/BlsSmCehejc/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=BlsSmCehejc&feature=youtube_gdata">Kamerun 1:2 Niederlande WM 2010 - Highlights 24.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe E: 44. Spiel Kamerun - Niederlande am 24.06.2010 um 20:30 Uhr in Kapstadt. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
16429</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_empty_11x11.gif"></div>
<div style="font-size: 11px;">16
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:10</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele24-06',
                    	'2',
                    	'25 Jun 2010 13:09:53',
                    	'http://www.youtube.com/watch?v=bsz-5Wn1kdg&feature=youtube_gdata',
                    	'D�nemark 1:3 Japan WM 2010 - Highlights 24.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=bsz-5Wn1kdg&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/bsz-5Wn1kdg/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=bsz-5Wn1kdg&feature=youtube_gdata">D&auml;nemark 1:3 Japan WM 2010 - Highlights 24.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe E: 43. Spiel D&auml;nemark - Japan am 24.06.2010 um 20:30 Uhr in Rustenburg. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
64980</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">87
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:12</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele24-06',
                    	'3',
                    	'24 Jun 2010 20:08:40',
                    	'http://www.youtube.com/watch?v=gJbtHx9rHa0&feature=youtube_gdata',
                    	'Paraguay 0:0 Neuseeland WM 2010 - Highlights 24.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=gJbtHx9rHa0&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/gJbtHx9rHa0/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=gJbtHx9rHa0&feature=youtube_gdata">Paraguay 0:0 Neuseeland WM 2010 - Highlights 24.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe F: 42. Spiel Paraguay - Neuseeland am 24.06.2010 um 16:00 Uhr in Polokwane. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
2558</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"></div>
<div style="font-size: 11px;">5
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:14</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '3';
            	echo getContainerListVisited(
                		'spiele24-06',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 23.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele23-06',
                    	'1',
                    	'24 Jun 2010 12:37:43',
                    	'http://www.youtube.com/watch?v=hQRfd_0D-b0&feature=youtube_gdata',
                    	'Australien 2:1 Serbien WM 2010 - Highlights 23.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=hQRfd_0D-b0&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/hQRfd_0D-b0/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=hQRfd_0D-b0&feature=youtube_gdata">Australien 2:1 Serbien WM 2010 - Highlights 23.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe D: 40. Spiel Australien - Serbien am 23.06.2010 um 20:30 Uhr in Nelspruit.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
23793</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_empty_11x11.gif"></div>
<div style="font-size: 11px;">26
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:10</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele23-06',
                    	'2',
                    	'24 Jun 2010 12:22:02',
                    	'http://www.youtube.com/watch?v=DlGwAIyUwQc&feature=youtube_gdata',
                    	'Slowenien 0:1 England WM 2010 - Highlights 23.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=DlGwAIyUwQc&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/DlGwAIyUwQc/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=DlGwAIyUwQc&feature=youtube_gdata">Slowenien 0:1 England WM 2010 - Highlights 23.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe C: 37. Spiel Slowenien - England am 23.06.2010 um 16:00 Uhr in Nelson Mandela Bay/Port Elizabeth. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
8204</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">8
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:20</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele23-06',
                    	'3',
                    	'24 Jun 2010 12:17:04',
                    	'http://www.youtube.com/watch?v=SpQZhcDYL_o&feature=youtube_gdata',
                    	'USA 1:0 Algerien WM 2010 - Highlights 23.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=SpQZhcDYL_o&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/SpQZhcDYL_o/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=SpQZhcDYL_o&feature=youtube_gdata">USA 1:0 Algerien WM 2010 - Highlights 23.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe C: 38. Spiel USA - Algerien am 23.06.2010 um 16:00 Uhr in Tshwane/Pretoria. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
15343</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"></div>
<div style="font-size: 11px;">13
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:11</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '3';
            	echo getContainerListVisited(
                		'spiele23-06',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 22.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele22-06',
                    	'1',
                    	'23 Jun 2010 12:50:09',
                    	'http://www.youtube.com/watch?v=OurXMTOB0u8&feature=youtube_gdata',
                    	'Griechenland 0:2 Argentinien WM 2010 - Highlights 22.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=OurXMTOB0u8&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/OurXMTOB0u8/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=OurXMTOB0u8&feature=youtube_gdata">Griechenland 0:2 Argentinien WM 2010 - Highlights 22.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe B: 36. Spiel Griechenland - Argentinen am 22.06.2010 um 20:30 Uhr in Polokwane. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
15103</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">25
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:29</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele22-06',
                    	'2',
                    	'23 Jun 2010 12:33:28',
                    	'http://www.youtube.com/watch?v=ytvXhMTNsbU&feature=youtube_gdata',
                    	'Nigeria 2:2 S�dkorea WM 2010 - Highlights 22.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=ytvXhMTNsbU&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/ytvXhMTNsbU/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=ytvXhMTNsbU&feature=youtube_gdata">Nigeria 2:2 S&uuml;dkorea WM 2010 - Highlights 22.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe B: 35. Spiel Nigeria - S&uuml;dkorea am 22.06.2010 um 20:30 Uhr in Durban. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
9782</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"></div>
<div style="font-size: 11px;">15
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:15</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele22-06',
                    	'3',
                    	'22 Jun 2010 18:55:49',
                    	'http://www.youtube.com/watch?v=CeAQ67vMcko&feature=youtube_gdata',
                    	'Frankreich 1:2 S�dafrika WM 2010 - Highlights 22.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=CeAQ67vMcko&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/CeAQ67vMcko/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=CeAQ67vMcko&feature=youtube_gdata">Frankreich 1:2 S&uuml;dafrika WM 2010 - Highlights 22.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe A: 34. Spiel Frankreich - S&uuml;dafrika am 22.06.2010 um 16:00 Uhr in Mangaung / Bloemfontein. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
16078</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"></div>
<div style="font-size: 11px;">21
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:08</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele22-06',
                    	'4',
                    	'22 Jun 2010 18:43:42',
                    	'http://www.youtube.com/watch?v=ghTsi_Q18YM&feature=youtube_gdata',
                    	'Mexiko 0:1 Uruguay WM 2010 - Highlights 22.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=ghTsi_Q18YM&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/ghTsi_Q18YM/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=ghTsi_Q18YM&feature=youtube_gdata">Mexiko 0:1 Uruguay WM 2010 - Highlights 22.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe A: 33. Spiel Mexiko - Uruguay am 22.06.2010 um 16:00 Uhr in Rustenburg. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
11744</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">19
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:06</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '4';
            	echo getContainerListVisited(
                		'spiele22-06',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 21.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele21-06',
                    	'1',
                    	'22 Jun 2010 12:15:25',
                    	'http://www.youtube.com/watch?v=uU7Jh9o234M&feature=youtube_gdata',
                    	'Spanien 2:0 Honduras WM 2010 - Highlights 21.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=uU7Jh9o234M&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/uU7Jh9o234M/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=uU7Jh9o234M&feature=youtube_gdata">Spanien 2:0 Honduras WM 2010 - Highlights 21.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe H: 32. Spiel Spanien - Honduras am 21.06.2010 um 20:30 Uhr in Johannesburg - JEP. Kommentieren, Daumen hoch & Abonnieren.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
31253</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">25
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:09</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '1';
            	echo getContainerListVisited(
                		'spiele21-06',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 20.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele20-06',
                    	'1',
                    	'20 Jun 2010 19:10:08',
                    	'http://www.youtube.com/watch?v=ZGXBIUB6fVk&feature=youtube_gdata',
                    	'Italien 1:1 Neuseeland WM 2010 - Highlights 20.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=ZGXBIUB6fVk&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/ZGXBIUB6fVk/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=ZGXBIUB6fVk&feature=youtube_gdata">Italien 1:1 Neuseeland WM 2010 - Highlights 20.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe F: 28. Spiel Italien - Neuseeland am 20.06.2010 um 16:00 Uhr in Nelspruit. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
13057</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_half_11x11.gif"></div>
<div style="font-size: 11px;">15
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:03</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele20-06',
                    	'2',
                    	'20 Jun 2010 15:09:41',
                    	'http://www.youtube.com/watch?v=G10RJ7DuSKo&feature=youtube_gdata',
                    	'Slowakei 0:2 Paraguay WM 2010 - Highlights 20.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=G10RJ7DuSKo&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/G10RJ7DuSKo/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=G10RJ7DuSKo&feature=youtube_gdata">Slowakei 0:2 Paraguay WM 2010 - Highlights 20.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe F: 27. Spiel Slowakei - Paraguay am 20.06.2010 um 13:30 Uhr in Mangaung / Bloemfontein. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
6161</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"></div>
<div style="font-size: 11px;">9
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:10</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '2';
            	echo getContainerListVisited(
                		'spiele20-06',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 19.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele19-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 18.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele18-06',
                    	'1',
                    	'18 Jun 2010 22:51:47',
                    	'http://www.youtube.com/watch?v=i-e4kGIkFm0&feature=youtube_gdata',
                    	'England 0:0 Algerien WM 2010 - Highlights 18.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=i-e4kGIkFm0&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/i-e4kGIkFm0/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=i-e4kGIkFm0&feature=youtube_gdata">England 0:0 Algerien WM 2010 - Highlights 18.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe C: 23. Spiel England - Algerien am 18.06.2010 um 20:30 Uhr in Kapstadt. Kommentieren, Daumen hoch & Abonnieren, danke.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
22729</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_empty_11x11.gif"></div>
<div style="font-size: 11px;">12
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">01:44</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '1';
            	echo getContainerListVisited(
                		'spiele18-06',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 17.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele17-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 16.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele16-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 15.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele15-06',
                    	'1',
                    	'20 Jun 2010 00:01:40',
                    	'http://www.youtube.com/watch?v=BBDA_ORHeEM&feature=youtube_gdata',
                    	'Elfenbeink�ste 0:0 Portugal WM 2010 - Highlights 15.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=BBDA_ORHeEM&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/BBDA_ORHeEM/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=BBDA_ORHeEM&feature=youtube_gdata">Elfenbeink&uuml;ste 0:0 Portugal WM 2010 - Highlights 15.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe G: 13. Spiel Elfenbeink&uuml;ste - Portugal am 15.06.2010 um 16:00 Uhr in Nelson Mandela Bay/Port Elizabeth.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
13638</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"></div>
<div style="font-size: 11px;">21
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:06</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'spiele15-06',
                    	'2',
                    	'19 Jun 2010 23:30:31',
                    	'http://www.youtube.com/watch?v=dou6wVSlD2U&feature=youtube_gdata',
                    	'Neuseeland 1:1 Slowakei WM 2010 - Highlights 15.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=dou6wVSlD2U&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/dou6wVSlD2U/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=dou6wVSlD2U&feature=youtube_gdata">Neuseeland 1:1 Slowakei WM 2010 - Highlights 15.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe F: 12. Spiel Neuseeland - Slowakei am 15.06.2010 um 13:30 Uhr in Rustenburg</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
3400</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_empty_11x11.gif"></div>
<div style="font-size: 11px;">7
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:03</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '2';
            	echo getContainerListVisited(
                		'spiele15-06',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 14.06.</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'spiele14-06',
                    	'1',
                    	'19 Jun 2010 23:42:45',
                    	'http://www.youtube.com/watch?v=Yl6Rdpuaj7U&feature=youtube_gdata',
                    	'Italien 1:1 Paraguay WM 2010 - Highlights 14.06.2010',
                    	'<div style="color: #000000;font-family: Arial, Helvetica, sans-serif;     font-size:12px; font-size: 12px; width: 555px;">
<table cellspacing="0" cellpadding="0" border="0"><tbody><tr><td width="140" valign="top" rowspan="2"><div style="border: 1px solid #999999; margin: 0px 10px 5px 0px;"><a href="http://www.youtube.com/watch?v=Yl6Rdpuaj7U&feature=youtube_gdata"><img alt="" src="http://i.ytimg.com/vi/Yl6Rdpuaj7U/default.jpg"></a></div></td>
<td width="256" valign="top"><div style="font-size: 12px; font-weight: bold;"><a style="font-size: 15px; font-weight: bold;                  font-decoration: none;" href="http://www.youtube.com/watch?v=Yl6Rdpuaj7U&feature=youtube_gdata">Italien 1:1 Paraguay WM 2010 - Highlights 14.06.2010</a>
<br></div>
<div style="font-size: 12px; margin: 3px 0px;"><span>Gruppe F: 11. Spiel Italien - Paraguay am 14.06.2010 um 20:30 Uhr in Kapstadt.</span></div></td>
<td style="font-size: 11px; line-height: 1.4em; padding-left: 20px;             padding-top: 1px;" width="146" valign="top"><div><span style="color: #666666; font-size: 11px;">From:</span>
<a href="http://www.youtube.com/profile?user=FifaWM2010Suedafrika">FifaWM2010Suedafrika</a></div>
<div><span style="color: #666666; font-size: 11px;">Views:</span>
6317</div>
<div style="white-space: nowrap;text-align: left"><img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"> <img style="border: 0px none; margin: 0px; padding: 0px;                    vertical-align: middle; font-size: 11px;" align="top" alt="" src="http://gdata.youtube.com/static/images/icn_star_full_11x11.gif"></div>
<div style="font-size: 11px;">4
<span style="color: #666666; font-size: 11px;">ratings</span></div></td></tr>
<tr><td><span style="color: #666666; font-size: 11px;">Time:</span>
<span style="color: #000000; font-size: 11px; font-weight: bold;">02:08</span></td>
<td style="font-size: 11px; padding-left: 20px;"><span style="color: #666666; font-size: 11px;">More in</span>
<a href="http://www.youtube.com/videos?c=17">Sports</a></td></tr></tbody></table></div>'
                    	);
            	?><?php 
//            	echo '1';
            	echo getContainerListVisited(
                		'spiele14-06',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 13.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele13-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 12.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele12-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Spiele 11.06.</strong><div xmlns="" class="divLinkSection"><?php 
//            	echo '0';
            	echo getContainerListVisited(
                		'spiele11-06',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>
