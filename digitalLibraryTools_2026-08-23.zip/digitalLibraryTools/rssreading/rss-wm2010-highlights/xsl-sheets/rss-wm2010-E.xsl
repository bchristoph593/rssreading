<?xml version="1.0" encoding="ISO-8859-1"?>
<!-- DWXMLSource="http://www.spiegel.de/schlagzeilen/index.rss" -->
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Youtube-Channel: FifaWM2010Suedafrika | Alle Highlights</title>
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            			
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("WM2010-HighLights");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a href="index.php">&gt; Alle Highlights</a>
                            <br />
                        	<a href="index-A.php">&gt; Highlights: Gruppe A</a>
                        	<a href="index-B.php">&gt; Highlights: Gruppe B</a>
                        	<a href="index-C.php">&gt; Highlights: Gruppe C</a>
                        	<a href="index-D.php">&gt; Highlights: Gruppe D</a>
                        	<a class="linkSelected" href="index-E.php">&gt; Highlights: Gruppe E</a>
                        	<a href="index-F.php">&gt; Highlights: Gruppe F</a>
                        	<a href="index-G.php">&gt; Highlights: Gruppe G</a>
                        	<a href="index-H.php">&gt; Highlights: Gruppe H</a>
                            
                        </div>
                                         
                    </div>
                    
					<xsl:variable name="containerID" select="1"/>
                    <div class="divContent">
                        <strong>
                            RSS Newsletter: <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Gruppe E</xsl:with-param>
                            <xsl:with-param name="sectionName">gruppeE</xsl:with-param>
                            <xsl:with-param name="searchFor">Gruppe E</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="generateSection">
    	<xsl:param name="sectionTitle" />
    	<xsl:param name="sectionName" />
    	<xsl:param name="searchFor" />
        
		<strong>&gt; <xsl:value-of select="$sectionTitle" /></strong>
                
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(description, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(description, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
        
		<div class="divLinkSection">
			<xsl:for-each select="item[
            							contains(description, 'Gruppe A')=false
                                        and contains(description, 'Gruppe B')=false
                                        and contains(description, 'Gruppe C')=false
                                        and contains(description, 'Gruppe D')=false
                                        and contains(description, 'Gruppe E')=false
                                        and contains(description, 'Gruppe F')=false
                                        and contains(description, 'Gruppe G')=false
										]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
                                        		contains(description, 'Gruppe A')=false
                                        		and contains(description, 'Gruppe B')=false
                                        		and contains(description, 'Gruppe C')=false
                                        		and contains(description, 'Gruppe D')=false
                                        		and contains(description, 'Gruppe E')=false
                                        		and contains(description, 'Gruppe F')=false
                                        		and contains(description, 'Gruppe G')=false
                								])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
            
            	
</xsl:stylesheet>
