<?xml version="1.0" encoding="ISO-8859-1"?>
<!-- DWXMLSource="http://www.spiegel.de/schlagzeilen/index.rss" -->
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Youtube-Channel: FifaWM2010Suedafrika | Alle Highlights</title>
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            			
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("WM2010-HighLights");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Alle Highlights</a>
                            <br />
                        	<a href="index-A.php">&gt; Highlights: Gruppe A</a>
                        	<a href="index-B.php">&gt; Highlights: Gruppe B</a>
                        	<a href="index-C.php">&gt; Highlights: Gruppe C</a>
                        	<a href="index-D.php">&gt; Highlights: Gruppe D</a>
                        	<a href="index-E.php">&gt; Highlights: Gruppe E</a>
                        	<a href="index-F.php">&gt; Highlights: Gruppe F</a>
                        	<a href="index-G.php">&gt; Highlights: Gruppe G</a>
                        	<a href="index-H.php">&gt; Highlights: Gruppe H</a>
                            
                        </div>
                                         
                    </div>
                    
					<xsl:variable name="containerID" select="1"/>
                    <div class="divContent">
                        <strong>
                            RSS Newsletter: <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                                                
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 29.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele29-06</xsl:with-param>
                            <xsl:with-param name="searchFor">29.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 28.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele28-06</xsl:with-param>
                            <xsl:with-param name="searchFor">28.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 27.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele27-06</xsl:with-param>
                            <xsl:with-param name="searchFor">27.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 26.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele26-06</xsl:with-param>
                            <xsl:with-param name="searchFor">26.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 25.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele25-06</xsl:with-param>
                            <xsl:with-param name="searchFor">25.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 24.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele24-06</xsl:with-param>
                            <xsl:with-param name="searchFor">24.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 23.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele23-06</xsl:with-param>
                            <xsl:with-param name="searchFor">23.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 22.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele22-06</xsl:with-param>
                            <xsl:with-param name="searchFor">22.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 21.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele21-06</xsl:with-param>
                            <xsl:with-param name="searchFor">21.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 20.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele20-06</xsl:with-param>
                            <xsl:with-param name="searchFor">20.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 19.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele19-06</xsl:with-param>
                            <xsl:with-param name="searchFor">19.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 18.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele18-06</xsl:with-param>
                            <xsl:with-param name="searchFor">18.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 17.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele17-06</xsl:with-param>
                            <xsl:with-param name="searchFor">17.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 16.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele16-06</xsl:with-param>
                            <xsl:with-param name="searchFor">16.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 15.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele15-06</xsl:with-param>
                            <xsl:with-param name="searchFor">15.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 14.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele14-06</xsl:with-param>
                            <xsl:with-param name="searchFor">14.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 13.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele13-06</xsl:with-param>
                            <xsl:with-param name="searchFor">13.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 12.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele12-06</xsl:with-param>
                            <xsl:with-param name="searchFor">12.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
						<xsl:call-template name="generateSection">
                        	<xsl:with-param name="sectionTitle">Spiele 11.06.</xsl:with-param>
                            <xsl:with-param name="sectionName">spiele11-06</xsl:with-param>
                            <xsl:with-param name="searchFor">11.06.2010</xsl:with-param>
                        </xsl:call-template>                        
                        <br />
                                                                    
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="generateSection">
    	<xsl:param name="sectionTitle" />
    	<xsl:param name="sectionName" />
    	<xsl:param name="searchFor" />
        
		<strong>&gt; <xsl:value-of select="$sectionTitle" /></strong>
                
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(title, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(title, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
//            	echo '<xsl:value-of select="$linkCounter" />';
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
        
		<div class="divLinkSection">
			<xsl:for-each select="item[
            							contains(description, 'Gruppe A')=false
                                        and contains(description, 'Gruppe B')=false
                                        and contains(description, 'Gruppe C')=false
                                        and contains(description, 'Gruppe D')=false
                                        and contains(description, 'Gruppe E')=false
                                        and contains(description, 'Gruppe F')=false
                                        and contains(description, 'Gruppe G')=false
										]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
                                        		contains(description, 'Gruppe A')=false
                                        		and contains(description, 'Gruppe B')=false
                                        		and contains(description, 'Gruppe C')=false
                                        		and contains(description, 'Gruppe D')=false
                                        		and contains(description, 'Gruppe E')=false
                                        		and contains(description, 'Gruppe F')=false
                                        		and contains(description, 'Gruppe G')=false
                								])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
            
            	
</xsl:stylesheet>
