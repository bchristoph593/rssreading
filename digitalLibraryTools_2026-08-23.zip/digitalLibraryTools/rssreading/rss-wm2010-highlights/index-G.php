<?php
	include("../uc/header_imports.php");
	
	$xslPath = "xsl-sheets/rss-wm2010-G.xsl";
	$rssPath = "http://gdata.youtube.com/feeds/base/users/FifaWM2010Suedafrika/uploads?alt=rss&v=2&orderby=published&client=ytapi-youtube-profile";
	
	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	@include("temp.php");	
?>