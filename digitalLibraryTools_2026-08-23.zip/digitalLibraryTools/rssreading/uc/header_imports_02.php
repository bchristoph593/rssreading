<?php
	// import all needed php-files here
	
	include("articleSummary.php");
	include("containerVisited.php");
	
	include("siteHeadBar.php");

	include("navMenu_global.php");
	
	include("replaceHtmlChars_02.php");
?>