<?php
	function getShowSummary($sectionName, $articleNumber) {
		/*
		echo '
			<a onclick="blocking(\''. $articleNumber .'\')">
            	<img id=\'summary_'. $articleNumber .'_img\' 
                		src="images/arrow-right.png"
                        onmouseover="Tip(\'Show article summary\', ABOVE, true)"
                        onmouseout="UnTip()"/>
            </a>
		';
		*/
/*		
		return '
			<a onclick="">
            	<img id=\'summary_'. $articleNumber .'_img\' 
                		src="/images/arrow-right.png"
                        onmouseover="doBlocking(\''. $articleNumber .'\')"
                        onmouseout="doUnblocking(\''. $articleNumber .'\')"/>
            </a>
		';
*/
		// echo "toggleSummary($sectionName, $articleNumber") ";


		
//				document.getElementById(\'submitRow_'. $sectionName. '_'. $articleNumber. '\').focus();
//				alert(\'focus on toggleSummary\');

		return '
			<a onclick="
				toggleSummary(\''. $sectionName. '\', \''. $articleNumber. '\');
				">
            	<img id=\'summary_'. $sectionName. '_'. $articleNumber .'_img\' 
                		src="../images/arrow-right.png" width="20"
				/>
            </a>
		';
	}

	function getSummaryByDesc($articleNumber, $ressource_url, $desc) {
		$summary = $desc;
		
		/*
		$summary = ereg_replace("�", "&uuml;", $summary);
		$summary = ereg_replace("�", "&Uuml;", $summary);
		$summary = ereg_replace("�", "&auml;", $summary);
		$summary = ereg_replace("�", "&Auml;", $summary);
		$summary = ereg_replace("�", "&ouml;", $summary);
		$summary = ereg_replace("�", "&Ouml;", $summary);
		
		$summary = ereg_replace("�", "&szlig;", $summary);
		$summary = ereg_replace("�", "&sect;", $summary);
		$summary = ereg_replace("�", "&laquo;", $summary);
		$summary = ereg_replace("�", "&raquo;", $summary);
		$summary = ereg_replace("�", "&eacute;", $summary);
		$summary = ereg_replace("�", "&euml;", $summary);

		$summary = ereg_replace("'", "&acute;", $summary);
		*/
		
		$htmlDocument = '
			<div class="divArticleSummary" id="summary_'. $articleNumber .'">
				'.$summary.'
			</div>
		';
		
		echo $htmlDocument;
	}
		
	function getSummary02($sectionName, $articleNumber, $summary) {		
		$htmlDocument = '
			<div class="divArticleSummary" id="summary_'. $sectionName. '_'. $articleNumber .'">
				'.$summary.'
			</div>
		';
		
		$htmlDocument = replaceChars_02($htmlDocument);
		
		return $htmlDocument;
	}
	
	function getSummary($articleNumber, $ressource_url) {
		/*
		$htmlDocument = '
			<div class="divArticleSummary" id="summary_'. $articleNumber .'">
				'. $articleNumber .' -- here: use adapter to get article summary<br><br>
				Die auf dem G-20-Gipfel von Pittsburgh verabredeten Untergrenzen f�r die Eigenkapitalausstattung der 
				Banken d�rften vielen europ�ischen Geldinstituten noch schwer zu schaffen machen. Insgesamt fehlen
				ihnen einer Studie zufolge rund 53 Milliarden Euro - auch die deutschen Banken haben viel Nachholbedarf.
			</div>
		';
		*/
		
		$response = @file_get_contents($ressource_url);
		
		if (! strpos($http_response_header[0], "200")) { 
		   return "";
		}
		
		$subject = $response;
		$pattern = '|meta name=\"description\" content=\"([^\"]*)\"|';
		preg_match($pattern, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
		
		$summary = $matches[1][0];
		
		$htmlDocument = '
			<div class="divArticleSummary" id="summary_'. $articleNumber .'">
				'.$summary.'
			</div>
		';
		
		$htmlDocument = replaceChars_02($htmlDocument);
		
		echo $htmlDocument;
	}
?>