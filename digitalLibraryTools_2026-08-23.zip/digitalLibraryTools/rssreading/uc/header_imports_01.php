<?php
	// import all needed php-files here
	
	include("replaceHtmlChars.php");
	// include("newsPortal.php");
?>