<?php
	function getSiteHeadBar($newsportal) {
		$htmlcode = "";
		
		if($newsportal == "ReadingSession") {
			$htmlcode .= ' | <strong>ReadingSession</strong>';
		} else {
			$htmlcode .= ' | <a href="../readingSession/">ReadingSession</a>';
		}
		
		if($newsportal == "Tagesschau") {
			$htmlcode .= ' | <strong>tagesschau.de</strong>';
		} else {
			$htmlcode .= ' | <a href="../rss-tagesschau/">tagesschau.de</a>';
		}
		
		if($newsportal == "Zeit") {
			$htmlcode .= ' | <strong>DIE ZEIT</strong>';
		} else {
			$htmlcode .= ' | <a href="../rss-zeit/">DIE ZEIT</a>';
		}
		
		
		$htmlcode .= ' | ';
		
		/*
		if($newsportal == "FAZ") {
			$htmlcode .= ' | <strong>FAZ</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-faz/">FAZ</a>';
		}
		
		
		if( (strpos($newsportal, "SpiegelOnline")==0) && ($newsportal != "WM2010-HighLights") ) {
			if(strlen($newsportal) == strlen("SpiegelOnline")) {
				$htmlcode .= ' | <strong>SpiegelOnline</strong>';
			} else {
*/				
				/*
				 * here: Focus was set
				 * -> we need to extract Focus-Name
				 */
	
/*	
				$strlen = strlen($newsportal);
				 
				$focus = substr($newsportal, 14, $strlen-14);
				 
				$htmlcode .= ' | <a href="/rss-spiegel/">SpiegelOnline</a>';
				
				if($focus != "") {
					$htmlcode .= ':<strong>'. $focus. '</strong>';
				}
			}
			
		} else {
			$htmlcode .= ' | <a href="/rss-spiegel/">SpiegelOnline</a>';
		}

		if($newsportal == "NTV") {
			$htmlcode .= ' | <strong>N-TV</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-ntv/">N-TV</a>';
		}
		
		if($newsportal == "Golem") {
			$htmlcode .= ' | <strong>Golem</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-golem/">Golem</a>';
		}
		
		if($newsportal == "Sport1") {
			$htmlcode .= ' | <strong>Sport1</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-sport1/">Sport1</a>';
		}
*/
				
/*
		if($newsportal == "FocusOnline") {
			$htmlcode .= ' | <strong>FocusOnline</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-focusonline/">FocusOnline</a>';
		}
*/

/*		
		if($newsportal == "FinancialTimes") {
			$htmlcode .= ' | <strong>FinancialTimes</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-financialtimes/">FinancialTimes</a>';
		}
		
		if($newsportal == "Handelsblatt") {
			$htmlcode .= ' | <strong>Handelsblatt</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-handelsblatt/">Handelsblatt</a>';
		}
*/

/*
		if($newsportal == "WM2010-HighLights") {
			$htmlcode .= ' | <strong>WM2010-HighLights</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-wm2010-highlights/">WM2010-HighLights</a>';
		}
*/
		
/*
		if($newsportal == "HeiseOnline") {
			$htmlcode .= ' | <strong>HeiseOnline</strong>';
		} else {
			$htmlcode .= ' | <a href="/rss-heise/">HeiseOnline</a>';
		}
*/

		$htmlcode .= "\n";
		$htmlcode .= '<hr><br>'. "\n";
		
		return $htmlcode;
	}
?>
