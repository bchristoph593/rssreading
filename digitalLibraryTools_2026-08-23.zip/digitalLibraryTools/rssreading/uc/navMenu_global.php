<?php
	function getNavMenuGlobal() {
		return '
			<a href="index.php">&gt; Aktuelle Nachrichten</a>
			<br />
			<a href="index-wirtschaft.php">&gt; Wirtschaft</a>
			<a href="index-politik.php">&gt; Politik</a>
			<a href="index-netzwelt.php">&gt; Netzwelt</a>
			<a href="index-kultur.php">&gt; Kultur</a>
			<a href="index-sport.php">&gt; Sport</a>
			<a href="index-wissenschaft.php">&gt; Wissenschaft</a>
		';
	}
?>