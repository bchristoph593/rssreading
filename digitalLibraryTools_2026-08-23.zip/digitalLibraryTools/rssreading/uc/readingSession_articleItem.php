<?php
	function getArticleItem($sectionName, $position, $date, $linkURL, $linkTitle, $itemDescription) {
		// echo "section: ".$sectionName."<br>";
		// echo "position: ".$position."<br>";
		
		$linkTitle = preg_replace('/"/', "&#8221;", $linkTitle);
		
		$itemDescription = preg_replace("/s' F/", "s_ F", $itemDescription);
		
		return '
			<div id="divContainer_'. $sectionName. '_'. $position. '">
			  <div class="divArticleItem">
			    <table style="border: 0px solid black;">
			    <tr>
			      <td><div class="divArticleDate">'.$date.'</div></td>
				  <td><div class="divShowSummary">'.getShowSummary($sectionName, $position).'</div></td>
				  <td>
				    <div class="divArticleLink"  
					  >'
					  .getAnker($linkURL, $linkTitle, $sectionName. '_'. $position).'
					</div>
				  </td>
		        </tr>
			    <tr>
			      <td></td>
				  <td></td>
				  
				  <td>'.getSummary02($sectionName, $position, $itemDescription).'</td>
				  
			    </tr>
			    </table>

			    <div style="clear:both"></div>
				
			  </div>
			</div>			
		';
	}
?>