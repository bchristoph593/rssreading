<?php
	function getAnker($url, $urlName, $idContainerSuffix) {
		$redirect_mod = "http://www.betodate.de/show.php";
		$redirect_param = "?ref=";
		
		$redirect = $redirect_mod. $redirect_param. $url;
		
		// $urlName = replaceChars($urlName);
		
		
		// if(SID == "SID") {
		if(session_id() == "SID") {
			$htmlAnker = '
				<a target="_blank" href="'.$redirect.'" onclick="javascript:visit(\''.$idContainerSuffix.'\');">
					'.$urlName.'
				</a>
			';
		} else {
			
			/*
			 * when the user has a session and is logged in:
			 * - collect the clicked urls
			 * - user has assigned a list of sessions
			 * - each session has assigned a list of urls
			 */
			 /*
			  * <a href="javascript:void();" onclick="visit(\''.$idContainerSuffix.'\'); // alert(\''.SID.'\');">
			  */
			$htmlAnker = '
				<a target="_blank" href="'.$url.'" onclick="wndLocalStorage_appendArticleLinkUrl(\''. $url. '\');">
					'.$urlName.'
				</a>
			';
		}
		
		return $htmlAnker;
	}
?>