<?php
	function getArticleItem($sectionName, $position, $date, $linkURL, $linkTitle, $itemDescription) {
		// echo "section: ".$sectionName."<br>";
		// echo "position: ".$position."<br>";
		
		$linkTitle = preg_replace('/"/', "&#8221;", $linkTitle);
		
		$itemDescription = preg_replace("/s' F/", "s_ F", $itemDescription);
		
		return '
			<div id="divContainer_'. $sectionName. '_'. $position. '">
			  <div class="divArticleItem">
			    <table style="border: 0px solid black;">
			    <tr>
			      <td><div class="divArticleDate">'.$date.'</div></td>
				  <td><div class="divShowSummary">'.getShowSummary($sectionName, $position).'</div></td>
				  <td>
				    <div class="divArticleLink"  
					  onclick="visit(\''.$sectionName. '_'. $position.'\');">'
					  .getAnker($linkURL, $linkTitle, $sectionName. '_'. $position).'
					</div>
				  </td>
		        </tr>
			    <tr>
			      <td></td>
				  <td></td>
				  
				  <td>'.getSummary02($sectionName, $position, $itemDescription).'</td>
				  
			    </tr>
			    </table>

			    <div style="clear:both"></div>
				
				<form id="frm_'.$sectionName. '_'. $position. '" 
					target="_blank" 
					action="http://localhost/digitalLibraryTools/knowledgeLibrary/BrowsingSession_appendTWRI-Structure.php" 
					method="POST" 
					style="border: 0px solid black;">
			    <table style="border: 0px solid black; width:700px;">
				  <tr style="display:none;">
				    <td style="border: 1px solid black;">
					  <div style="width:210px; border: 1px solid black;">Date:</div>
					</td>
					<td>
					  <div><input name="txtDocDate" size="25" value="'.$date.'" /></div>
					</td>
				  </tr>
				  <tr style="display:none;">
				    <td style="border: 1px solid black;">
					  <div style="width:210px; border: 1px solid black;">Link:</div>
					</td>
					<td>
					  <div><input name="txtDocURL" size="50" value="'.$linkURL.'" /></div>
					</td>
				  </tr>
				  <tr style="display:none;">
				    <td style="border: 1px solid black;">
					  <div style="width:210px; border: 1px solid black;">Title:</div>
					</td>
					<td>
					  <div><input name="txtDocTitle" size="50" value="'.$linkTitle.'" /></div>
					</td>
				  </tr>
				  <tr style="display:none;">
				    <td style="border: 1px solid black;">
					  <div style="width:210px; border: 1px solid black;">Summary:</div>
					</td>
					<td>
					  <div><textarea name="txtDocSummary" rows="4" cols="50">'.$itemDescription.'</textarea>
					  </div>
					</td>
				  </tr>
				  
				  <tr id="submitRow_'.$sectionName. '_'. $position.'" style="display:none;">
				    <td style="border: 0px solid black;">
					  <div style="width:210px; border: 0px solid black;"></div>
					</td>
					<td>
					  <div><input 
									type="submit" 
									id="submitBtn_'.$sectionName. '_'. $position.'"
									onclick="toggleSummary(\''.$sectionName.'\', \''.$position.'\'); visit(\''.$sectionName. '_'. $position.'\');" 
									value="Precollect ArticleItem" />
					  </div>
					</td>
				  </tr>
				</table>
				</form>
				
			  </div>
			</div>			
		';
	}
?>