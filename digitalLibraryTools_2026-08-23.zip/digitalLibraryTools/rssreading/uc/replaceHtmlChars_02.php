<?php
	function replaceChars_02($htmlDocument) {
		// replace &quot; with "


		$htmlDocument = preg_replace("/d'I/","d&apos;I", $htmlDocument);
		// $htmlDocument = htmlspecialchars(preg_replace("/d'I/","d&apos;I",$htmlDocument),ENT_QUOTES);
		// $htmlDocument = htmlspecialchars($htmlDocument, ENT_QUOTES);

		// $htmlDocument = preg_replace("/s' F/","s&apos; F", $htmlDocument);



		
		// $htmlDocument = ereg_replace("<doc>", "", $htmlDocument);
		// $htmlDocument = ereg_replace("</doc>", "", $htmlDocument);
		
		
		/*
		$htmlDocument = ereg_replace("ü", "&uuml;", $htmlDocument);
		$htmlDocument = ereg_replace("Ü", "&Uuml;", $htmlDocument);
		$htmlDocument = ereg_replace("ä", "&auml;", $htmlDocument);
		$htmlDocument = ereg_replace("Ä", "&Auml;", $htmlDocument);
		$htmlDocument = ereg_replace("ö", "&ouml;", $htmlDocument);
		$htmlDocument = ereg_replace("Ö", "&Ouml;", $htmlDocument);
		
		$htmlDocument = ereg_replace("ß", "&szlig;", $htmlDocument);
		$htmlDocument = ereg_replace("§", "&sect;", $htmlDocument);
		$htmlDocument = ereg_replace("«", "&laquo;", $htmlDocument);
		$htmlDocument = ereg_replace("»", "&raquo;", $htmlDocument);
		$htmlDocument = ereg_replace("é", "&eacute;", $htmlDocument);
		$htmlDocument = ereg_replace("ë", "&euml;", $htmlDocument);
		
		// Here: Escape "'" - Character inside $htmlDocument
		$htmlDocument = ereg_replace("'er", "&acute;er", $htmlDocument);
		*/
		
		
		// $urlName = htmlspecialchars($urlName);
		
		// echo "before: ".$urlName;
		// echo "<br>";
		
		// $urlName = htmlentities($urlName);
		// echo "next: ".$urlName;
		// echo "<br>";
		
		
		// $urlName = htmlspecialchars($urlName, ENT_QUOTES, 'UTF-8', false);
		// $urlName = htmlspecialchars($urlName, ENT_QUOTES, 'ISO-8859-1', false);
		// $htmlDocument = htmlentities($htmlDocument);
		
		// $htmlDocument = preg_replace('/d\'I/', 'd\'I', $htmlDocument);
		
		/*
		$urlName = htmlspecialchars($urlName);
		$urlName = htmlentities($urlName);
		$urlName = utf8_decode($urlName);
		*/
		
		/*
		
		$urlName = preg_replace('/ä/', '&auml;', $urlName);
		$urlName = preg_replace('/Ä/', '&Auml;', $urlName);
		$urlName = preg_replace('/ü/', '&uuml;', $urlName);
		$urlName = preg_replace('/Ü/', '&Uuml;', $urlName);
		$urlName = preg_replace('/ö/', '&ouml;', $urlName);
		$urlName = preg_replace('/Ö/', '&Ouml;', $urlName);
		
		$urlName = preg_replace('/ß/', '&szlig;', $urlName);
		$urlName = preg_replace('/§/', '&sect;', $urlName);
		*/
		
		/*
		echo $urlName.'<br>';
		
		$pattern = '#das'.preg_quote($urlName,'#').'#i';
		echo "pattern".$pattern;
		echo preg_match($pattern, $urlName);
		*/
		
		/*
		if(preg_match($pattern, $urlName) {		
			echo "someText";
		}
		*/
		
		/*
		$htmlDocument = preg_replace('/«/', '&laquo;', $htmlDocument);
		$htmlDocument = preg_replace('/»/', '&raquo;', $htmlDocument);
		$htmlDocument = preg_replace('/é/', '&eacute;', $htmlDocument);
		$htmlDocument = preg_replace('/ë/', '&euml;', $htmlDocument);
		*/
		
			// Here: Escape "'" - Character inside $htmlDocument
			/*
			$htmlDocument = preg_replace('/\'er/', '\'er', $htmlDocument);
			
			$htmlDocument = preg_replace('/ \'Nd/', ' \'Nd', $htmlDocument);
			$htmlDocument = preg_replace('/&amp;/', '&', $htmlDocument);
			*/
			
			/*
			$htmlDocument = ereg_replace("&#8222;", "\"", $htmlDocument);
			$htmlDocument = ereg_replace("&#8220;", "\"", $htmlDocument);
			$htmlDocument = ereg_replace("&#8211;", "-", $htmlDocument);
			$htmlDocument = ereg_replace("&#8217;", "\'", $htmlDocument);
			// $htmlDocument = ereg_replace("�", "&szlig;", $htmlDocument);
			
			$htmlDocument = ereg_replace("es' ", "es\' ", $htmlDocument);

			$htmlDocument = ereg_replace(" ([A-Z])'([A-Z])", " \\1\'\\2", $htmlDocument);
			
			$htmlDocument = ereg_replace("ht''", "ht\''", $htmlDocument);
			$htmlDocument = ereg_replace("uh''", "uh\''", $htmlDocument);
			$htmlDocument = ereg_replace("r'' ", "r\'\' ", $htmlDocument);

			$htmlDocument = ereg_replace("l'\" ", "l\'\" ", $htmlDocument);
			$htmlDocument = ereg_replace("e'\" ", "e\'\" ", $htmlDocument);
			
			$htmlDocument = ereg_replace(" ''K", " \'\'K", $htmlDocument);
			
			$htmlDocument = ereg_replace("'schen", "\'schen", $htmlDocument);
			
			$htmlDocument = ereg_replace("ht's", "ht\'s", $htmlDocument);

			$htmlDocument = ereg_replace("([a-z])'([a-z])", "\\1\'\\2", $htmlDocument);
			$htmlDocument = ereg_replace("([a-z])'([A-Z])", "\\1\'\\2", $htmlDocument);
			$htmlDocument = ereg_replace("([A-Z])'([A-Z])", "\\1\'\\2", $htmlDocument);
			$htmlDocument = ereg_replace("([A-Z])'([a-z])", "\\1\'\\2", $htmlDocument);

			$htmlDocument = ereg_replace("([a-z])'(\":)", "\\1\'\\2", $htmlDocument);

			$htmlDocument = ereg_replace("([a-z])'\?", "\\1\'\?", $htmlDocument);
			
			$htmlDocument = ereg_replace("([a-z])' -", "\\1\' -", $htmlDocument);
			$htmlDocument = ereg_replace("([a-z])', ([a-z])", "\\1\', \\2", $htmlDocument);
			$htmlDocument = ereg_replace("([a-z])', ([A-Z])", "\\1\', \\2", $htmlDocument);
			
			$htmlDocument = ereg_replace("([a-z]) '([a-z])", "\\1 \'\\2", $htmlDocument);
			$htmlDocument = ereg_replace("([a-z]) '([A-Z])", "\\1 \'\\2", $htmlDocument);
			$htmlDocument = ereg_replace("- '([A-Z])", "- \'\\1", $htmlDocument);
			$htmlDocument = ereg_replace(": '([A-Z])", ": \'\\1", $htmlDocument);
			$htmlDocument = ereg_replace(": '([0-9])", ": \'\\1", $htmlDocument);


			$htmlDocument = ereg_replace("-' ([a-z])", "-\' \\1", $htmlDocument);
			$htmlDocument = ereg_replace("([a-z])' ([a-z])", "\\1\' \\2", $htmlDocument);
			$htmlDocument = ereg_replace("([a-z])' ([A-Z])", "\\1\' \\2", $htmlDocument);
			$htmlDocument = ereg_replace("(�)' ([A-Z])", "\\1\' \\2", $htmlDocument);

			$htmlDocument = ereg_replace("([a-z])'  ([a-z])", "\\1\'  \\2", $htmlDocument);
			$htmlDocument = ereg_replace("([a-z])'  ([A-Z])", "\\1\'  \\2", $htmlDocument);
			*/
			
		return $htmlDocument;
	}
?>