<?php
	class NewsPortal {
		var $xslSheetPath;
		var $rssFilePath;
		
		public function __construct() {}
		
		/*
		 *	Setters
		 */
		public function setXSLSheet($xslSheetPath) {
			$this->xslSheetPath = $xslSheetPath;
		}
		
		public function setRSSFile($rssFilePath) {
			$this->rssFilePath = $rssFilePath;
		}
		
		/*
		 *	Transform RSS with XSL -> Html-Document
		 */
		public function doProcessing() {
			
			$xslDoc = new DOMDocument();
			echo "[newsPortal] xslSheetPath: ". $this->xslSheetPath. "<br />";
			$xslDoc->load( $this->xslSheetPath );
			
			$xmlDoc = new DOMDocument();			
			echo "[newsPortal] rssFilePath: ". $this->rssFilePath. "<br />";
			$xmlDoc->load( $this->rssFilePath );
			
			
			
			// echo "[newsPortal] rssFilePath 01: ". $this->rssFilePath. "<br />";
			// $rssFileStr = $this->rssFilePath;
			
			// echo "[newsPortal] rssFilePath 02: ". 'http://localhost/digitalLibraryTools/knowledgeLibrary/BrowsingSession_xmlDataFile.xml'. "<br />";
			// $rssFileStr = 'http://localhost/digitalLibraryTools/knowledgeLibrary/BrowsingSession_xmlDataFile.xml';
			
			// $xmlString = file_get_contents( $rssFileStr );
			// $xml = simplexml_load_string($xmlString); 			
			
			// print_r($xmlString);
			
			// print_r($xml);
			
			// $xmlDoc = new DOMDocument();
			// $xmlDoc->loadXML($xmlString);	
			
			
			$proc = new XSLTProcessor();
			$proc->importStylesheet($xslDoc);
			
			$htmlDocument = $proc->transformToXML($xmlDoc);
			
			echo $htmlDocument;
			
			return;
			
			// $htmlDocument = replaceChars($htmlDocument);

			/*
				  Here: 
				    - There is the XML-Node 'description'.;
				    - It contains the substring: 'Mit der Diskussion um Wim Wenders' Film "Falsche Bewegung"'.;
					- Here we need to quote the char sequence: 'Wenders' Film' into something like 'Wenders&#39; Film'.; 
			*/

			$htmlDocument = preg_replace("/s' F/", "s&#39; F", $htmlDocument);
			$htmlDocument = preg_replace("/z' W/", "z&#39; W", $htmlDocument);
			
			$fh1 = fopen("temp.php", "w");
			
			fwrite($fh1, $htmlDocument);
			fclose($fh1);
		}
		
	}
?>
