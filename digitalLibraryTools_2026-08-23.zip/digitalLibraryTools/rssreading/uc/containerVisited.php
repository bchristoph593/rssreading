<?php
	function getContainerListVisited($sectionName, $countItems) {
		$containerListVisited = "";
		
		$containerListVisited .= '<div style="display:none" id="divContainerVisited_'. $sectionName. '">';
		$containerListVisited .= '
			<div style="width:190px; display:block">
				<hr />
            </div>
		';
		
		for($i=1; $i<=$countItems; $i++) {
			$containerListVisited .= '
				<div id="divContainerVisited_'. $sectionName. '_'. $i. '">
				</div>
			';
		}
		
		$containerListVisited .= "</div>";
		
		return $containerListVisited;
	}
?>