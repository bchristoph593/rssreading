<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

  <html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta><meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>tagesschau.de | Schlagzeilen - rssreading</title><link rel="shortcut icon" href="../images/favicon/fav-tagesschau.ico"></link><link href="../css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="../js/unfold.js"></script><script type="text/javascript" src="../js/visitLink.js"></script><script type="text/javascript" src="../js/wndLocalStorage.js"></script><script type="text/javascript">
          </script><?php 
					include("../uc/header_imports_02.php");
				?><?php 
					include("../uc/articleItem.php");
				?><?php 
					include("../uc/articleLink.php");
				?><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Tagesschau");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="../rss-tagesschau/">
							  &gt; Alle Nachrichten (<?php 
								  echo '40';
								?>)</a></div></div><div class="divContent"><strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; tagesschau.de - Die Nachrichten der ARD</strong><hr></hr><strong xmlns="">&gt; Ausland (<?php 
		  echo '11';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'ausland',
                    	'1',
                    	'23 Aug 2026 08:17:34',
                    	'https://www.tagesschau.de/ausland/afrika/nigeria-angriff-102.html',
                    	'Tote und Entführte bei Angriff auf Dorf in Nigeria',
                    	'In Nigeria haben Islamisten ein Dorf überfallen. Dutzende Menschen wurde getötet oder entführt - wie viele genau, ist unklar. Hinter dem Angriff steckt offenbar ein Ableger der Terrorgruppe "Islamischer Staat".'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'2',
                    	'23 Aug 2026 06:37:22',
                    	'https://www.tagesschau.de/ausland/amerika/schildkroeten-in-mexiko-touristenhit-100.html',
                    	'Schildkröten in Mexiko: Vom gefundenen Fressen zum Touri-Highlight',
                    	'Einst vor allem bei Wilderern berühmt, hat sich ein kleiner Strand im mexikanischen Bundesstaat Oaxaca mittlerweile zum Paradies für Ökotourismus gewandelt. Die Stars sind Meeresschildkröten. Von Christina Fee Moebus.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'3',
                    	'23 Aug 2026 09:19:06',
                    	'https://www.tagesschau.de/ausland/amerika/zollstreit-usa-kanada-eskaliert-100.html',
                    	'Experte warnt vor "Handelskrieg" zwischen Kanada und USA ',
                    	'Die Zoll-Gespräche zwischen den USA und Kanada sind gescheitert - jetzt treten neue US-Zölle in Kraft. Ein neuer "Handelskrieg" droht, denn Kanada will mit Gegenzöllen antworten. Beide Seiten geben sich gegenseitig die Schuld.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'4',
                    	'23 Aug 2026 05:03:07',
                    	'https://www.tagesschau.de/ausland/asien/parlamentswahl-in-kasachstan-100.html',
                    	'Kasachstan wählt neues Parlament',
                    	'2019 beerbte der kasachische Präsident Tokajew den Langzeitherrscher Nasarbajew. Doch Hoffnungen auf demokratische Veränderungen bleiben unerfüllt. Heute wird ein neues Parlament gewählt - nach umfassenden Verfassungsänderungen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'5',
                    	'22 Aug 2026 21:29:05',
                    	'https://www.tagesschau.de/ausland/asien/china-roboter-lauf-100.html',
                    	'China: Humanoider Roboter schneller über 100 Meter als Usain Bolt',
                    	'Bei der Weltmeisterschaft humanoider Roboter in China hat ein chinesisches Modell den 100-Meter-Weltrekord von Usain Bolt unterboten. Es war nicht das erste Mal, dass Roboter schneller als Menschen laufen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'6',
                    	'22 Aug 2026 16:41:06',
                    	'https://www.tagesschau.de/ausland/afrika/tunesien-migranten-bootunglueck-100.html',
                    	'Mindestens 13 Migranten nach Bootsunglück vor Tunesien vermisst',
                    	'Bei einem Unglück vor der Küste Tunesiens sind offenbar mehrere Menschen ertrunken. Nachdem ihr Boot gekentert war, konnten bislang nur zwei Personen gerettet werden. Auch Minderjährige und eine Schwangere werden vermisst.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'7',
                    	'22 Aug 2026 15:34:42',
                    	'https://www.tagesschau.de/ausland/amerika/usa-transmenschen-100.html',
                    	'Druck auf Transmenschen in den USA: "Das ist entmenschlichend"',
                    	'Seit der Rückkehr ins Weiße Haus versucht die Trump-Administration, Rechte von Transmenschen zu mindern. Zuletzt wurde die Zahlung für Behandlungen von Transjugendlichen gestoppt. Wie lebt die Community damit? Von Marc Feuser.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'8',
                    	'22 Aug 2026 04:45:27',
                    	'https://www.tagesschau.de/ausland/asien/israel-siedlungspolitik-eu-100.html',
                    	'Siedlungsbau im Westjordanland: Stresstest für Israels Verhältnis zu Europa',
                    	'Israel treibt den Bau neuer Siedlungen voran, sie könnten einen zusammenhängenden Palästinenserstaat unmöglich machen. Westliche Staaten verurteilen die Pläne, die EU diskutiert Sanktionen - und das Verhältnis zu Israel leidet weiter. Von Julia Ley.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'9',
                    	'22 Aug 2026 00:04:29',
                    	'https://www.tagesschau.de/ausland/afrika/mauretanien-rettung-migranten-100.html',
                    	'Mehr als 300 Migranten von Holzboot vor Mauretanien gerettet',
                    	'Vor der Küste Mauretaniens hat die Küstenwache mehr als 300 Menschen von einem manövrierunfähigen Holzboot gerettet. Sie waren wohl auf dem Weg zu den Kanarischen Inseln - eine Route, die immer gefährlicher wird.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'10',
                    	'21 Aug 2026 21:27:17',
                    	'https://www.tagesschau.de/ausland/amerika/un-generalsekretaer-auswahl-100.html',
                    	'Diplomatin Birkett führt bei Testabstimmung über Amt des UN-Generalsekretärs',
                    	'Wer folgt auf Guterres? In einer zweiten Abstimmung setzte sich die Guyanerin Birkett an die Spitze der Liste für das Amt des UN-Generalsekretärs. Die Präsidentin der Generalversammlung Baerbock wirbt für mehr Transparenz - und wird dafür angefeindet.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland',
                    	'11',
                    	'21 Aug 2026 17:21:40',
                    	'https://www.tagesschau.de/ausland/asien/iran-krieg-peseschkian-100.html',
                    	'Irans Präsident sieht guten Zeitpunkt für Kriegsende mit den USA',
                    	'Trotz der massiven US-Angriffe im vergangenen halben Jahr scheint das iranische Regime weiter fest an der Macht zu sein. Präsident Peseschkian spricht sich jetzt für ein Ende des Krieges aus. Er sieht sein Land im Vorteil.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'ausland',
                    	'11'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Ausland - Europa (<?php 
		  echo '12';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'1',
                    	'23 Aug 2026 09:02:36',
                    	'https://www.tagesschau.de/ausland/europa/russland-urlaub-krieg-100.html',
                    	'Krieg gegen die Ukraine: Urlaub unter Beschuss an Russlands Küste',
                    	'Es ist Sommer, und die Menschen in Russland zieht es an die Strände der Schwarzmeerküste. Doch dort gibt es zunehmend Luftalarm - und so zeigt sich der Krieg gegen die Ukraine den Russen auch im Urlaub. Von Silke Diettrich.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'2',
                    	'23 Aug 2026 02:04:59',
                    	'https://www.tagesschau.de/ausland/europa/schweden-nach-schwertangriff-100.html',
                    	'Schwertangriff in Schweden: Wenn plötzlich das Grauen zu spüren ist',
                    	'Nach dem Schwertangriff an einer schwedischen Schule am vergangenen Freitag bleibt die Provinzstadt Fagersta fassungslos zurück. Ein Mädchen wurde getötet, zwei Schüler schwer verletzt. Wie umgehen mit dieser Tat? Von Christian Stichler.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'3',
                    	'22 Aug 2026 18:25:33',
                    	'https://www.tagesschau.de/ausland/europa/ukraine-wadephul-106.html',
                    	'Wadephul verspricht der Ukraine weitere humanitäre Hilfe',
                    	'Bei seinem Besuch in der Hauptstadt Kiew hat Bundesaußenminister Wadephul der Ukraine weitere 50 Millionen Euro an humanitärer Hilfe zugesagt. Die anhaltenden russischen Angriffe auf das Land nannte er einen "wahllosen Mord an Zivilisten".'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'4',
                    	'22 Aug 2026 13:23:43',
                    	'https://www.tagesschau.de/ausland/europa/schweden-fagersta-schwertangriff-100.html',
                    	'Trauer und Fassungslosigkeit nach Schwertangriff in Schweden',
                    	'Der Angriff an einer Schule schockiert Schweden. Ein 18-Jähriger hatte gestern mit einem Schwert eine Schülerin getötet und mehrere verletzt. Der Täter soll frühere Schulmassaker verherrlicht haben. Von Christian Stichler.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'5',
                    	'22 Aug 2026 11:15:40',
                    	'https://www.tagesschau.de/ausland/europa/russland-jabloko-rybakow-wahlausschluss-100.html',
                    	'Jabloko-Chef Rybakow: "In Russland denken viele wie wir"',
                    	'Die russische Oppositionspartei Jabloko lehnt den Ukraine-Krieg ab und darf nach einem Gerichtsurteil nicht an der Parlamentswahl im September teilnehmen. Parteichef Rybakow spricht im Interview über die Gründe dafür - und über den Rückhalt im Land.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'6',
                    	'22 Aug 2026 10:16:59',
                    	'https://www.tagesschau.de/ausland/europa/ukraine-russland-angriffe-ozon-krywyj-rih-100.html',
                    	'Zahl der Todesopfer nach Angriff auf ukrainisches Einkaufszentrum gestiegen',
                    	'Nach dem russischen Drohnenangriff auf ein Einkaufszentrum in Krywyj Rih ist die Zahl der Toten auf 16 gestiegen. Die Ukraine attackierte erneut eine russische Ölraffinerie und einen Logistikbetrieb - dieses Mal nicht Wildberries.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'7',
                    	'22 Aug 2026 14:19:28',
                    	'https://www.tagesschau.de/ausland/europa/ukraine-wadephul-100.html',
                    	'Außenminister Wadephul zu unangekündigtem Besuch in der Ukraine',
                    	'Inmitten neuer russischer Angriffe ist Außenminister Wadephul in die Ukraine gereist. Er warf der Führung in Moskau "wahllosen Mord an Zivilisten" vor. Gleichzeitig sprach er von Zeichen der Schwäche im russischen Regime.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'8',
                    	'21 Aug 2026 20:30:11',
                    	'https://www.tagesschau.de/ausland/europa/ukraine-korruption-selenskyj-102.html',
                    	'Korruptionsskandal in der Ukraine weitet sich aus',
                    	'Der jüngste Korruptionsskandal in der Ukraine weitet sich aus: Eine beteiligte staatseigene Bank soll privatisiert werden. Auch im Umfeld des Präsidenten wird ermittelt. Die Opposition erhebt schwere Vorwürfe. Von Florian Kellermann.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'9',
                    	'21 Aug 2026 22:26:30',
                    	'https://www.tagesschau.de/ausland/europa/russland-angriff-einkaufszentrum-100.html',
                    	'Tote und Verletzte nach Angriffen auf ukrainisches Einkaufszentrum',
                    	'Russland hat ein belebtes Einkaufszentrum in der Heimatstadt des ukrainischen Präsidenten angegriffen. Es gibt viele Tote und Verletzte. Selenskyj spricht von einem "hinterhältigen Angriff" in zwei Wellen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'10',
                    	'21 Aug 2026 18:35:44',
                    	'https://www.tagesschau.de/ausland/europa/ukraine-zeichentrickserie-russland-100.html',
                    	'Ukraine verbietet beliebte Zeichentrickserie "Mascha und der Bär"',
                    	'Die ukrainische Regierung hat die beliebte russische Animationsserie "Mascha und der Bär" verboten. Sie darf im Land nicht mehr gezeigt werden. Hintergrund sind die Werbeeinnahmen durch die Serie, die Russland zugutekommen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'11',
                    	'21 Aug 2026 18:00:40',
                    	'https://www.tagesschau.de/ausland/europa/daily-mail-prozesskosten-harry-elton-john-100.html',
                    	'Prinz Harry und Elton John müssen Prozesskosten in Millionenhöhe begleichen',
                    	'Eine Woche haben Prinz Harry, Elton John und weitere Kläger Zeit, um Prozesskosten in Höhe von elf Millionen Euro zu begleichen. Sie hatten eine Klage wegen möglicher Verletzung der Privatsphäre gegen die Zeitung Daily Mail verloren.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'ausland-europa',
                    	'12',
                    	'21 Aug 2026 22:01:48',
                    	'https://www.tagesschau.de/ausland/europa/schwertangriff-schweden-100.html',
                    	'Ein Toter nach Schwertangriff an schwedischer Schule',
                    	'In einer Schule in einer Kleinstadt in Zentralschweden hat ein 18-Jähriger mit einem Schwert mehrere Personen angegriffen. Ein Mensch starb, drei weitere wurden verletzt. Die Polizei nahm den mutmaßlichen Täter fest.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'ausland-europa',
                    	'12'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Inland (<?php 
		  echo '8';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'inland',
                    	'1',
                    	'23 Aug 2026 03:29:20',
                    	'https://www.tagesschau.de/inland/evg-droht-mit-streiks-im-regionalverkehr-100.html',
                    	'Eisenbahngewerkschaft EVG droht mit Blockade im Regionalverkehr',
                    	'Seit dem tödlichen Angriff auf einen Zugbegleiter in einem Regionalexpress Anfang Februar werden Maßnahmen für mehr Sicherheit diskutiert. Die Eisenbahngewerkschaft EVG fordert nun Ergebnisse - und droht mit einer Blockade der Dienstpläne.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'2',
                    	'23 Aug 2026 02:21:07',
                    	'https://www.tagesschau.de/inland/innenpolitik/wie-geht-es-nach-der-sommerpause-weiter-bundesregierung-100.html',
                    	'Merz will Reformbeschlüsse so schnell wie möglich umsetzen ',
                    	'Nach der Urlaubszeit kommen Bundeskanzler Merz und die Minister in der kommenden Woche zur Klausur in Brandenburg zusammen. Merz will die beschlossenen Reformen voranbringen - trotz des Gegenwindes, der in drei Wochen Urlaub aufkam.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'3',
                    	'22 Aug 2026 19:59:00',
                    	'https://www.tagesschau.de/inland/gesellschaft/kuenstliche-intelligenz-justiz-100.html',
                    	'Wie Künstliche Intelligenz die Justiz ausbremst',
                    	'Vor allem die Sozialgerichte erleben das Phänomen: Immer mehr Kläger nutzen offenbar Künstliche Intelligenz, um Eingaben zu formulieren. Für die Justiz bedeutet das viel Arbeit mit teils unsinnigen Schriftsätzen. Von T. Denzel.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'4',
                    	'22 Aug 2026 17:06:54',
                    	'https://www.tagesschau.de/inland/innenpolitik/merz-waldbrand-eifel-100.html',
                    	'Kanzler Merz dankt Helfern im Waldbrandgebiet in NRW',
                    	'Nach dem Waldbrand im nordrhein-westfälischen Hürtgenwald hat der Kanzler den Helfern gedankt. Zu spät sei sein Besuch gekommen, sagen Anwohner. Doch die Rettungskräfte loben das Timing des Kanzlers.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'5',
                    	'22 Aug 2026 14:12:54',
                    	'https://www.tagesschau.de/inland/innenpolitik/merz-waldbrand-besuch-100.html',
                    	'Kanzler Merz besucht Waldbrandgebiet in NRW',
                    	'Sommerpause, Urlaub, terminfreie Zeit: Für die Abwesenheit von Kanzler Merz gibt es viele Begriffe. Doch nun ist er wieder da - im Waldbrandgebiet in NRW. Dort ist das Feuer gelöscht, für die Brandherde des Kanzlers gilt das nicht.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'6',
                    	'22 Aug 2026 14:10:42',
                    	'https://www.tagesschau.de/inland/innenpolitik/uebergewinnsteuer-klingbeil-eu-100.html',
                    	'Klingbeil macht Vorstoß für Übergewinnsteuer bei Ölkonzernen',
                    	'Während die Spritpreise im Zuge des Iran-Kriegs stark gestiegen sind, machen Ölkonzerne höhere Gewinne. Finanzminister Klingbeil will diese deshalb zur Kasse bitten und fordert - zusammen mit anderen EU-Staaten - eine Übergewinnsteuer.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'7',
                    	'22 Aug 2026 11:07:06',
                    	'https://www.tagesschau.de/inland/innenpolitik/hubig-queere-menschen-grundgesetz-100.html',
                    	'Justizministerin Hubig will mehr Schutz für queere Menschen',
                    	'Der Anschlag auf den CSD in Berlin Ende Juli hat die queere Community schwer getroffen. Justizministerin Hubig will nun einen besseren Schutz durchsetzen - mit einer Grundgesetzänderung. Spielt die Union mit?'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'inland',
                    	'8',
                    	'22 Aug 2026 08:47:35',
                    	'https://www.tagesschau.de/inland/gesellschaft/diebstahl-senioren-pflege-100.html',
                    	'Diebstahl in der Pflege: Wie sich Betroffene schützen können',
                    	'Pflege- und hilfsbedürftige Menschen können leicht zu Opfern von Diebstahl werden. Die Kriminalstatistik zeigt, dass bei ihnen immer öfter Wertsachen entwendet werden. Was die Polizei rät. Von Peter Allgaier und Oliver Christa.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'inland',
                    	'8'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Wirtschaft (<?php 
		  echo '5';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'1',
                    	'22 Aug 2026 17:09:13',
                    	'https://www.tagesschau.de/wirtschaft/unternehmen/aldi-lidl-discounter-wettbewerb-100.html',
                    	'Aldi gegen Lidl: Discounter-Zoff um den günstigsten Preis',
                    	'Die deutschen Discounter liefern sich einen Preiskampf. Aldi setzt auf den besten Preis für alle - ganz ohne Bonus-App. Lidl kontert digital. Wer hat die bessere Strategie? Von Anke Heinhaus.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'2',
                    	'22 Aug 2026 13:02:46',
                    	'https://www.tagesschau.de/wirtschaft/technologie/humanoide-roboter-deutschland-industrie-china-100.html',
                    	'Humanoide Roboter: Kann Deutschland beim Boom mithalten?',
                    	'China gibt bei humanoiden Robotern das Tempo vor. Doch Deutschland hat durchaus Chancen - ausgerechnet für die kriselnden Autozulieferer könnte der neue Milliardenmarkt zum Wachstumstreiber werden. Von Angela Göpfert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'3',
                    	'22 Aug 2026 19:04:55',
                    	'https://www.tagesschau.de/wirtschaft/weltwirtschaft/usa-kanada-handelsstreit-zoelle-100.html',
                    	'Handelsgespräche gescheitert - USA verhängen neue Zölle gegen Kanada',
                    	'Die Verhandlungen über ein Handelsabkommen zwischen den USA und Kanada sind gescheitert. Washington setzte daraufhin weitere Zölle in Kraft. Die Reaktion des Nachbarn fällt hart aus: Regierungschef Carney spricht von Vergeltung.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'4',
                    	'22 Aug 2026 03:03:05',
                    	'https://www.tagesschau.de/wirtschaft/unternehmen/tiktok-vergleich-usa-100.html',
                    	'US-Ermittlungen gegen TikTok enden mit 400-Millionen-Dollar-Vergleich',
                    	'Die US-Regierung warf TikTok vor, illegal Daten von Kindern gesammelt zu haben. Nach dem Besitzerwechsel im US-Geschäft und einer Zahlung von mehreren hundert Millionen Dollar enden die Ermittlungen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'5',
                    	'21 Aug 2026 18:27:50',
                    	'https://www.tagesschau.de/wirtschaft/finanzen/marktberichte/marktbericht-dax-dow-staatsschulden-100.html',
                    	'Marktbericht: DAX geht mit Gewinn aus der Woche',
                    	'Nach vier Verlusttagen in Folge ist der DAX heute mit einem Plus aus dem Handel gegangen. Auf Wochensicht schneidet der Leitindex schlechter ab. Die Risiken bleiben.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'5'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sport (<?php 
		  echo '0';
		?>)
		</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sonstige (<?php 
		  echo '4';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'23 Aug 2026 10:28:46',
                    	'https://www.tagesschau.de/wissen/gottesanbeterin-ausbreitung-erderwaermung-100.html',
                    	'Gottesanbeterin breitet sich in Deutschland aus',
                    	'Lange galt sie hierzulande als Exotin, doch mittlerweile hat sich die Gottesanbeterin sprunghaft verbreitet - eine Folge des Klimawandels. Vor allem in zwei Regionen Deutschlands ist das Insekt zu finden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'22 Aug 2026 13:35:22',
                    	'https://www.tagesschau.de/wissen/gesundheit/longevity-langlebigkeit-supplements-nahrungsergaenzung-100.html',
                    	'Langlebigkeit - Hype oder wissenschaftlich belegbar? ',
                    	'Wie kann es gelingen, möglichst gesund alt zu werden? Ist Longevity nur ein Hype oder gibt es wissenschaftliche Fakten? Ein Kongress im September will informieren. Initiator Kluge rät im Interview zur Vorsicht.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'22 Aug 2026 04:48:05',
                    	'https://www.tagesschau.de/kultur/kaisergrab-otto-der-grosse-magdeburger-dom-100.html',
                    	'Magdeburg: Kaiser Otto der Große bekommt neues Grab',
                    	'Weil das Grab von Kaiser Otto dem Großen restauriert werden musste, wurden auch seine Gebeine erforscht. Historiker und Chirurgen sind nun um einiges klüger - und der Kaiser bekommt bald eine neue Ruhestätte. Von S. Meyer.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'21 Aug 2026 18:00:46',
                    	'https://www.tagesschau.de/wissen/klima/wetter-klima-jahrhundertsommer-100.html',
                    	'Jahrhundertsommer? Warum Forschende neu denken müssen',
                    	'Ein überaus heißer und trockener Sommer wie in diesem Jahr kann künftig normal sein. Das zumindest sagt die Klimaforschung. Die Frage ist nur: Wie sieht dann künftig ein Jahrhundertsommer aus? Von Florian Zimmer.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div></div><div style="clear:both"></div></div><div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div></body></html>

