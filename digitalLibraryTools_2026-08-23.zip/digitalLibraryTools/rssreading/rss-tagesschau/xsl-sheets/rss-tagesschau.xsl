<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" 
		encoding="UTF-8" 
		doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" 
		doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>tagesschau.de | Schlagzeilen - rssreading</title>
                <link rel="shortcut icon" href="../images/favicon/fav-tagesschau.ico" />
                <link href="../css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            
<!--			
			<body onload="lookupArticleLinkAmount(); ">
-->
			<body>
				<!--
                <script type="text/javascript" src="../js/jquery-latest.min.js"></script>
				-->
				
                <script type="text/javascript" src="../js/unfold.js"></script>
                <script type="text/javascript" src="../js/visitLink.js"></script>
                <script type="text/javascript" src="../js/wndLocalStorage.js"></script>
        
		<script type="text/javascript">
		  <![CDATA[
          ]]>
        </script>
		
				<xsl:processing-instruction name="php">
					include("../uc/header_imports_02.php");
				?</xsl:processing-instruction>
				
				<xsl:processing-instruction name="php">
					include("../uc/articleItem.php");
				?</xsl:processing-instruction>
				
				<xsl:processing-instruction name="php">
					include("../uc/articleLink.php");
				?</xsl:processing-instruction>
				
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("Tagesschau");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
						<xsl:variable name="linkCounter_all">
							<xsl:value-of select="count(item)"/>
						</xsl:variable>
			
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="../rss-tagesschau/">
							  &gt; Alle Nachrichten (<xsl:processing-instruction name="php">
								  echo '<xsl:value-of select="$linkCounter_all" />';
								?</xsl:processing-instruction>)</a>
<!--
                            <br />
							<a href="index-wirtschaft.php">&gt; Wirtschaft</a>
							<a href="index-politik.php">&gt; Politik</a>
							<a href="index-netzwelt.php">&gt; Netzwelt</a>
							<a href="index-kultur.php">&gt; Kultur</a>
							<a href="index-sport.php">&gt; Sport</a>
							<a href="index-wissenschaft.php">&gt; Wissenschaft</a>
-->
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <!-- <br /> -->
                        <hr />
                        
						<xsl:call-template name="Ausland" />
						<xsl:call-template name="AuslandEuropa" />
						<xsl:call-template name="Inland" />
						<xsl:call-template name="Wirtschaft" />
						<xsl:call-template name="Sport" />
						<!--
						<xsl:call-template name="Regional-brOnline" />
                        <br />
						<xsl:call-template name="Regional-hrOnline" />
                        <br />
						<xsl:call-template name="Regional-ndrOnline" />
                        <br />
						<xsl:call-template name="Regional-mdrOnline" />
                        <br />
						<xsl:call-template name="Regional-rbbOnline" />
                        <br />
						<xsl:call-template name="Regional-srOnline" />
                        <br />
						<xsl:call-template name="Regional-swrOnline" />
                        <br />
						-->
						<xsl:call-template name="Sonstige" />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
				
				<div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div>
                
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="Ausland">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/ausland/'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'ausland'"/>
		</xsl:variable>
            
			<xsl:variable name="linkCounter_ausland">
				<xsl:value-of select="count(item[
										( contains(link, $searchFor)
											or contains(title, 'Flugh�fen in Iran')
											or contains(title, 'Iran-Liveblog:')											
										)
										and (
											contains(link, '/ausland/europa/')
											or contains(title, 'Berlusconi')
											or contains(title, 'Papstbesuch')
											or contains(title, 'Sagrada Familia')
											or contains(title, 'Nordirland:')
											or contains(description, 'D�nemark')
											or contains(description, 'Niederlande')
											or contains(title, 'EU-Asylpolitik:')
										)=false
										and (
											contains(title, 'EU')
											and contains(title, 'Beitrittsverhandlungen')
										)=false
									])"/>
			</xsl:variable>
			
		<strong>&gt; Ausland (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_ausland" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[
										( contains(link, $searchFor)
											or contains(title, 'Flugh�fen in Iran')
											or contains(title, 'Iran-Liveblog:')
										)
										and (
											contains(link, '/ausland/europa/')
											or contains(title, 'Berlusconi')
											or contains(title, 'Papstbesuch')
											or contains(title, 'Sagrada Familia')
											or contains(title, 'Nordirland:')
											or contains(description, 'D�nemark')
											or contains(description, 'Niederlande')
											or contains(title, 'EU-Asylpolitik:')
										)=false
										and (
											contains(title, 'EU')
											and contains(title, 'Beitrittsverhandlungen')
										)=false
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										( contains(link, $searchFor)
											or contains(title, 'Flugh�fen in Iran')
											or contains(title, 'Iran-Liveblog:')											
										)
										and (
											contains(link, '/ausland/europa/')
											or contains(title, 'Berlusconi')
											or contains(title, 'Papstbesuch')
											or contains(title, 'Sagrada Familia')
											or contains(title, 'Nordirland:')
											or contains(description, 'D�nemark')
											or contains(description, 'Niederlande')
											or contains(title, 'EU-Asylpolitik:')
										)=false
										and (
											contains(title, 'EU')
											and contains(title, 'Beitrittsverhandlungen')
										)=false
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="AuslandEuropa">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/ausland/europa/'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'ausland-europa'"/>
		</xsl:variable>
            
			<xsl:variable name="linkCounter_ausland_europa">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
											contains(title, 'Berlusconi')
											or contains(title, 'Papstbesuch')
											or contains(title, 'Sagrada Familia')
											or contains(title, 'Nordirland:')
											or contains(description, 'D�nemark')
											or contains(description, 'Niederlande')
											or contains(title, 'EU-Asylpolitik:')
										)
										or (
											contains(title, 'EU')
											and contains(title, 'Beitrittsverhandlungen')
										)
										and (
											contains(title, 'Flugh�fen in Iran')=false
										)
									])"/>
			</xsl:variable>
			
		<strong>&gt; Ausland - Europa (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_ausland_europa" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										or (
											contains(title, 'Berlusconi')
											or contains(title, 'Berlusconi')
											or contains(title, 'Papstbesuch')
											or contains(title, 'Sagrada Familia')
											or contains(title, 'Nordirland:')
											or contains(description, 'D�nemark')
											or contains(description, 'Niederlande')
											or contains(title, 'EU-Asylpolitik:')
										)
										or (
											contains(title, 'EU')
											and contains(title, 'Beitrittsverhandlungen')
										)
										and (
											contains(title, 'Flugh�fen in Iran')=false
										)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
											contains(title, 'Berlusconi')
											or contains(title, 'Berlusconi')
											or contains(title, 'Papstbesuch')
											or contains(title, 'Sagrada Familia')
											or contains(title, 'Nordirland:')
											or contains(description, 'D�nemark')
											or contains(description, 'Niederlande')
											or contains(title, 'EU-Asylpolitik:')
										)
										or (
											contains(title, 'EU')
											and contains(title, 'Beitrittsverhandlungen')
										)
										and (
											contains(title, 'Flugh�fen in Iran')=false
										)
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Inland">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/inland/'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'inland'"/>
		</xsl:variable>
            
			<xsl:variable name="linkCounter_inland">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			
		<strong>&gt; Inland (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_inland" />';
		?</xsl:processing-instruction>)
		</strong>
        
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Wirtschaft">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wirtschaft/'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaft'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_wirtschaft">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			
		<strong>&gt; Wirtschaft (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_wirtschaft" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sport">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'sportschau'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_sport">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
											contains(link, 'sport')
										)
										])"/>
			</xsl:variable>
			
		<strong>&gt; Sport (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_sport" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										or (
											contains(link, 'sport')
										)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
											contains(link, 'sport')
										)
										])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<!--
	<xsl:template name="Regional-brOnline">
		<strong>&gt; Regional - br-online</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'br-online.de'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'bronline'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Regional-hrOnline">
		<strong>&gt; Regional - hr-online</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'hr-online.de'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'hronline'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Regional-rbbOnline">
		<strong>&gt; Regional - rbb-online</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'rbb-online.de'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'rbbonline'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Regional-ndrOnline">
		<strong>&gt; Regional - ndr-online</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'ndr.de'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'ndronline'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Regional-mdrOnline">
		<strong>&gt; Regional - mdr-online</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'mdr.de'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'mdronline'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Regional-srOnline">
		<strong>&gt; Regional - sr-online</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'sr-online.de'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sronline'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Regional-swrOnline">
		<strong>&gt; Regional - swr-online</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'swr.de'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'swronline'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
	-->

	<xsl:template name="Sonstige">
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_sonstige">
				<xsl:value-of select="count(item[
										contains(link, '/wirtschaft')=false
										and contains(link, 'sportschau')=false
										and contains(link, '/ausland')=false
										and contains(link, '/ausland/europa')=false
										and contains(link, '/inland')=false
										and contains(link, 'boerse.ard.de')=false
										and contains(link, 'br-online.de')=false
										and contains(link, 'hr-online.de')=false
										and contains(link, 'ndr.de')=false
										and contains(link, 'mdr.de')=false
										and contains(link, 'rbb-online.de')=false
										and contains(link, 'sr-online.de')=false
										and contains(link, 'swr.de')=false
                                    	and (
											contains(link, 'sport')
											or contains(title, 'Flugh�fen in Iran')
											or contains(title, 'Iran-Liveblog:')											
                                    	)=false
										])
									"/>
			</xsl:variable>
			
		<strong>&gt; Sonstige (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_sonstige" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[
            							contains(link, '/wirtschaft')=false
                                    	and contains(link, 'sportschau')=false
                                    	and contains(link, '/ausland')=false
										and contains(link, '/ausland/europa/')=false
                                    	and contains(link, '/inland')=false
                                    	and contains(link, 'boerse.ard.de')=false
                                    	and contains(link, 'br-online.de')=false
                                    	and contains(link, 'hr-online.de')=false
                                    	and contains(link, 'ndr.de')=false
                                    	and contains(link, 'mdr.de')=false
                                    	and contains(link, 'rbb-online.de')=false
                                    	and contains(link, 'sr-online.de')=false
                                    	and contains(link, 'swr.de')=false
                                    	and (
											contains(link, 'sport')
											or contains(title, 'Flugh�fen in Iran')
											or contains(title, 'Iran-Liveblog:')											
                                    	)=false
                                    ]">
									
				<!--
				  Here: 
				    - There is the XML-Node 'description'.;
				    - It contains the substring: 'Mit der Diskussion um Wim Wenders' Film "Falsche Bewegung"'.;
					- Here we need to quote the char sequence: 'Wenders' Film' into something like 'Wenders&apos; Film'.; 
				-->
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, '/wirtschaft')=false
										and contains(link, 'sportschau')=false
										and contains(link, '/ausland')=false
										and contains(link, '/ausland/europa/')=false
										and contains(link, '/inland')=false
										and contains(link, 'boerse.ard.de')=false
										and contains(link, 'br-online.de')=false
										and contains(link, 'hr-online.de')=false
										and contains(link, 'ndr.de')=false
										and contains(link, 'mdr.de')=false
										and contains(link, 'rbb-online.de')=false
										and contains(link, 'sr-online.de')=false
										and contains(link, 'swr.de')=false
                                    	and (
											contains(link, 'sport')
											or contains(title, 'Flugh�fen in Iran')
											or contains(title, 'Iran-Liveblog:')											
                                    	)=false
										])
									"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
