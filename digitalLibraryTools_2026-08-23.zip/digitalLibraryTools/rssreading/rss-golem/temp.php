<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Golem Online | Schlagzeilen - crossreading</title><link rel="shortcut icon" href="/images/golem-favicon.ico"></link><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Golem");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a></div></div><div class="divContent"><strong style="margin:3px;">
                            Newsletter &gt; Golem.de</strong><br></br><hr></hr><strong xmlns="">&gt; Smartphones & Tablets</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'mobile',
                    	'1',
                    	'15 Feb 2012 14:08:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/294d5be1/l/0L0Sgolem0Bde0Cnews0Csmartphones0Edoppelt0Eso0Eviele0Eiphones0Ewie0Esymbian0Esmartphones0Everkauft0E120A20E897990Erss0Bhtml/story01.htm',
                    	'Smartphones: Doppelt so viele iPhones wie Symbian-Smartphones verkauft',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'mobile',
                    	'2',
                    	'15 Feb 2012 09:15:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/ec30dd9/l/0L0Sgolem0Bde0Cnews0Ccloud0Esmartphone0Eacer0Ebestaetigt0Ecloud0Emobile0Emit0Eandroid0E40E120A20E897860Erss0Bhtml/story01.htm',
                    	'Cloud-Smartphone: Acer best�tigt Cloud Mobile mit Android 4',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'mobile',
                    	'3',
                    	'15 Feb 2012 07:13:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/1cc3c63c/l/0L0Sgolem0Bde0Cnews0Csmartphone0Eapp0Eremove0Eloescht0Estoerende0Emenschen0Eim0Ebild0E120A20E897790Erss0Bhtml/story01.htm',
                    	'Smartphone-App: Remove l�scht st�rende Menschen im Bild',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'mobile',
                    	'4',
                    	'14 Feb 2012 13:36:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/1bb387d4/l/0L0Sgolem0Bde0Cnews0Cvodafone0Elte0Eauf0Edem0Esmartphone0Ekostet0Emonatlich0E10A0Eeuro0Emehr0E120A20E897680Erss0Bhtml/story01.htm',
                    	'Vodafone: LTE auf dem Smartphone kostet monatlich 10 Euro mehr',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'mobile',
                    	'5',
                    	'14 Feb 2012 13:09:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/1bc70092/l/0L0Sgolem0Bde0Cnews0Cproview0Etechnology0Eausfuhrverbot0Esoll0Eapple0Evon0Eipad0Eherstellern0Eabschneiden0E120A20E897650Erss0Bhtml/story01.htm',
                    	'Proview Technology: Ausfuhrverbot soll Apple von iPad-Herstellern abschneiden',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'mobile',
                    	'6',
                    	'14 Feb 2012 11:28:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/770c93c9/l/0L0Sgolem0Bde0Cnews0Chtc0Evelocity0E4g0Eandroid0Esmartphone0Emit0Elte0Eund0E40E50Ezoll0Etouchscreen0E120A20E897660Erss0Bhtml/story01.htm',
                    	'HTC Velocity 4G: Android-Smartphone mit LTE und 4,5-Zoll-Touchscreen',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'mobile',
                    	'6'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Internet</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'internet',
                    	'1',
                    	'15 Feb 2012 09:15:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/ec30dd9/l/0L0Sgolem0Bde0Cnews0Ccloud0Esmartphone0Eacer0Ebestaetigt0Ecloud0Emobile0Emit0Eandroid0E40E120A20E897860Erss0Bhtml/story01.htm',
                    	'Cloud-Smartphone: Acer best�tigt Cloud Mobile mit Android 4',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'internet',
                    	'2',
                    	'14 Feb 2012 15:57:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/52ad8d2a/l/0L0Sgolem0Bde0Cnews0Cisis0Eweb0Ebrowser0Eneuer0Ebrowser0Efuer0Ehps0Ewebos0E120A20E897720Erss0Bhtml/story01.htm',
                    	'Isis Web Browser: Neuer Browser f�r HPs WebOS',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'internet',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Open Source</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'openSource',
                    	'1',
                    	'15 Feb 2012 11:20:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/d437376/l/0L0Sgolem0Bde0Cnews0Copen0Esource0Edebian0Eprojekt0Eauf0E140Emilliarden0Eeuro0Egeschaetzt0E120A20E897930Erss0Bhtml/story01.htm',
                    	'Open Source: Debian-Projekt auf 14 Milliarden Euro gesch�tzt',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'openSource',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Security</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'security',
                    	'1',
                    	'15 Feb 2012 09:36:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/12c53cc0/l/0L0Sgolem0Bde0Cnews0Csicherheitsluecke0Egroupware0Ehorde0Eenthaelt0Ebackdoor0E120A20E897880Erss0Bhtml/story01.htm',
                    	'Sicherheitsl�cke: Groupware Horde enth�lt Backdoor',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'security',
                    	'2',
                    	'14 Feb 2012 17:20:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/612f723c/l/0L0Sgolem0Bde0Cnews0Cyouporn0Ebetreiber0Ehacker0Ewill0E350A0E0A0A0A0Edatensaetze0Ebei0Epornoseite0Eerbeutet0Ehaben0E120A20E897770Erss0Bhtml/story01.htm',
                    	'Youporn-Betreiber: Hacker will 350.000 Datens�tze bei Pornoseite erbeutet haben',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'security',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Social Media</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'socialmedia',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Games</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'games',
                    	'1',
                    	'15 Feb 2012 09:29:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/38de8574/l/0L0Sgolem0Bde0Cnews0Czynga0E20E90Emillionen0Ezahlende0Ekunden0Ebei0Ecastleville0Eco0E120A20E897850Erss0Bhtml/story01.htm',
                    	'Zynga: 2,9 Millionen zahlende Kunden bei Castleville & Co.',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'games',
                    	'2',
                    	'14 Feb 2012 11:12:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/31c848fd/l/0L0Sgolem0Bde0Cnews0Cfarmville0Eco0Epatentklage0Egegen0Ezynga0E120A20E897640Erss0Bhtml/story01.htm',
                    	'Farmville & Co.: Patentklage gegen Zynga',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'games',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Hardware</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'hardware',
                    	'1',
                    	'15 Feb 2012 05:01:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/41afd44e/l/0L0Sgolem0Bde0Cnews0Cradeon0Ehd0E7770A0Eund0E7750A0Eim0Etest0Edie0Egrafikkarte0Emit0E10Eghz0Efuer0E1590Eeuro0E120A20E897780Erss0Bhtml/story01.htm',
                    	'Radeon HD 7770 und 7750 im Test: Die Grafikkarte mit 1 GHz f�r 159 Euro',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'hardware',
                    	'2',
                    	'14 Feb 2012 17:13:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/69aaff2b/l/0L0Sgolem0Bde0Cnews0Ctz77xe40Ebiostar0Ezeigt0Emainboard0Efuer0Eivy0Ebridge0Eund0Esandy0Ebridge0E120A20E897760Erss0Bhtml/story01.htm',
                    	'TZ77XE4: Biostar zeigt Mainboard f�r Ivy Bridge und Sandy Bridge',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'hardware',
                    	'3',
                    	'14 Feb 2012 11:28:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/770c93c9/l/0L0Sgolem0Bde0Cnews0Chtc0Evelocity0E4g0Eandroid0Esmartphone0Emit0Elte0Eund0E40E50Ezoll0Etouchscreen0E120A20E897660Erss0Bhtml/story01.htm',
                    	'HTC Velocity 4G: Android-Smartphone mit LTE und 4,5-Zoll-Touchscreen',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'hardware',
                    	'4',
                    	'14 Feb 2012 10:56:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/5774e24d/l/0L0Sgolem0Bde0Cnews0Cpegatron0Euebt0Eapple0Edruck0Eauf0Eoem0Ehersteller0Evon0Eultrabooks0Eaus0E120A20E897620Erss0Bhtml/story01.htm',
                    	'Pegatron: �bt Apple Druck auf OEM-Hersteller von Ultrabooks aus?',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'hardware',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Technik, Robotik, Physik</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'technics',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Wirtschaft</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'1',
                    	'15 Feb 2012 14:08:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/294d5be1/l/0L0Sgolem0Bde0Cnews0Csmartphones0Edoppelt0Eso0Eviele0Eiphones0Ewie0Esymbian0Esmartphones0Everkauft0E120A20E897990Erss0Bhtml/story01.htm',
                    	'Smartphones: Doppelt so viele iPhones wie Symbian-Smartphones verkauft',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Recht, Politik</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'rechtPolitik',
                    	'1',
                    	'14 Feb 2012 13:14:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/7e874fda/l/0L0Sgolem0Bde0Cnews0Cabmahnabzocke0Emaximal0E10A0A0Eeuro0Eabmahngebuehr0Efuer0Eurheberrechtsverstoesse0E120A20E897670Erss0Bhtml/story01.htm',
                    	'Abmahnabzocke: Maximal 100 Euro Abmahngeb�hr f�r Urheberrechtsverst��e',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'rechtPolitik',
                    	'2',
                    	'14 Feb 2012 11:12:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/31c848fd/l/0L0Sgolem0Bde0Cnews0Cfarmville0Eco0Epatentklage0Egegen0Ezynga0E120A20E897640Erss0Bhtml/story01.htm',
                    	'Farmville & Co.: Patentklage gegen Zynga',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'rechtPolitik',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'15 Feb 2012 15:01:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/35c64f40/l/0L0Sgolem0Bde0Cnews0Ccapcom0Esprinten0Eund0Eschiessen0Ein0Eresident0Eevil0E60E120A20E8980A30Erss0Bhtml/story01.htm',
                    	'Capcom: Sprinten und schie�en in Resident Evil 6',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'15 Feb 2012 14:42:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/102f8e53/l/0L0Sgolem0Bde0Cnews0Coracle0Ejava0Eupdates0Ebeheben0Ekritische0Efehler0E120A20E8980A0A0Erss0Bhtml/story01.htm',
                    	'Oracle: Java-Updates beheben kritische Fehler',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'15 Feb 2012 14:37:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/2be5e749/l/0L0Sgolem0Bde0Cnews0Cdigitale0Elandkarte0Ezoomen0Eohne0Everzerrung0E120A20E8980A10Erss0Bhtml/story01.htm',
                    	'Digitale Landkarte: Zoomen ohne Verzerrung',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'15 Feb 2012 14:02:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/49cdf10/l/0L0Sgolem0Bde0Cnews0Ckonami0Emetal0Egear0Eonline0Eschleicht0Esich0E120A20E897980Erss0Bhtml/story01.htm',
                    	'Konami: Metal Gear Online schleicht sich',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'15 Feb 2012 13:57:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/5e0a52d2/l/0L0Sgolem0Bde0Cnews0Caccessibility0Eapi0Ewindows0E80Esoll0Ebarrierefrei0Ewerden0E120A20E897970Erss0Bhtml/story01.htm',
                    	'Accessibility-API: Windows 8 soll barrierefrei werden',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'6',
                    	'15 Feb 2012 13:41:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/305a89e1/l/0L0Sgolem0Bde0Cnews0Ckonservativer0Eeu0Efraktionsschef0Eacta0Eist0Eam0Eende0E120A20E897960Erss0Bhtml/story01.htm',
                    	'Konservativer EU-Fraktionsschef: "Acta ist am Ende"',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'7',
                    	'15 Feb 2012 11:44:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/319a2fa6/l/0L0Sgolem0Bde0Cnews0Cwindows0Eund0Einternet0Eexplorer0Emicrosofts0Epatch0Eparade0E120A20E897950Erss0Bhtml/story01.htm',
                    	'Windows und Internet Explorer: Microsofts Patch-Parade',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'8',
                    	'15 Feb 2012 11:21:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/2e491adc/l/0L0Sgolem0Bde0Cnews0Cmegaupload0Ekompagnon0Evon0Ekim0Eschmitz0Eauf0Ekaution0Efrei0E120A20E897940Erss0Bhtml/story01.htm',
                    	'Megaupload: Kompagnon von Kim Schmitz auf Kaution frei',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'9',
                    	'15 Feb 2012 11:08:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/6a7b3ee9/l/0L0Sgolem0Bde0Cnews0Capple0Etv0Etim0Ecook0Egibt0Ehinweise0Ezum0Eapple0Efernseher0E120A20E897920Erss0Bhtml/story01.htm',
                    	'Apple-TV: Tim Cook gibt Hinweise zum Apple-Fernseher',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'10',
                    	'15 Feb 2012 10:44:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/144e5e4/l/0L0Sgolem0Bde0Cnews0Crockstar0Egames0Egta0E50Enutzt0Eangeblich0Esprachanimationen0Evon0Espeech0Egraphics0E120A20E897910Erss0Bhtml/story01.htm',
                    	'Rockstar Games: GTA 5 nutzt angeblich Sprachanimationen von Speech Graphics',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'11',
                    	'15 Feb 2012 10:36:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/40545bb7/l/0L0Sgolem0Bde0Cnews0Cmitx0Emit0Ebietet0Eersten0Eonlinekurs0Ean0E120A20E89790A0Erss0Bhtml/story01.htm',
                    	'MITx: MIT bietet ersten Onlinekurs an',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'12',
                    	'15 Feb 2012 10:14:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/7cefb95a/l/0L0Sgolem0Bde0Cnews0Capps0Efuer0Ewindows0E80Ees0Edarf0Ejeden0Enamen0Enur0Eeinmal0Egeben0E120A20E897890Erss0Bhtml/story01.htm',
                    	'Apps f�r Windows 8: Es darf jeden Namen nur einmal geben',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'13',
                    	'15 Feb 2012 10:05:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/3ca12a1a/l/0L0Sgolem0Bde0Cnews0Cjonathan0Eschwartz0Eex0Esun0Echef0Eanalysiert0Edie0Eletzten0Etage0Evon0Esun0Emicrosystems0E120A20E897870Erss0Bhtml/story01.htm',
                    	'Jonathan Schwartz: Ex-Sun-Chef analysiert die letzten Tage von Sun Microsystems',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'14',
                    	'15 Feb 2012 09:11:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/2e9672a9/l/0L0Sgolem0Bde0Cnews0Cron0Ewas0Ewrong0Ewhit0Eis0Eright0Ersa0Eschluessel0Eunsicherer0Eals0Egedacht0E120A20E897830Erss0Bhtml/story01.htm',
                    	'Ron was wrong, Whit is right: RSA-Schl�ssel unsicherer als gedacht',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'15',
                    	'15 Feb 2012 08:29:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/33c09ac4/l/0L0Sgolem0Bde0Cnews0Cbioware0Ekurz0Edie0Ewelt0Eretten0Ein0Eder0Edemo0Ezu0Emass0Eeffect0E30E120A20E897840Erss0Bhtml/story01.htm',
                    	'Bioware: Kurz die Welt retten in der Demo zu Mass Effect 3',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'16',
                    	'15 Feb 2012 07:55:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/512335ae/l/0L0Sgolem0Bde0Cnews0Cadobe0Ephotoshop0Ecs60Emit0Econtent0Eaware0Emove0E120A20E897810Erss0Bhtml/story01.htm',
                    	'Adobe: Photoshop CS6 mit Content-Aware Move',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'17',
                    	'15 Feb 2012 07:33:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/18648f88/l/0L0Sgolem0Bde0Cnews0Cgoogle0Ewir0Ehaben0Eden0Egroessten0Edns0Edienst0E120A20E897820Erss0Bhtml/story01.htm',
                    	'Google: Wir haben den gr��ten DNS-Dienst',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'18',
                    	'15 Feb 2012 07:17:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/647ff15/l/0L0Sgolem0Bde0Cnews0Clensbaby0Eteleobjektiv0Emit0Eabsichtlicher0Eunschaerfe0E120A20E89780A0Erss0Bhtml/story01.htm',
                    	'Lensbaby: Teleobjektiv mit absichtlicher Unsch�rfe',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'19',
                    	'14 Feb 2012 16:41:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/65168c29/l/0L0Sgolem0Bde0Cnews0Cunity0Etechnologies0Ebessere0Egrafik0Eund0Eki0Emit0Eunity0E30E50Everfuegbar0E120A20E897750Erss0Bhtml/story01.htm',
                    	'Unity Technologies: Bessere Grafik und KI mit Unity 3.5 verf�gbar',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'20',
                    	'14 Feb 2012 16:36:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/73487ec7/l/0L0Sgolem0Bde0Cnews0Cfifa0Estreet0Elast0Eman0Estanding0Eauf0Edem0Ebolzplatz0E120A20E897740Erss0Bhtml/story01.htm',
                    	'Fifa Street: Last Man Standing auf dem Bolzplatz',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'21',
                    	'14 Feb 2012 15:51:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/68db6a8a/l/0L0Sgolem0Bde0Cnews0Cnortel0Enetworks0Enortel0Ewar0Efast0Ezehn0Ejahre0Elang0Egehackt0E120A20E89770A0Erss0Bhtml/story01.htm',
                    	'Nortel Networks: Nortel war fast zehn Jahre lang gehackt',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'22',
                    	'14 Feb 2012 14:59:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/162f49a5/l/0L0Sgolem0Bde0Cnews0Cthermosensor0Eschmetterlingsfluegel0Emacht0Ewaerme0Esichtbar0E120A20E897710Erss0Bhtml/story01.htm',
                    	'Thermosensor: Schmetterlingsfl�gel macht W�rme sichtbar',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'23',
                    	'14 Feb 2012 14:24:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/54cf41b6/l/0L0Sgolem0Bde0Cnews0Cdeutsche0Egamestage0Ecall0Efor0Epapers0Eder0Equo0Evadis0Everlaengert0E120A20E897690Erss0Bhtml/story01.htm',
                    	'Deutsche Gamestage: Call for Papers der Quo Vadis verl�ngert',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'24',
                    	'14 Feb 2012 11:02:00',
                    	'http://rss.feedsportal.com/c/33374/f/578068/p/1/s/2507156c/l/0L0Sgolem0Bde0Cnews0Cdocument0Efoundation0Elibreoffice0E30E50Eist0Efertig0E120A20E897630Erss0Bhtml/story01.htm',
                    	'Document Foundation: Libreoffice 3.5 ist fertig',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
            			'sonstige',
            			'24'
            			);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>
