<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Golem Online | Schlagzeilen - crossreading</title>
                <link rel="shortcut icon" href="/images/favicon/fav-golem.ico" />
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("Golem");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                        </div>
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                            Newsletter &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="Mobile" />
                        <br />
						<xsl:call-template name="Internet" />
                        <br />
						<xsl:call-template name="OpenSource" />
                        <br />
						<xsl:call-template name="Security" />
                        <br />
						<xsl:call-template name="SocialMedia" />
                        <br />
						<xsl:call-template name="Games" />
                        <br />
						<xsl:call-template name="Hardware" />
                        <br />
						<xsl:call-template name="Technik" />
                        <br />
						<xsl:call-template name="Wirtschaft" />
                        <br />
						<xsl:call-template name="RechtPolitik" />
                        <br />
						<xsl:call-template name="Sonstige" />
                        <br />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
                
			</body>
			
		</html>	
	</xsl:template>

	<xsl:template name="Mobile">
		<strong>&gt; Smartphones &amp; Tablets</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'Smartphone'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'mobile'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, $searchFor)
									or contains(title, 'Tablet')
									or contains(title, 'Mobil')
									or contains(title, 'Handy')
									or contains(title, 'iPhone')
									or contains(title, 'iPad')
									or contains(title, 'Android')
									or contains(title, 'Galaxy-Nexus')
									or contains(title, 'Galaxy Nexus')
									or contains(title, 'Galaxy Tab')
									or contains(title, 'Symbian')
									or contains(title, 'Meego')
									or contains(title, 'Galaxy Note')
									or (
										contains(title, 'smart')
										and contains(title, 'Phone')
									)
									or contains(title, 'Galaxy S3')
									or contains(title, 'Jelly Bean')
									or contains(title, 'Gamepad')
									or contains(title, 'Spieletablet')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(title, 'Smartphone')
									or contains(title, 'Mobil')
									or contains(title, 'Handy')
									or contains(title, 'iPhone')
									or contains(title, 'iPad')
									or contains(title, 'Android')
									or contains(title, 'Galaxy-Nexus')
									or contains(title, 'Galaxy Nexus')
									or contains(title, 'Galaxy Tab')
									or contains(title, 'Symbian')
									or contains(title, 'Meego')
									or contains(title, 'Galaxy Note')
									or (
										contains(title, 'smart')
										and contains(title, 'Phone')
									)
									or contains(title, 'Galaxy S3')
									or contains(title, 'Jelly Bean')
									or contains(title, 'Gamepad')
									or contains(title, 'Spieletablet')
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Internet">
		<strong>&gt; Internet</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'internet'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Browser')
									or contains(title, 'Firefox')
									or contains(title, 'Opera ')
									or contains(title, 'Chrome')
									or contains(title, 'Cloud')
									or contains(title, 'Webkit')
									or contains(title, 'browser')
									or contains(title, 'Anonymes Surfen')
									or contains(title, 'Mutation Summary')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Browser')
												or contains(title, 'Firefox')
												or contains(title, 'Opera ')
												or contains(title, 'Chrome')
												or contains(title, 'Cloud')
												or contains(title, 'Webkit')
												or contains(title, 'browser')
												or contains(title, 'Anonymes Surfen')
												or contains(title, 'Mutation Summary')
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="OpenSource">
		<strong>&gt; Open Source</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'openSource'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Firefox')
									or contains(title, 'Linux')
									or contains(title, 'Compiler')
									or contains(title, 'Gnome')
									or contains(title, 'Mozilla')
									or contains(title, 'Ubuntu')
									or contains(title, 'Open-Source')
									or contains(title, 'CouchDB')
									or contains(title, 'KDE')
									or contains(title, 'Open Source')
									or contains(title, 'Unix')
									or contains(title, 'GPL')
									or contains(title, 'Open Data')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Firefox')
												or contains(title, 'Linux')
												or contains(title, 'Compiler')
												or contains(title, 'Gnome')
												or contains(title, 'Mozilla')
												or contains(title, 'Ubuntu')
												or contains(title, 'Open-Source')
												or contains(title, 'CouchDB')
												or contains(title, 'KDE')
												or contains(title, 'Open Source')
												or contains(title, 'Unix')
												or contains(title, 'GPL')
												or contains(title, 'Open Data')
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Security">
		<strong>&gt; Security</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'security'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Datenschutz')
									or contains(title, 'Sicherheit')
									or contains(title, 'Hacker')
									or contains(title, 'Botnetz')
									or contains(title, 'Trojaner')
									or contains(title, 'trojaner')
									or contains(title, 'Anonymous:')
									or contains(title, '�berwachung:')
									or contains(title, 'Kopierschutz')
									or contains(title, 'gesch�tzt')
									or contains(title, 'Jugendschutz')
									or contains(title, 'medienschutz')
									or contains(title, 'Cyberwar')
									or contains(title, 'Security:')
									or contains(title, 'Datendiebstahl')
									or contains(title, 'Passwortwechsel')
									or contains(title, 'Datensch�tzer')
									or contains(title, 'verschl�sselung')
									or contains(title, 'Passwort')
									or contains(title, 'DRM')
									or contains(title, 'Secure Memory')
									or contains(title, 'Identit�t')
									or contains(title, '�berwachungstechnik')
									or contains(title, 'Secure Boot')
									or contains(title, 'Schadsoftware')
									or contains(title, 'DDoS-Attacke')
									or contains(title, 'PC-Durchsuchung durch Arbeitgeber')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Datenschutz')
												or contains(title, 'Sicherheit')
												or contains(title, 'Hacker')
												or contains(title, 'Botnetz')
												or contains(title, 'Trojaner')
												or contains(title, 'trojaner')
												or contains(title, 'Anonymous:')
												or contains(title, '�berwachung:')
												or contains(title, 'Kopierschutz')
												or contains(title, 'gesch�tzt')
												or contains(title, 'Jugendschutz')
												or contains(title, 'medienschutz')
												or contains(title, 'Cyberwar')
												or contains(title, 'Security:')
												or contains(title, 'Datendiebstahl')
												or contains(title, 'Passwortwechsel')
												or contains(title, 'Datensch�tzer')
												or contains(title, 'verschl�sselung')
												or contains(title, 'Passwort')
												or contains(title, 'DRM')
												or contains(title, 'Secure Memory')
												or contains(title, 'Identit�t')
												or contains(title, '�berwachungstechnik')
												or contains(title, 'Secure Boot')
												or contains(title, 'Schadsoftware')
												or contains(title, 'DDoS-Attacke')
												or contains(title, 'PC-Durchsuchung durch Arbeitgeber')
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="SocialMedia">
		<strong>&gt; Social Media, Messaging</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'socialmedia'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Twitter')
									or contains(title, 'Facebook')
									or contains(title, 'oziales Netzwerk')
									or contains(title, 'Google+')
									or contains(title, 'Flickr')
									or contains(title, 'Pinwheel')
									or contains(title, 'Second Life')
									or contains(title, 'Skype')
									or contains(title, 'Whatsapp')
									or contains(title, 'Messenger')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Twitter')
												or contains(title, 'Facebook')
												or contains(title, 'oziales Netzwerk')
												or contains(title, 'Google+')
												or contains(title, 'Flickr')
												or contains(title, 'Pinwheel')
												or contains(title, 'Second Life')
												or contains(title, 'Skype')
												or contains(title, 'Whatsapp')
												or contains(title, 'Messenger')
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Games">
		<strong>&gt; Games</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'games'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Battlefield 3')
									or contains(title, 'Max Payne 3')
									or contains(title, 'World of Warcraft')
									or contains(title, 'Mechwarrior')
									or contains(title, 'Super Mario 3D Land')
									or contains(title, 'Starcraft 2')
									or contains(title, 'Counter-Strike')
									or contains(title, 'Command &amp; Conquer')
									or contains(title, 'Doom 3')
									or contains(title, 'Skyrim')
									or contains(title, 'Quake')
									or contains(title, 'Diablo 3')
									or contains(title, 'Crysis')
									or contains(title, 'Neverdead')
									or contains(title, 'angespielt')
									
									or contains(title, 'Xbox')
									or contains(title, 'PS3')
									or contains(title, 'PSN')
									or contains(title, 'Nintendo 3DS')
									
									or contains(title, 'Rollenspiel')
									or contains(title, 'Cryengine')
									
									or contains(title, 'Activision')
									or contains(title, 'Zynga')
									or contains(title, 'Electronic Arts')
									or contains(title, 'Egosoft')
									or contains(title, 'Infinity Blade')
									or contains(title, 'The Witcher 2')
									or contains(title, 'Minecraft')
									or contains(title, 'Steam')
									or contains(title, 'Spielestudio')
									or contains(title, 'Jagged Alliance')
									or contains(title, 'Uncharted')
									or contains(title, 'Spielebranche')
									or contains(title, 'Unreal Engine')
									or contains(title, 'Echtzeitstrategie')
									or contains(title, 'Videospiel')
									or contains(title, 'God of War')
									or contains(title, 'Spielspa�')
									or contains(title, 'Call of Duty')
									or contains(title, 'Rundenstrategie')
									or contains(title, 'Diablo 3')
									or contains(title, 'Playstation')
									or contains(title, 'Angry Birds')
									or contains(title, 'Tekken')
									or contains(title, 'haltige Spiele')
									or contains(title, 'Spieletastatur')
									or contains(title, 'Cry Engine')
									or contains(title, 'Nintendo')
									or contains(title, 'Super Mario')
									or contains(title, 'Gamepad')
									or contains(title, 'Spieletablet')
									or contains(title, 'Bioshock Infinite')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(title, 'Battlefield 3')
									or contains(title, 'Max Payne 3')
									or contains(title, 'World of Warcraft')
									or contains(title, 'Mechwarrior')
									or contains(title, 'Super Mario 3D Land')
									or contains(title, 'Starcraft 2')
									or contains(title, 'Counter-Strike')									
									or contains(title, 'Command &amp; Conquer')
									or contains(title, 'Doom 3')
									or contains(title, 'Skyrim')
									or contains(title, 'Quake')
									or contains(title, 'Diablo 3')
									or contains(title, 'Neverdead')
									or contains(title, 'angespielt')
									
									or contains(title, 'Xbox')
									or contains(title, 'PS3')
									or contains(title, 'PSN')
									or contains(title, 'Nintendo 3DS')
									
									or contains(title, 'Rollenspiel')
									or contains(title, 'Cryengine')
									
									or contains(title, 'Activision')
									or contains(title, 'Zynga')
									or contains(title, 'Electronic Arts')
									
									or contains(title, 'Crysis')
									or contains(title, 'Egosoft')
									or contains(title, 'Infinity Blade')
									or contains(title, 'The Witcher 2')
									or contains(title, 'Minecraft')
									or contains(title, 'Steam')
									or contains(title, 'Spielestudio')
									or contains(title, 'Jagged Alliance')
									or contains(title, 'Uncharted')
									or contains(title, 'Spielebranche')
									or contains(title, 'Unreal Engine')
									or contains(title, 'Echtzeitstrategie')
									or contains(title, 'Videospiel')
									or contains(title, 'God of War')
									or contains(title, 'Spielspa�')
									or contains(title, 'Call of Duty')
									or contains(title, 'Rundenstrategie')
									or contains(title, 'Diablo 3')
									or contains(title, 'Playstation')
									or contains(title, 'Angry Birds')
									or contains(title, 'Tekken')
									or contains(title, 'haltige Spiele')
									or contains(title, 'Spieletastatur')
									or contains(title, 'Cry Engine')
									or contains(title, 'Nintendo')
									or contains(title, 'Super Mario')
									or contains(title, 'Gamepad')
									or contains(title, 'Spieletablet')
									or contains(title, 'Bioshock Infinite')
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Hardware">
		<strong>&gt; Hardware</strong>
		        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'hardware'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'chip')
									or contains(title, 'DDR')
									or contains(title, 'CPU')
									or contains(title, 'GPU')
									or contains(title, 'LED')
									or contains(title, 'APU')
									or contains(title, 'Touchscreen')
									or contains(title, 'Xeon')
									or contains(title, 'Kamera')
									or contains(title, 'NAND')
									or contains(title, 'PCI Express')
									or contains(title, 'ARM')
									or contains(title, 'USB')
									or contains(title, 'Festplatte')
									or contains(title, 'Grafikkarte')
									or contains(title, 'Display')
									or contains(title, 'Mainboard')
									or contains(title, 'SSD')
									or contains(title, 'Ultrabook')
									or contains(title, 'Pentium')
									or contains(title, 'Celeron')
									or contains(title, 'Athlon')
									or contains(title, 'Phenom')
									or contains(title, 'DRAM')
									or contains(title, 'Compactflash')
									or contains(title, 'XQD')
									or contains(title, 'Notebook')
									or contains(title, 'Radeon')
									or contains(title, 'Firmware')
									or contains(title, 'Rechenzentren')
									or contains(title, 'Speicherkarte')
									or contains(title, 'Nvidia')
									or contains(title, 'Grafiktreiber')
									or contains(title, '3D-Desktop')
									or contains(title, 'Quad-Core')
									or contains(title, 'Dolby 3D')
									or contains(title, 'OpenGL')
									or contains(title, 'projektor')
									or contains(title, 'Spieletastatur')
									or contains(title, 'Touchpad')
									or contains(title, 'Thunderbolt')
									or contains(title, 'VDSL')
									or contains(title, 'LTE')
									or contains(title, 'Dual-Core')
									or contains(title, 'NAS-System')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'chip')
												or contains(title, 'DDR')
												or contains(title, 'CPU')
												or contains(title, 'GPU')
												or contains(title, 'LED')
												or contains(title, 'APU')
												or contains(title, 'Touchscreen')
												or contains(title, 'Xeon')
												or contains(title, 'Kamera')
												or contains(title, 'NAND')
												or contains(title, 'PCI Express')
												or contains(title, 'ARM')
												or contains(title, 'USB')
												or contains(title, 'Pentium')
												or contains(title, 'Celeron')
												or contains(title, 'Festplatte')
												or contains(title, 'Grafikkarte')
												or contains(title, 'Display')
												or contains(title, 'Mainboard')
												or contains(title, 'SSD')
												or contains(title, 'Ultrabook')
												or contains(title, 'Athlon')
												or contains(title, 'Phenom')
												or contains(title, 'DRAM')
												or contains(title, 'Compactflash')
												or contains(title, 'XQD')
												or contains(title, 'Notebook')
												or contains(title, 'Radeon')
												or contains(title, 'Firmware')
												or contains(title, 'Rechenzentren')
												or contains(title, 'Speicherkarte')
												or contains(title, 'Nvidia')
												or contains(title, 'Grafiktreiber')
												or contains(title, '3D-Desktop')
												or contains(title, 'Quad-Core')
												or contains(title, 'Dolby 3D')
												or contains(title, 'OpenGL')
												or contains(title, 'projektor')
												or contains(title, 'Spieletastatur')
												or contains(title, 'Touchpad')
												or contains(title, 'Thunderbolt')
												or contains(title, 'VDSL')
												or contains(title, 'LTE')
												or contains(title, 'Dual-Core')
												or contains(title, 'NAS-System')
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="RechtPolitik">
		<strong>&gt; Recht, Politik</strong>
		        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'rechtPolitik'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Urheber')
									or contains(title, 'Patent')
									or contains(title, 'Parlament')
									or contains(title, 'Gericht')
									or contains(title, 'Piratenpartei')
									or contains(title, 'Kartellamt')
									or contains(title, 'Bundespr�fstelle')
									or contains(title, 'Gesetzesentwurf')
									or contains(title, 'Bundesnetzagentur')
									or contains(title, 'Koalition')
									or contains(title, 'gesetz')
									or contains(title, 'Datenschutzreform')
									or contains(title, 'Bundesregierung')
									or contains(title, 'Bundesverfassungsgericht')
									or contains(title, 'Rechtsstreit')
									or contains(title, 'illegal')
									or contains(title, 'Rechteverwalt')
									or contains(title, 'Regierung')
									or contains(title, 'minister')
									or contains(title, 'Datensch�tzer')
									or contains(title, 'EuGH')
									or contains(title, 'Acta')
									or contains(title, 'Neue Anklage')
									or contains(title, 'Bew�hrungsstrafe')
									or contains(title, 'GPL')
									or contains(title, 'Datenschutz')
									or contains(title, 'Vorratsdatenspeicherung')
									or contains(title, 'Politiker')
									or contains(title, 'schutzrecht')
									or contains(title, 'Grundrecht')
									or contains(title, 'Meinungsfreiheit')
									or contains(title, 'gerichtshof:')
									or contains(title, 'Filesharing')
									or contains(title, 'Pers�nlichkeitsrecht')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Urheber')
												or contains(title, 'Patent')
												or contains(title, 'Parlament')
												or contains(title, 'Gericht')
												or contains(title, 'Piratenpartei')
												or contains(title, 'Kartellamt')
												or contains(title, 'Bundespr�fstelle')
												or contains(title, 'Gesetzesentwurf')
												or contains(title, 'Bundesnetzagentur')
												or contains(title, 'Koalition')
												or contains(title, 'gesetz')
												or contains(title, 'Datenschutzreform')
												or contains(title, 'Bundesregierung')
												or contains(title, 'Bundesverfassungsgericht')
												or contains(title, 'Rechtsstreit')
												or contains(title, 'illegal')
												or contains(title, 'Rechteverwalt')
												or contains(title, 'Regierung')
												or contains(title, 'minister')
												or contains(title, 'Datensch�tzer')
												or contains(title, 'EuGH')
												or contains(title, 'Acta')
												or contains(title, 'Neue Anklage')
												or contains(title, 'Bew�hrungsstrafe')
												or contains(title, 'GPL')
												or contains(title, 'Datenschutz')
												or contains(title, 'Vorratsdatenspeicherung')
												or contains(title, 'Politiker')
												or contains(title, 'schutzrecht')
												or contains(title, 'Grundrecht')
												or contains(title, 'Meinungsfreiheit')
												or contains(title, 'gerichtshof:')
												or contains(title, 'Filesharing')
												or contains(title, 'Pers�nlichkeitsrecht')
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Wirtschaft">
		<strong>&gt; Wirtschaft</strong>
		        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaft'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Gesch�ftsmodell')
									or contains(title, 'Betriebsversammlung')
									or contains(title, 'werbung')
									or contains(title, 'TV-Rechte')
									or contains(title, 'bestellung')
									or contains(title, 'Kartellamt')
									or contains(title, 'Konkurrenz')
									or contains(title, 'B�rsengang')
									or contains(title, 'Verkauf')
									or contains(title, 'investiert in')
									or contains(title, 'sparte')
									or contains(title, 'verkaufen')
									or contains(title, 'kauft')
									or contains(title, 'neue Jobs')
									or contains(title, 'B�rsenwert')
									or contains(title, 'Marktzahlen')
									or contains(title, 'Bundeskartellamt')
									or contains(title, 'vorbestellt')
									or contains(title, 'mehr Lohn')
									or contains(title, 'Abmahnung')
									or contains(title, 'Lohnerh�hung')
									or contains(title, 'Vorverkauf')
									or contains(title, 'nennt Preis')
									or contains(title, 'lizenziert')
									or contains(title, 'gegen Bezahlung')
									or contains(title, 'Preisspekulation')
									or (
										contains(title, 'zieht sich')
										and contains(title, 'markt zur�ck')
									)
									or contains(title, 'Preissenkung')
									or contains(title, 'Liefertermin')
									or contains(title, 'liefert bestellte')
									or contains(title, 'Insolvenz:')
									or contains(title, 'in den Handel')
									or contains(title, 'Onlinehandel:')
									or (
										contains(title, 'will')
										and contains(title, 'anbieten')
									)
									or contains(title, 'reduziert Auftr�ge')
									or (
										contains(title, 'Amazon')
										and contains(title, 'spart')
									)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Gesch�ftsmodell')
												or contains(title, 'Betriebsversammlung')
												or contains(title, 'werbung')
												or contains(title, 'TV-Rechte')
												or contains(title, 'bestellung')
												or contains(title, 'Kartellamt')
												or contains(title, 'Konkurrenz')
												or contains(title, 'B�rsengang')
												or contains(title, 'Verkauf')
												or contains(title, 'investiert in')
												or contains(title, 'sparte')
												or contains(title, 'verkaufen')
												or contains(title, 'kauft')
												or contains(title, 'neue Jobs')
												or contains(title, 'B�rsenwert')
												or contains(title, 'Marktzahlen')
												or contains(title, 'Bundeskartellamt')
												or contains(title, 'vorbestellt')
												or contains(title, 'mehr Lohn')
												or contains(title, 'Abmahnung')
												or contains(title, 'Lohnerh�hung')
												or contains(title, 'Vorverkauf')
												or contains(title, 'nennt Preis')
												or contains(title, 'lizenziert')
												or contains(title, 'gegen Bezahlung')
												or contains(title, 'Preisspekulation')
												or (
													contains(title, 'zieht sich')
													and contains(title, 'markt zur�ck')
												)
												or contains(title, 'Preissenkung')
												or contains(title, 'Liefertermin')
												or contains(title, 'liefert bestellte')
												or contains(title, 'Insolvenz:')
												or contains(title, 'in den Handel')
												or contains(title, 'Onlinehandel:')
												or (
													contains(title, 'will')
													and contains(title, 'anbieten')
												)
												or contains(title, 'reduziert Auftr�ge')
												or (
													contains(title, 'Amazon')
													and contains(title, 'spart')
												)
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Technik">
		<strong>&gt; Technik, Robotik, Physik</strong>
		        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="''"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'technics'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Schwimmroboter')
									or contains(title, 'Roboter')
									or contains(title, 'LHC')
									or contains(title, 'Raumfahrt')
									or contains(title, 'Cyborg')
									or contains(title, 'Nanotechnologie')
									or contains(title, 'Robotik:')
									or contains(title, 'Quantencomputer')
									or contains(title, 'Forschung')
									or contains(title, 'Solarzelle')
									or contains(title, 'Nanobeschichtung')
									or contains(title, 'Nobelpreis')
									or contains(title, 'Drohnen:')
									or contains(title, 'Tr�gerrakete')
									or contains(title, 'Triebwerk')
									or contains(title, 'Relativit�tstheorie')
									or contains(title, 'Nachbarplanet')
									or contains(title, 'Curiosity:')
									or contains(title, 'Wissenschaft:')
									or contains(title, 'Astronomie:')
									or contains(title, 'Drohne:')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Schwimmroboter')
												or contains(title, 'Roboter')
												or contains(title, 'LHC')
												or contains(title, 'Raumfahrt')
												or contains(title, 'Cyborg')
												or contains(title, 'Nanotechnologie')
												or contains(title, 'Robotik:')
												or contains(title, 'Quantencomputer')
												or contains(title, 'Forschung')
												or contains(title, 'Solarzelle')
												or contains(title, 'Nanobeschichtung')
												or contains(title, 'Nobelpreis')
												or contains(title, 'Drohnen:')
												or contains(title, 'Tr�gerrakete')
												or contains(title, 'Triebwerk')
												or contains(title, 'Relativit�tstheorie')
												or contains(title, 'Nachbarplanet')
												or contains(title, 'Curiosity:')
												or contains(title, 'Wissenschaft:')
												or contains(title, 'Astronomie:')
												or contains(title, 'Drohne:')
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
        
	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Datenschutz')=false
									and contains(title, 'Sicherheit')=false
									and contains(title, 'Hacker')=false
									and contains(title, 'Botnetz')=false
									and contains(title, 'Trojaner')=false
									and contains(title, 'trojaner')=false
									and contains(title, 'Anonymous:')=false
									and contains(title, '�berwachung:')=false
									and contains(title, 'Kopierschutz')=false
									and contains(title, 'gesch�tzt')=false
									and contains(title, 'Jugendschutz')=false
									and contains(title, 'medienschutz')=false
									and contains(title, 'Cyberwar')=false
									and contains(title, 'Security:')=false
									and contains(title, 'Datendiebstahl')=false
									and contains(title, 'Passwortwechsel')=false
									and contains(title, 'verschl�sselung')=false
									and contains(title, 'Passwort')=false
									and (
										contains(title, 'DRM')
										or contains(title, 'Secure Memory')
										or contains(title, 'Identit�t')
										or contains(title, '�berwachungstechnik')
										or contains(title, 'Secure Boot')
										or contains(title, 'Schadsoftware')
										or contains(title, 'DDoS-Attacke')
										or contains(title, 'PC-Durchsuchung durch Arbeitgeber')
									)=false
									
									and(
										contains(title, 'Browser')
										or contains(title, 'Firefox')
										or contains(title, 'Opera ')
										or contains(title, 'Chrome')
										or contains(title, 'Cloud')
										or contains(title, 'Webkit')
										or contains(title, 'browser')
										or contains(title, 'Anonymes Surfen')
										or contains(title, 'Mutation Summary')
									)=false
									
									and contains(title, 'Smartphone')=false
									and contains(title, 'Tablet')=false
									and contains(title, 'Mobil')=false
									and contains(title, 'Handy')=false
									and contains(title, 'iPhone')=false
									and contains(title, 'iPad')=false
									and contains(title, 'Android')=false
									and contains(title, 'Galaxy-Nexus')=false
									and contains(title, 'Galaxy Nexus')=false
									and contains(title, 'Galaxy Tab')=false
									and (
										contains(title, 'Symbian')
										or contains(title, 'Meego')
										or contains(title, 'Galaxy Note')
										or (
											contains(title, 'smart')
											and contains(title, 'Phone')
										)
										or contains(title, 'Galaxy S3')
										or contains(title, 'Jelly Bean')
										or contains(title, 'Gamepad')
										or contains(title, 'Spieletablet')
									)=false
									
									and contains(title, 'Twitter')=false
									and contains(title, 'Facebook')=false
									and (
										contains(title, 'oziales Netzwerk')
										or contains(title, 'Google+')
										or contains(title, 'Flickr')
										or contains(title, 'Pinwheel')
										or contains(title, 'Second Life')
										or contains(title, 'Skype')
										or contains(title, 'Whatsapp')
										or contains(title, 'Messenger')
									)=false
									
									and contains(title, 'Firefox')=false
									and contains(title, 'Mozilla')=false
									and contains(title, 'Linux')=false
									and contains(title, 'Compiler')=false
									and contains(title, 'Gnome')=false
									and contains(title, 'Ubuntu')=false
									and contains(title, 'Open-Source')=false
									and contains(title, 'CouchDB')=false
									and contains(title, 'KDE')=false
									and contains(title, 'Open Source')=false
									and contains(title, 'Unix')=false
									and (
										contains(title, 'GPL')
										or contains(title, 'Open Data')
									)=false
									
									and contains(title, 'Battlefield 3')=false
									and contains(title, 'World of Warcraft')=false
									and contains(title, 'Mechwarrior')=false
									and contains(title, 'Super Mario 3D Land')=false
									and contains(title, 'Starcraft 2')=false
									and contains(title, 'Counter-Strike')=false
									and contains(title, 'Command &amp; Conquer')=false
									and contains(title, 'Doom 3')=false
									and contains(title, 'Skyrim')=false
									and contains(title, 'Quake')=false
									and contains(title, 'Diablo 3')=false
									and contains(title, 'Neverdead')=false
									and contains(title, 'angespielt')=false
									and (
										contains(title, 'Xbox')
										or contains(title, 'PS3')
										or contains(title, 'PSN')
										or contains(title, 'Nintendo 3DS')
									)=false
									and contains(title, 'Rollenspiel')=false
									and contains(title, 'Cryengine')=false
									and contains(title, 'Activision')=false
									and contains(title, 'Zynga')=false
									and contains(title, 'Electronic Arts')=false
									and (
										contains(title, 'Crysis')
										or contains(title, 'Egosoft')
										or contains(title, 'Infinity Blade')
										or contains(title, 'The Witcher 2')
										or contains(title, 'Minecraft')
										or contains(title, 'Steam')
										or contains(title, 'Spielestudio')
										or contains(title, 'Jagged Alliance')
										or contains(title, 'Uncharted')
										or contains(title, 'Spielebranche')
										or contains(title, 'Unreal Engine')
										or contains(title, 'Echtzeitstrategie')
										or contains(title, 'Videospiel')
										or contains(title, 'God of War')
										or contains(title, 'Spielspa�')
										or contains(title, 'Call of Duty')
										or contains(title, 'Rundenstrategie')
										or contains(title, 'Diablo 3')
										or contains(title, 'Playstation')
										or contains(title, 'Angry Birds')
										or contains(title, 'Tekken')
										or contains(title, 'haltige Spiele')
										or contains(title, 'Spieletastatur')
										or contains(title, 'Cry Engine')
										or contains(title, 'Nintendo')
										or contains(title, 'Super Mario')
										or contains(title, 'Gamepad')
										or contains(title, 'Spieletablet')
										or contains(title, 'Bioshock Infinite')
									)=false
									
									and contains(title, 'Schwimmroboter')=false
									and contains(title, 'Roboter')=false
									and contains(title, 'LHC')=false
									and contains(title, 'Raumfahrt')=false
									and contains(title, 'Cyborg')=false
									and contains(title, 'Nanotechnologie')=false
									and contains(title, 'Robotik:')=false
									and contains(title, 'Quantencomputer')=false
									and contains(title, 'Forschung')=false
									and (
										contains(title, 'Solarzelle')
										or contains(title, 'Nanobeschichtung')
										or contains(title, 'Nobelpreis')
										or contains(title, 'Drohnen:')
										or contains(title, 'Tr�gerrakete')
										or contains(title, 'Triebwerk')
										or contains(title, 'Relativit�tstheorie')
										or contains(title, 'Nachbarplanet')
										or contains(title, 'Curiosity:')
										or contains(title, 'Wissenschaft:')
										or contains(title, 'Astronomie:')
										or contains(title, 'Drohne:')
									)=false
									
									and contains(title, 'Urheber')=false
									and contains(title, 'Patent')=false
									and contains(title, 'Parlament')=false
									and contains(title, 'Gericht')=false
									and contains(title, 'Piratenpartei')=false
									and contains(title, 'Kartellamt')=false
									and contains(title, 'Gesetzesentwurf')=false
									and contains(title, 'Bundesnetzagentur')=false
									and contains(title, 'Koalition')=false
									and contains(title, 'gesetz')=false
									and (
										contains(title, 'Datenschutzreform')
										or contains(title, 'Bundespr�fstelle')
										or contains(title, 'Bundesregierung')
										or contains(title, 'Bundesverfassungsgericht')
										or contains(title, 'EuGH')
										or contains(title, 'Acta')
										or contains(title, 'Neue Anklage')
										or contains(title, 'Bew�hrungsstrafe')
										or contains(title, 'GPL')
										or contains(title, 'Datenschutz')
										or contains(title, 'Vorratsdatenspeicherung')
										or contains(title, 'Politiker')
										or contains(title, 'schutzrecht')
										or contains(title, 'Grundrecht')
										or contains(title, 'Meinungsfreiheit')
										or contains(title, 'gerichtshof:')
										or contains(title, 'Filesharing')
										or contains(title, 'Pers�nlichkeitsrecht')
									)=false
									and contains(title, 'Rechtsstreit')=false
									and contains(title, 'illegal')=false
									and contains(title, 'Rechteverwalt')=false
									and contains(title, 'Regierung')=false
									and contains(title, 'minister')=false
									and contains(title, 'Datensch�tzer')=false
									
									and contains(title, 'chip')=false
									and contains(title, 'DDR')=false
									and contains(title, 'CPU')=false
									and contains(title, 'GPU')=false
									and contains(title, 'LED')=false
									and contains(title, 'APU')=false
									and contains(title, 'Touchscreen')=false
									and contains(title, 'Kamera')=false
									and contains(title, 'NAND')=false
									and contains(title, 'PCI Express')=false
									and contains(title, 'ARM')=false
									and contains(title, 'USB')=false
									and contains(title, 'Festplatte')=false
									and contains(title, 'Grafikkarte')=false
									and contains(title, 'Display')=false
									and contains(title, 'Mainboard')=false
									and contains(title, 'SSD')=false
									and contains(title, 'Ultrabook')=false
									and (
										contains(title, 'Xeon')
										or contains(title, 'Pentium')
										or contains(title, 'Celeron')
										or contains(title, 'Athlon')
										or contains(title, 'Phenom')
									)=false
									and contains(title, 'DRAM')=false
									and contains(title, 'Compactflash')=false
									and contains(title, 'XQD')=false
									and contains(title, 'Notebook')=false
									and contains(title, 'Radeon')=false
									and contains(title, 'Firmware')=false
									and contains(title, 'Rechenzentren')=false
									and (
										contains(title, 'Speicherkarte')
										or contains(title, 'Nvidia')
										or contains(title, 'Grafiktreiber')
										or contains(title, '3D-Desktop')
										or contains(title, 'Quad-Core')
										or contains(title, 'Dolby 3D')
										or contains(title, 'OpenGL')
										or contains(title, 'projektor')
										or contains(title, 'Spieletastatur')
										or contains(title, 'Touchpad')
										or contains(title, 'Thunderbolt')
										or contains(title, 'VDSL')
										or contains(title, 'LTE')
										or contains(title, 'Dual-Core')
										or contains(title, 'NAS-System')
									)=false
									
									and contains(title, 'Gesch�ftsmodell')=false
									and contains(title, 'Betriebsversammlung')=false
									and contains(title, 'werbung')=false
									and contains(title, 'TV-Rechte')=false
									and contains(title, 'bestellung')=false
									and contains(title, 'Konkurrenz')=false
									and contains(title, 'B�rsengang')=false
									and contains(title, 'Verkauf')=false
									and contains(title, 'investiert in')=false
									and contains(title, 'sparte')=false
									and contains(title, 'verkaufen')=false
									and contains(title, 'kauft')=false
									and contains(title, 'neue Jobs')=false
									and contains(title, 'B�rsenwert')=false
									and contains(title, 'Marktzahlen')=false
									and (
										contains(title, 'Bundeskartellamt')
										or contains(title, 'vorbestellt')
										or contains(title, 'mehr Lohn')
										or contains(title, 'Abmahnung')
										or contains(title, 'Lohnerh�hung')
										or contains(title, 'Vorverkauf')
										or contains(title, 'nennt Preis')
										or contains(title, 'lizenziert')
										or contains(title, 'gegen Bezahlung')
										or contains(title, 'Preisspekulation')
										or (
											contains(title, 'zieht sich')
											and contains(title, 'markt zur�ck')
										)
										or contains(title, 'Preissenkung')
										or contains(title, 'Liefertermin')
										or contains(title, 'liefert bestellte')
										or contains(title, 'Insolvenz:')
										or contains(title, 'in den Handel')
										or contains(title, 'Onlinehandel:')
										or (
											contains(title, 'will')
											and contains(title, 'anbieten')
										)
										or contains(title, 'reduziert Auftr�ge')
										or (
											contains(title, 'Amazon')
											and contains(title, 'spart')
										)
									)=false
                                    ]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(title, 'Datenschutz')=false
												and contains(title, 'Sicherheit')=false
												and contains(title, 'Hacker')=false
												and contains(title, 'Botnetz')=false
												and contains(title, 'Trojaner')=false
												and contains(title, 'Anonymous:')=false
												and contains(title, '�berwachung:')=false
												and contains(title, 'Kopierschutz')=false
												and contains(title, 'gesch�tzt')=false
												and contains(title, 'Jugendschutz')=false
												and contains(title, 'medienschutz')=false
												and contains(title, 'Cyberwar')=false
												and contains(title, 'Security:')=false
												and contains(title, 'Datendiebstahl')=false
												and contains(title, 'Passwortwechsel')=false
												and contains(title, 'verschl�sselung')=false
												and contains(title, 'Passwort')=false
												and (
													contains(title, 'DRM')
													or contains(title, 'Secure Memory')
													or contains(title, 'Identit�t')
													or contains(title, '�berwachungstechnik')
													or contains(title, 'Secure Boot')
													or contains(title, 'Schadsoftware')
													or contains(title, 'DDoS-Attacke')
													or contains(title, 'PC-Durchsuchung durch Arbeitgeber')
												)=false

												and(
													contains(title, 'Browser')
													or contains(title, 'Firefox')
													or contains(title, 'Opera ')
													or contains(title, 'Chrome')
													or contains(title, 'Cloud')
													or contains(title, 'Webkit')
													or contains(title, 'browser')
													or contains(title, 'Anonymes Surfen')
													or contains(title, 'Mutation Summary')
												)=false
												
												and contains(title, 'Smartphone')=false
												and contains(title, 'Tablet')=false
												and contains(title, 'Mobil')=false
												and contains(title, 'Handy')=false
												and contains(title, 'iPhone')=false
												and contains(title, 'iPad')=false
												and contains(title, 'Android')=false
												and contains(title, 'Galaxy-Nexus')=false
												and contains(title, 'Galaxy Nexus')=false
												and contains(title, 'Galaxy Tab')=false
												and (
													contains(title, 'Symbian')
													or contains(title, 'Meego')
													or contains(title, 'Galaxy Note')
													or (
														contains(title, 'smart')
														and contains(title, 'Phone')
													)
													or contains(title, 'Galaxy S3')
													or contains(title, 'Jelly Bean')
													or contains(title, 'Gamepad')
													or contains(title, 'Spieletablet')
												)=false
												
												and contains(title, 'Twitter')=false
												and contains(title, 'Facebook')=false
												and (
													contains(title, 'oziales Netzwerk')
													or contains(title, 'Google+')
													or contains(title, 'Flickr')
													or contains(title, 'Pinwheel')
													or contains(title, 'Second Life')
													or contains(title, 'Skype')
													or contains(title, 'Whatsapp')
													or contains(title, 'Messenger')
												)=false
												
												and contains(title, 'Firefox')=false
												and contains(title, 'Mozilla')=false
												and contains(title, 'Linux')=false
												and contains(title, 'Compiler')=false
												and contains(title, 'Gnome')=false
												and contains(title, 'Ubuntu')=false
												and contains(title, 'Open-Source')=false
												and contains(title, 'CouchDB')=false
												and contains(title, 'KDE')=false
												and contains(title, 'Open Source')=false
												and contains(title, 'Unix')=false
												and (
													contains(title, 'GPL')
													or contains(title, 'Open Data')
												)=false
												
												and contains(title, 'Battlefield 3')=false
												and contains(title, 'World of Warcraft')=false
												and contains(title, 'Mechwarrior')=false
												and contains(title, 'Super Mario 3D Land')=false
												and contains(title, 'Starcraft 2')=false
												and contains(title, 'Counter-Strike')=false
												and contains(title, 'Command &amp; Conquer')=false
												and contains(title, 'Doom 3')=false
												and contains(title, 'Skyrim')=false
												and contains(title, 'Quake')=false
												and contains(title, 'Diablo 3')=false
												and contains(title, 'Neverdead')=false
												and contains(title, 'angespielt')=false
												and (
													contains(title, 'Xbox')
													or contains(title, 'PS3')
													or contains(title, 'PSN')
													or contains(title, 'Nintendo 3DS')
												)=false
												and contains(title, 'Rollenspiel')=false
												and contains(title, 'Cryengine')=false
												and contains(title, 'Activision')=false
												and contains(title, 'Zynga')=false
												and contains(title, 'Electronic Arts')=false
												and (
													contains(title, 'Crysis')
													or contains(title, 'Egosoft')
													or contains(title, 'Infinity Blade')
													or contains(title, 'The Witcher 2')
													or contains(title, 'Minecraft')
													or contains(title, 'Steam')
													or contains(title, 'Spielestudio')
													or contains(title, 'Jagged Alliance')
													or contains(title, 'Uncharted')
													or contains(title, 'Spielebranche')
													or contains(title, 'Unreal Engine')
													or contains(title, 'Echtzeitstrategie')
													or contains(title, 'Videospiel')
													or contains(title, 'God of War')
													or contains(title, 'Spielspa�')
													or contains(title, 'Call of Duty')
													or contains(title, 'Rundenstrategie')
													or contains(title, 'Diablo 3')
													or contains(title, 'Playstation')
													or contains(title, 'Angry Birds')
													or contains(title, 'Tekken')
													or contains(title, 'haltige Spiele')
													or contains(title, 'Spieletastatur')
													or contains(title, 'Cry Engine')
													or contains(title, 'Nintendo')
													or contains(title, 'Super Mario')
													or contains(title, 'Gamepad')
													or contains(title, 'Spieletablet')
													or contains(title, 'Bioshock Infinite')
												)=false
												
												and contains(title, 'Schwimmroboter')=false
												and contains(title, 'Roboter')=false
												and contains(title, 'LHC')=false
												and contains(title, 'Raumfahrt')=false
												and contains(title, 'Cyborg')=false
												and contains(title, 'Nanotechnologie')=false
												and contains(title, 'Robotik:')=false
												and contains(title, 'Quantencomputer')=false
												and contains(title, 'Forschung')=false
												and (
													contains(title, 'Solarzelle')
													or contains(title, 'Nanobeschichtung')
													or contains(title, 'Nobelpreis')
													or contains(title, 'Drohnen:')
													or contains(title, 'Tr�gerrakete')
													or contains(title, 'Triebwerk')
													or contains(title, 'Relativit�tstheorie')
													or contains(title, 'Nachbarplanet')
													or contains(title, 'Curiosity:')
													or contains(title, 'Wissenschaft:')
													or contains(title, 'Astronomie:')
													or contains(title, 'Drohne:')
												)=false
												
												and contains(title, 'Urheber')=false
												and contains(title, 'Patent')=false
												and contains(title, 'Parlament')=false
												and contains(title, 'Gericht')=false
												and contains(title, 'Piratenpartei')=false
												and contains(title, 'Kartellamt')=false
												and contains(title, 'Bundespr�fstelle')=false
												and contains(title, 'Gesetzesentwurf')=false
												and contains(title, 'Bundesnetzagentur')=false
												and contains(title, 'Koalition')=false
												and contains(title, 'gesetz')=false
												and (
													contains(title, 'Datenschutzreform')
													or contains(title, 'Bundesregierung')
													or contains(title, 'Bundesverfassungsgericht')
													or contains(title, 'EuGH')
													or contains(title, 'Acta')
													or contains(title, 'Neue Anklage')
													or contains(title, 'Bew�hrungsstrafe')
													or contains(title, 'GPL')
													or contains(title, 'Datenschutz')
													or contains(title, 'Vorratsdatenspeicherung')
													or contains(title, 'Politiker')
													or contains(title, 'schutzrecht')
													or contains(title, 'Grundrecht')
													or contains(title, 'Meinungsfreiheit')
													or contains(title, 'gerichtshof:')
													or contains(title, 'Filesharing')
													or contains(title, 'Pers�nlichkeitsrecht')
												)=false
												and contains(title, 'Rechtsstreit')=false
												and contains(title, 'illegal')=false
												and contains(title, 'Rechteverwalt')=false
												and contains(title, 'Regierung')=false
												and contains(title, 'minister')=false
												and contains(title, 'Datensch�tzer')=false
												
												and contains(title, 'chip')=false
												and contains(title, 'DDR')=false
												and contains(title, 'CPU')=false
												and contains(title, 'GPU')=false
												and contains(title, 'APU')=false
												and contains(title, 'LED')=false
												and contains(title, 'Touchscreen')=false
												and contains(title, 'Kamera')=false
												and contains(title, 'NAND')=false
												and contains(title, 'PCI Express')=false
												and contains(title, 'ARM')=false
												and contains(title, 'USB')=false
												and contains(title, 'Festplatte')=false
												and contains(title, 'Grafikkarte')=false
												and contains(title, 'Display')=false
												and contains(title, 'Mainboard')=false
												and contains(title, 'SSD')=false
												and contains(title, 'Ultrabook')=false
												and (
													contains(title, 'Xeon')
													or contains(title, 'Pentium')
													or contains(title, 'Celeron')
													or contains(title, 'Athlon')
													or contains(title, 'Phenom')
												)=false
												and contains(title, 'DRAM')=false
												and contains(title, 'Compactflash')=false
												and contains(title, 'XQD')=false
												and contains(title, 'Notebook')=false
												and contains(title, 'Radeon')=false
												and contains(title, 'Firmware')=false
												and contains(title, 'Rechenzentren')=false
												and (
													contains(title, 'Speicherkarte')
													or contains(title, 'Nvidia')
													or contains(title, 'Grafiktreiber')
													or contains(title, '3D-Desktop')
													or contains(title, 'Quad-Core')
													or contains(title, 'Dolby 3D')
													or contains(title, 'OpenGL')
													or contains(title, 'projektor')
													or contains(title, 'Spieletastatur')
													or contains(title, 'Touchpad')
													or contains(title, 'Thunderbolt')
													or contains(title, 'VDSL')
													or contains(title, 'LTE')
													or contains(title, 'Dual-Core')
													or contains(title, 'NAS-System')
												)=false
												
												and contains(title, 'Gesch�ftsmodell')=false
												and contains(title, 'Betriebsversammlung')=false
												and contains(title, 'werbung')=false
												and contains(title, 'TV-Rechte')=false
												and contains(title, 'bestellung')=false
												and contains(title, 'Konkurrenz')=false
												and contains(title, 'B�rsengang')=false
												and contains(title, 'Verkauf')=false
												and contains(title, 'investiert in')=false
												and contains(title, 'sparte')=false
												and contains(title, 'verkaufen')=false
												and contains(title, 'kauft')=false
												and contains(title, 'neue Jobs')=false
												and contains(title, 'B�rsenwert')=false
												and contains(title, 'Marktzahlen')=false
												and (
													contains(title, 'Bundeskartellamt')
													or contains(title, 'vorbestellt')
													or contains(title, 'mehr Lohn')
													or contains(title, 'Abmahnung')
													or contains(title, 'Lohnerh�hung')
													or contains(title, 'Vorverkauf')
													or contains(title, 'nennt Preis')
													or contains(title, 'lizenziert')
													or contains(title, 'gegen Bezahlung')
													or contains(title, 'Preisspekulation')
													or (
														contains(title, 'zieht sich')
														and contains(title, 'markt zur�ck')
													)
													or contains(title, 'Preissenkung')
													or contains(title, 'Liefertermin')
													or contains(title, 'liefert bestellte')
													or contains(title, 'Insolvenz:')
													or contains(title, 'in den Handel')
													or contains(title, 'Onlinehandel:')
													or (
														contains(title, 'will')
														and contains(title, 'anbieten')
													)
													or contains(title, 'reduziert Auftr�ge')
													or (
														contains(title, 'Amazon')
														and contains(title, 'spart')
													)
												)=false
                                            	]
											)"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
            			'<xsl:value-of select="$sectionName" />',
            			'<xsl:value-of select="$linkCounter" />'
            			);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
