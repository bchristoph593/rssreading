<?php 
  /*
   * the '<?php' line MUST be the very first line
   */
  
  /*
   * if the cookie $_COOKIE["PHPSESSID"] is set,
   * we will re-use it
   */
  
  if(isset($_COOKIE["PHPSESSID"]) && (! empty($_COOKIE["PHPSESSID"])) ) {
    session_id( $_COOKIE["PHPSESSID"] );
    $mode = "restore session by cookie";
    
  } else {
    $mode = "create new session";
  }
  
  // $sess_ID = session_id();
  if( empty($sess_ID) ) { 
    $state = session_start(); 
    $sess_ID = session_id();
  }

  if( isset($_COOKIE['expire']) && (! empty($_COOKIE['expire'])) ) {
    $msg_expire = "not expired";
  } else {
    $msg_expire = "expired";
  }
  
  $msg_reset = "no cookie reset";
  if( $msg_expire == "expired" ) {
    $msg_reset = "reset cookie";
    $cookie_expire = time() + 60; // 60 = 1 minute
    
    setcookie("PHPSESSID", '' );
    setcookie('expire', $cookie_expire, $cookie_expire );
    
  } else {
    setcookie("PHPSESSID", $sess_ID, $cookie_expire );
  }
  
  /*
   * - if setcookie() was applied before, value is not directly accessible
   * - accessible just after page is load 
   */
  $msg = "[cookie set] 'expire' has value '".$_COOKIE['expire']. "'". "<br>";
?>

<?php
/*
  if (isset($_COOKIE['key'])) {
    $msg = "[cookie set] 'key' has value '".$_COOKIE['key']."'". "<br>";
    $msg = $msg. "[cookie set] 'expire' has value '".$_COOKIE['expire']. "<br>";
    
  } else {
    $msg = "[cookie not set]". "<br>";
    $cookie_expire = time() + 60; // 60 = 1 minute
    setcookie('expire', $cookie_expire, $cookie_expire );
    setcookie('key', 'this is the value', $cookie_expire );
  }
*/
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>Cookie Test</title>
  </head>

  <body>
<?php
  if($state) {
    echo "session started";
    echo "<br>";
  }
  echo "session-state: '". $state. "' ";
  echo "<br>";
  echo "session-mode: '". $mode. "'";
  echo "<br>";
  echo "expire-msg: '". $msg_expire. "'";
  echo "<br>";
  echo "reset-msg: '". $msg_reset. "'";
  echo "<br>";
  var_dump($_SESSION);
  echo "<br>";
  echo "current session-ID: '". $sess_ID. "' ";
  echo "<br>";
  echo "SID: ".SID."<br>session_id(): ".session_id()."<br>COOKIE: ".$_COOKIE["PHPSESSID"];
  echo "<br>";
  echo "<br>";
  echo "SESSION['testKey']: '". $_SESSION["testKey"]. "'";
  echo "<br>";
  $_SESSION["testKey"] = "this session is open until: ". $_COOKIE["expire"];
  echo "<br>";
  echo $msg;
  
  echo "Cookie Test";
?>
  </body>
</html>
