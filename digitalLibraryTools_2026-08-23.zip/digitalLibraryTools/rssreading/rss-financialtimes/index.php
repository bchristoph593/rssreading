<?php
	include("../uc/header_imports.php");
	
   	// $xmlDoc->load("http://www.ftd.de/rss2/index.xml");
	
	$xslPath = "xsl-sheets/rss-ftd.xsl";
	$rssPath = "http://newsengine.v232681353.yourvserver.net/rss-news/ftd/schlagzeilen/index.xml";
	
	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	@include("temp.php");
?>