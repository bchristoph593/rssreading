<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Financial Times Deutschland | Schlagzeilen - crossreading</title>
                <link rel="shortcut icon" href="/images/favicon/fav-ftd.ico" />
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            			
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("FinancialTimes");
						?</xsl:processing-instruction>
                    </div>
                                        
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                            <br />
<!--
							<a href="index-finanzen.php">&gt; Finanzen</a>
							<a href="index-unternehmen.php">&gt; Unternehmen</a>
							<a href="index-politik.php">&gt; Politik</a>
							<a href="index-it_medien.php">&gt; IT + Medien</a>
-->
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                            Newsletter &gt; <xsl:processing-instruction name="php">
                                                echo htmlentities("<xsl:value-of select="title" />");
                                            ?</xsl:processing-instruction>
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="Finanzen" />
                        <br />
                        <xsl:call-template name="Unternehmen" />
                        <br />
                        <xsl:call-template name="PolitikEuropa" />
                        <br />
                        <xsl:call-template name="Politik" />
                        <br />
                        <xsl:call-template name="IT-Medien" />
                        <br />
                        <xsl:call-template name="Wissen" />
                        <br />
                        <xsl:call-template name="Sport" />
                        <br />
                        <xsl:call-template name="Auto" />
                        <br />
                        <xsl:call-template name="Sonstige" />
                        <br />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
			</body>
			
		</html>	
	</xsl:template>

	<xsl:template name="Finanzen">
		<strong>&gt; Finanzen</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/finanzen'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'finanzen'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Unternehmen">
    	<strong>&gt; Unternehmen</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/unternehmen'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'unternehmen'"/>
		</xsl:variable>
        
        <div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="PolitikEuropa">
    	<strong>&gt; Politik - Europa</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik-europa'"/>
		</xsl:variable>
        
        <div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										and (
											contains(title, 'griechisch')
											or contains(title, 'Frankreich')
											or contains(title, 'Gro�britanien')
											or contains(title, 'urop�isch')
											or contains(title, 'Griechenland')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										and (
											contains(title, 'griechisch')
											or contains(title, 'Frankreich')
											or contains(title, 'Gro�britanien')
											or contains(title, 'urop�isch')
											or contains(title, 'Griechenland')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Politik">
    	<strong>&gt; Politik</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik'"/>
		</xsl:variable>
        
        <div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										and (
											contains(title, 'griechisch')
											or contains(title, 'Frankreich')
											or contains(title, 'Gro�britanien')
											or contains(title, 'urop�isch')
											or contains(title, 'Griechenland')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)=false
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										and (
											contains(title, 'griechisch')
											or contains(title, 'Frankreich')
											or contains(title, 'Gro�britanien')
											or contains(title, 'urop�isch')
											or contains(title, 'Griechenland')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)=false
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="IT-Medien">
    	<strong>&gt; IT-Medien</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/it-medien'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'it-medien'"/>
		</xsl:variable>
        
        <div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Wissen">
    	<strong>&gt; Wissen</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/wissen'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wissen'"/>
		</xsl:variable>
        
        <div class="divLinkSection">
			<xsl:for-each select="item[
											contains(link, $searchFor)
											or (
												contains(title, 'Bologna-Reform')
												or contains(title, 'Bachelor')
											)
										]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
											contains(link, $searchFor)
											or (
												contains(title, 'Bologna-Reform')
												or contains(title, 'Bachelor')
											)
										])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sport">
    	<strong>&gt; Sport</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/sport'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport'"/>
		</xsl:variable>
        
        <div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Auto">
    	<strong>&gt; Auto</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'.de/auto'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'auto'"/>
		</xsl:variable>
        
        <div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sonstige">
    	<strong>&gt; Sonstige</strong>

		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstiges'"/>
		</xsl:variable>
                
        <div class="divLinkSection">
			<xsl:for-each select="item[
            							contains(link, '.de/unternehmen')=false
            							and contains(link, '.de/finanzen')=false
                                    	and contains(link, '.de/politik')=false
                                    	and contains(link, '.de/it-medien')=false
                                    	and contains(link, '.de/wissen')=false
										and (
											contains(title, 'Bologna-Reform')
											or contains(title, 'Bachelor')
										)=false
                                    	and contains(link, '.de/sport')=false
                                    	and contains(link, '.de/auto')=false
                                    ]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
            							contains(link, '.de/unternehmen')=false
            							and contains(link, '.de/finanzen')=false
                                    	and contains(link, '.de/politik')=false
                                    	and contains(link, '.de/it-medien')=false
                                    	and contains(link, '.de/wissen')=false
										and (
											contains(title, 'Bologna-Reform')
											or contains(title, 'Bachelor')
										)=false
                                    	and contains(link, '.de/sport')=false
                                    	and contains(link, '.de/auto')=false
                                    ]
									)"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
        	
</xsl:stylesheet>
