<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

  <html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Financial Times Deutschland | Schlagzeilen - crossreading</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("FinancialTimes");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a><br></br></div></div><div class="divContent"><strong style="margin:3px;">
                            Newsletter &gt; <?php 
                                                echo htmlentities("Financial Times Deutschland");
                                            ?></strong><br></br><hr></hr><strong xmlns="">&gt; Finanzen</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'finanzen',
                    	'1',
                    	'17 Feb 2012 16:39:54',
                    	'http://www.ftd.de/finanzen/maerkte/anleihen-devisen/:schuldenkrise-faule-kredite-in-spanien-wachsen-rasant/60170411.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Schuldenkrise: Faule Kredite in Spanien wachsen rasant',
                    	'Das Volumen der Zahlungsr�ckst�nde in den B�chern der spanischen Banken ist so hoch wie seit 1994 nicht mehr. Ein Grund daf�r ist die schlechte Wirtschaftslage.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'finanzen',
                    	'2',
                    	'17 Feb 2012 08:46:11',
                    	'http://www.ftd.de/finanzen/maerkte/:anstehender-haircut-europas-notenbanken-bringen-griechen-bonds-in-sicherheit/60170137.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Anstehender "Haircut": Europas Notenbanken bringen Griechen-Bonds in Sicherheit',
                    	'Die Euro-Zentralbanken wollen Verluste beim anstehenden Schuldenschnitt vermeiden. Das soll ein technischer Trick mit neuen Seriennummern auf den alten Papieren erm�glichen.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'finanzen',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Unternehmen</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'1',
                    	'17 Feb 2012 20:42:16',
                    	'http://www.ftd.de/unternehmen/handel-dienstleister/:paketbranche-tnt-schlaegt-milliardenofferte-von-ups-aus/60170592.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Paketbranche: TNT schl�gt Milliardenofferte von UPS aus',
                    	'Bei den Paketlieferdiensten bahnt sich eine gigantische �bernahmeschlacht an: Branchenprimus UPS will den Konkurrenten TNT Express schlucken - doch der wehrt sich.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'2',
                    	'17 Feb 2012 11:21:04',
                    	'http://www.ftd.de/unternehmen/handel-dienstleister/:tarifstreit-in-frankfurt-gewerkschaft-droht-mit-laengerem-flughafenstreik/60170284.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Tarifstreit in Frankfurt: Gewerkschaft droht mit l�ngerem Flughafenstreik',
                    	'Auf dem Vorfeld des Frankfurter Flughafens wird gestreikt, zahlreiche Fl�ge fallen aus. Die Gewerkschaft plant f�r kommende Woche mit einer Fortsetzung.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'unternehmen',
                    	'3',
                    	'17 Feb 2012 04:00:00',
                    	'http://www.ftd.de/unternehmen/industrie/:flugsicherheit-probleme-mit-alunieten-am-airbus-a380/60170051.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Flugsicherheit: Probleme mit Alunieten am Airbus A380',
                    	'Die Flugsicherheitsbeh�rde hat eine neue Schwachstelle beim Riesenflugzeug entdeckt: Die Nieten in der Flugzeugspitze k�nnten bei Extrembelastung zum Problem werden. Airbus wiegelt ab: Ein aktues Sicherheitsproblem sei das nicht.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'unternehmen',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Politik</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'politik',
                    	'1',
                    	'17 Feb 2012 23:30:20',
                    	'http://www.ftd.de/politik/deutschland/:nach-wulffs-abgang-opposition-macht-merkel-die-kanditatensuche-schwer/60170623.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Nach Wulffs Abgang: Opposition macht Merkel die Kanditatensuche schwer',
                    	'Die �ra von Christian Wulff als Bundespr�sident ist vorbei. Die Kanzlerin bietet SPD und Gr�nen die Suche nach einem gemeinsamen Bewerber an. Die zwei Partien bauen jedoch H�rden auf. Ein potenzieller Kandidat nimmt sich derweil aus dem Rennen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'2',
                    	'17 Feb 2012 18:10:50',
                    	'http://www.ftd.de/politik/deutschland/:praesidentenruecktritt-praesident-a-d-zwingt-merkel-zur-grossen-koalition/60170407.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Pr�sidentenr�cktritt: Pr�sident a.D. zwingt Merkel zur Gro�en Koalition',
                    	'Die Worte der Kanzlerin zum Abschied von Christian Wulff fallen �u�erst knapp aus. Schlie�lich dr�ngt die Suche nach einem Nachfolger in den Vordergrund. Und da ist die CDU-Chefin auf die Sozialdemokraten angewiesen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'3',
                    	'17 Feb 2012 15:53:11',
                    	'http://www.ftd.de/politik/deutschland/:ruecktrittsgruende-fragezeichen-hinter-wulffs-ehrensold/60170426.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'R�cktrittsgr�nde: Fragezeichen hinter Wulffs Ehrensold',
                    	'Bundespr�sidenten au�er Diensten werden mit 200.000 Euro pro Jahr versorgt. Hat auch Christian Wulff Anspruch auf die Ruhebez�ge? Selbst in der Union gibt es Zweifel. Kanzlerin Merkel muss den heiklen Fall entscheiden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'4',
                    	'17 Feb 2012 14:05:58',
                    	'http://www.ftd.de/politik/deutschland/:ruecktritt-des-praesidenten-so-ging-der-uneinsichtige/60170359.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'R�cktritt des Pr�sidenten: So ging der Uneinsichtige',
                    	'Acht Wochen sa� Christian Wulff seine Aff�re aus, nicht einmal vier Minuten braucht er f�r seinen R�cktritt. Warum er nun doch geht, l�sst er im Vagen. Eine Reportage aus Bellevue.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'5',
                    	'17 Feb 2012 13:20:51',
                    	'http://www.ftd.de/politik/deutschland/:ende-einer-dienstzeit-wulff-bedroht-merkels-machtsystem/60170349.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Ende einer Dienstzeit: Wulff bedroht Merkels Machtsystem',
                    	'Der Ex-Bundespr�sident hat der Demokratie geschadet, aber ungewollt auch den Beweis erbracht, dass sie sehr gut funktioniert. Allerdings: Das System Merkel ist marode. Hoffentlich zieht die Kanzlerin die Lehren daraus.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'6',
                    	'17 Feb 2012 12:31:44',
                    	'http://www.ftd.de/politik/deutschland/:lange-liste-das-brachte-den-praesidenten-zu-fall/60168813.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Lange Liste: Das brachte den Pr�sidenten zu Fall',
                    	'Am Ende verloren sich die meisten Vorw�rfe in der un�bersichtlichen Masse - ein Teil der Wulffschen Verteidigung. �berstanden hat er die vielen Aff�ren und Aff�rchen dennoch nicht. Die Ungereimtheiten der letzten Monate zusammengefasst'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'7',
                    	'17 Feb 2012 11:29:10',
                    	'http://www.ftd.de/politik/europa/:museumsdiebstahl-raeuber-in-olympia/60170258.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Museumsdiebstahl: R�uber in Olympia',
                    	'Ein Kunstraub mit Folgen: Mitten in den Wirren des Schuldendramas werden den Griechen dutzende antike Sch�tze gestohlen. Bewaffnete M�nner �berfallen das Olympia-Museum. Der Kulturminister bietet seinen R�cktritt an.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'8',
                    	'17 Feb 2012 11:00:00',
                    	'http://www.ftd.de/politik/international/:kolumne-thomas-fricke-der-grieche-in-uns/60170019.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Kolumne: Thomas Fricke: Der Grieche in uns',
                    	'Um Kritik an der deutschen Exportbilanz zu verhindern, hat die Bundesregierung in Br�ssel die Kriterien manipuliert. Das macht sie nicht zum ersten Mal. Und ist fatal, wenn man f�hren will.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'9',
                    	'17 Feb 2012 10:45:12',
                    	'http://www.ftd.de/politik/deutschland/:praesident-in-not-wulffs-moegliche-erben/60146087.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Pr�sident in Not: Wulffs m�gliche Erben',
                    	'Kann sich der Bundespr�sident im Amt halten? Bei einem R�cktritt m�sste die Nachfolge rasch geregelt werden. Ein Blick auf die potenziellen Bewerber f�r Schloss Bellevue.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'10',
                    	'16 Feb 2012 19:38:04',
                    	'http://www.ftd.de/politik/europa/:schuldenkrise-griechenland-braucht-definitiv-mehr-als-130-mrd-euro-hilfe/60170012.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Schuldenkrise: Griechenland braucht definitiv mehr als 130 Mrd. Euro Hilfe',
                    	'Die Troika bescheinigt, was seit Tagen vermutet wird: Wenn Hellas vor der Pleite bewahrt werden soll, muss die geplante Finanzspritze aufgestockt werden. Als eine Option wird ein h�herer Schuldenschnitt f�r private Investoren genannt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'11',
                    	'16 Feb 2012 17:10:28',
                    	'http://www.ftd.de/politik/deutschland/:beschaeftigung-mehr-flexibilitaet-fuer-arbeitnehmer/60169922.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Besch�ftigung: Mehr Flexibilit�t f�r Arbeitnehmer',
                    	'Die Kombirente soll �lteren Mitarbeitern ab 2013 den Weg in den Ruhestand vereinfachen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'12',
                    	'16 Feb 2012 14:09:48',
                    	'http://www.ftd.de/politik/europa/:schuldenkrise-der-deutsch-griechische-shitstorm/60169755.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Schuldenkrise: Der deutsch-griechische Shitstorm',
                    	'Zwischen Athen und den Euro-Partnern entbrennt ein Krieg der Worte. Die Geldgeber sagen den Griechen mittlerweile unverbl�mt die Meinung. Die Politiker in dem hochverschuldeten Land f�hlen sich entm�ndigt - und reagieren beleidigt.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'politik',
                    	'12'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; IT-Medien</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'it-medien',
                    	'1',
                    	'17 Feb 2012 17:45:30',
                    	'http://www.ftd.de/it-medien/medien-internet/:datenschutzeinstellungen-im-safari-browser-google-trickst-apple-nutzer-aus/60170395.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Datenschutzeinstellungen im Safari-Browser: Google trickst Apple-Nutzer aus',
                    	'Apple will verhindern, dass Nutzer des Safari-Browsers ungewollt Cookies auf die Festplatte bekommen. Das hat den neuen Dienst Google+ beeintr�chtigt und die Programmierer nutzten eine Sicherheitsl�cke aus. Das hatte weiter reichende Folgen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'it-medien',
                    	'2',
                    	'17 Feb 2012 16:26:01',
                    	'http://www.ftd.de/it-medien/medien-internet/:internet-facebook-hoehlt-twitters-geschaeft-aus/60170376.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Internet: Facebook h�hlt Twitters Gesch�ft aus',
                    	'Das Netzwerk gibt Usern M�glichkeiten an die Hand gibt, die zu Lasten des Konkurrenten gehen. Neuerdings ist es ganz einfach, via Facebook zu "zwitschern".'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'it-medien',
                    	'3',
                    	'17 Feb 2012 14:53:13',
                    	'http://www.ftd.de/it-medien/it-telekommunikation/:bestechungsvorwuerfe-murdoch-macht-gut-wetter-bei-der-sun/60170378.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Bestechungsvorw�rfe: Murdoch macht gut Wetter bei der "Sun"',
                    	'Er kam zum Tr�sten. Nach mehreren vor�bergehenden Festnahmen wollte der Medienunternehmer pers�nlich die Wogen in der Redaktion seines Boulevardblattes gl�tten. Die Skandale der vergangenen Monate gingen f�r Murdoch ziemlich ins Geld.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'it-medien',
                    	'4',
                    	'16 Feb 2012 19:40:46',
                    	'http://www.ftd.de/it-medien/it-telekommunikation/:kopf-des-tages-philip-falcone-der-sternengreifer/60170017.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Kopf des Tages: Philip Falcone - Der Sternengreifer',
                    	'In der Finanzkrise galt er als einer der gerissensten Hedge-Fonds-Manager. Mit dem Mobilfunk-Startup Lightsquared droht Philip Falcone den Ruf endg�ltig zu verspielen.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'it-medien',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Wissen</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wissen',
                    	'1',
                    	'17 Feb 2012 17:27:37',
                    	'http://www.ftd.de/wissen/:kultstaette-floetentoene-koennten-raetsel-um-stonehenge-loesen/60170535.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Kultst�tte: Fl�tent�ne k�nnten R�tsel um Stonehenge l�sen',
                    	'Zahlreiche Theorien kursieren um die gesch�tzte 5000 Jahre alte Kultst�tte im S�den Englands. Eine neue Theorie sieht den Grund f�r die Anordnung der Steinkreise in der Akustik.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wissen',
                    	'2',
                    	'17 Feb 2012 16:41:03',
                    	'http://www.ftd.de/wissen/leben/:schlafbedarf-forscher-entdecken-langschlaefer-gen/60170514.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Schlafbedarf: Forscher entdecken Langschl�fer-Gen',
                    	'"Wer morgens l�nger schl�ft, h�lts abends l�nger aus" sang die Hamburger Countryband Truck Stop. Wisschenschaftler der Uni M�nchen haben nun den ersten genetischen Faktor identifiziert, der die Schlafdauer beeinflusst.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wissen',
                    	'3',
                    	'17 Feb 2012 16:32:14',
                    	'http://www.ftd.de/wissen/leben/:raumfahrt-die-vermessung-der-erde/60170509.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Raumfahrt: Die Vermessung der Erde',
                    	'Vier Jahre lang sollen genaue Daten zum Magnetfeld unseres Planeten ermittelt werden. Forscher erhoffen sich dadurch Erkenntnisse zum sogenannten Polsprung.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wissen',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sport',
                    	'1',
                    	'17 Feb 2012 10:00:00',
                    	'http://www.ftd.de/sport/:boxen-lieber-klitschko-als-knast/60169975.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Boxen: Lieber Klitschko als Knast',
                    	'Dereck Chisora, ein tunichtguter Million�rssohn, darf sich gegen den �lteren der Champions versuchen. Klitschko nennt den Gegner einen der "st�rksten Boxer der Welt".'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sport',
                    	'2',
                    	'17 Feb 2012 07:49:11',
                    	'http://www.ftd.de/sport/fussball/:europa-league-hannover-gewinnt-hoch-verdient-schalke-rettet-remis/60170125.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Europa League: Hannover gewinnt hoch verdient, Schalke rettet Remis',
                    	'Mit einem Kraftakt hat Hannover 96 Kurs auf das Achtelfinale der Europa League genommen. Die Niedersachsen drehten gegen Christoph Daums FC Br�gge das Hinspiel und gewannen noch 2:1.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sport',
                    	'3',
                    	'16 Feb 2012 13:51:27',
                    	'http://www.ftd.de/sport/:nordderby-guerrero-bietet-pizarro-ein-pferd-als-wetteinsatz/60169725.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Nordderby: Guerrero bietet Pizarro ein Pferd als Wetteinsatz',
                    	'Die beiden Peruaner verbindet nicht nur eine jahrelange Freundschaft, sondern auch die Liebe zu Rennpferden. Wenn ihre Mannschaften im Nordderby aufeinandertreffen, soll ein Gaul den Besitzer wechseln.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Auto</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'auto',
                    	'1',
                    	'17 Feb 2012 14:00:00',
                    	'http://www.ftd.de/auto/praxistests/:fahrbericht-skoda-citigo-1-0-vw-up-leger/60169628.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Fahrbericht: Skoda Citigo 1.0 - VW-Up-Leger',
                    	'Er sollte eigentlich nur ein preisg�nstigeres Derivat des VW Up werden, doch der Skoda Citigo ist mehr als das. Mit der einen oder anderen Innenraumraffinesse zeigt sich der kleine Tscheche allemal so durchdacht wie sein Wolfsburger Bruder.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'auto',
                    	'2',
                    	'16 Feb 2012 17:09:42',
                    	'http://www.ftd.de/auto/trends/:gescheitertes-marketing-ein-auto-namens-kothaufen/60169918.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Gescheitertes Marketing: Ein Auto namens Kothaufen',
                    	'Wichser, Stuhlgang, Schei�dreck - alles Modellbezeichnungen f�r Fahrzeuge. Unterschiedliche sprachliche Bedeutungen auf der weiten Welt l�sen dieses Problem aus. F�r Autobauer ist die Namensfindung ein vermintes Gel�nde.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'auto',
                    	'3',
                    	'16 Feb 2012 14:00:00',
                    	'http://www.ftd.de/auto/praxistests/:fahrbericht-fiat-freemont-awd-keine-bergziege/60167291.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Fahrbericht: Fiat Freemont AWD - keine Bergziege',
                    	'Mit dem Freemont ist den Fiat-Ingenieuren ein praktischer Crossover gelungen, der sich mit viel Spa� im Alltag bewegen l�sst. Mit der neuen Allradversion geht das jetzt auch bei Schnee, Eis und im leichten Gel�nde.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'auto',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstiges',
                    	'1',
                    	'17 Feb 2012 17:30:00',
                    	'http://www.ftd.de/lifestyle/outofoffice/:interview-das-gute-an-der-schattenwirtschaft/60170348.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Interview: Das Gute an der Schattenwirtschaft',
                    	'Mit informellen Jobs schlagen sich weltweit Milliarden Menschen durch. "System D" nennt US-Autor Robert Neuwirth diese Grauzone - er bewundert den Unternehmergeist von Produktpiraten und Wasserverk�ufern.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstiges',
                    	'2',
                    	'17 Feb 2012 16:24:53',
                    	'http://www.ftd.de/lifestyle/entertainment/:reichstagsverhuellung-christos-sammlung-soll-nach-berlin/60170467.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Reichstagsverh�llung: Christos Sammlung soll nach Berlin',
                    	'Rund 400 Objekte umfasst die Dokumentation zur Reichstagsverh�llung 1995, unter anderem Modelle des Reichstags, Originalzeichnungen und Collagen, Fotos und auch Stoffbahnen. Der K�nstler will sie verkaufen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstiges',
                    	'3',
                    	'17 Feb 2012 16:00:31',
                    	'http://www.ftd.de/lifestyle/entertainment/:500-folgen-die-simpsons-jubilaeumsfeier-mit-julian-assange/60170387.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'500 Folgen "Die Simpsons": Jubil�umsfeier mit Julian Assange',
                    	'Auch heute halten viele die "Simpsons" noch  f�r Kinderfernsehen - doch mitnichten! Die Serie, die unz�hlige Preise und Milliarden einspielte, hat als spitze Satire das Fernsehen ver�ndert.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstiges',
                    	'4',
                    	'17 Feb 2012 15:03:46',
                    	'http://www.ftd.de/lifestyle/luxus/:das-will-ich-auch-das-punkerkostuem-von-markus-soeder/60170417.html#utm_source=rss2&utm_medium=rss_feed&utm_campaign=/',
                    	'Das will ich auch!: Das Punkerkost�m von Markus S�der',
                    	'Er hat kaum Erfahrung, kann aber gut reden. So l�sst sich ohne Sch�nf�rberei zusammenfassen, was letzten November zum Antritt des bayerischen Finanzministers Markus S�der (CSU) aus den Reihen seiner eigenen Partei zu h�ren war. Aber ein Kommunikationstalent ist der Mann ja durchaus - in Wort und Bild.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstiges',
                    	'4'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>

