<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Sueddeutsche Online | Schlagzeilen - crossreading</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Sueddeutsche");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a></div></div><div class="divContent"><strong style="margin:3px;">
                            Newsletter &gt; Artikel / S�ddeutsche.de</strong><br></br><hr></hr><strong xmlns="">&gt; Wirtschaft</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'1',
                    	'17 Feb 2012 16:54:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbaf0b/l/0Lsz0Bde0C10B1287327/story01.htm',
                    	'Insolvenz der Gro�b�ckerei: M�ller-Brot soll verkauft werden',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Politik</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'politik',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport - Fussball</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'sportFussball',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'17 Feb 2012 21:52:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbcbee9/l/0Lsz0Bde0C10B1287448/story01.htm',
                    	'Mainz mit Remis in Hoffenheim: Babbel bleibt auch im zweiten Spiel sieglos',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'17 Feb 2012 21:19:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbcb710/l/0Lsz0Bde0C10B1287442/story01.htm',
                    	'Sensation in Berlin: Rehhagel soll Trainer bei Hertha BSC werden',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'17 Feb 2012 20:28:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc8d0a/l/0Lsz0Bde0C10B1287439/story01.htm',
                    	'Niederl�ndischer K�nigssohn von Lawine versch�ttet',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'17 Feb 2012 19:56:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc874d/l/0Lsz0Bde0C10B1286350A/story01.htm',
                    	'General Motors und seine Europa-Tochter Opel: Detroit wird aggressiv',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'17 Feb 2012 19:40:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbb793/l/0Lsz0Bde0C10B1287335/story01.htm',
                    	'Wulff-R�cktritt: Merkels dritter Versuch muss sitzen',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'6',
                    	'17 Feb 2012 19:31:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc71fc/l/0Lsz0Bde0C10B1287430A/story01.htm',
                    	'Eurovision Song Contest in Aserbaidschan: Ein bisschen S�ngerfrieden',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'7',
                    	'17 Feb 2012 19:27:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc71fd/l/0Lsz0Bde0C10B1287426/story01.htm',
                    	'Sport kompakt: "Dreckiger Sieg" f�r St. Pauli',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'8',
                    	'17 Feb 2012 18:49:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc281f/l/0Lsz0Bde0C10B1287422/story01.htm',
                    	'Twilight-Star Robert Pattinson auf der Berlinale',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'9',
                    	'17 Feb 2012 18:31:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc2820/l/0Lsz0Bde0C10B1287371/story01.htm',
                    	'Oberstaatsanwalt Eimterb�umer: Ermittler mit Mission',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'10',
                    	'17 Feb 2012 18:24:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbf74d/l/0Lsz0Bde0C10B1287412/story01.htm',
                    	'Prinz Johan Friso in Lebensgefahr: Niederl�ndischer K�nigssohn von Lawine versch�ttet',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'11',
                    	'17 Feb 2012 18:11:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc1106/l/0Lsz0Bde0C10B1287328/story01.htm',
                    	'Schlecker: Wenn niemand mehr einkaufen kommt',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'12',
                    	'17 Feb 2012 18:00:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbc1108/l/0Lsz0Bde0C10B1287385/story01.htm',
                    	'Parteipolitisches Kalk�l bei der Pr�sidentenwahl: Spiel mit den Mehrheiten',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'13',
                    	'17 Feb 2012 17:52:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbefb4/l/0Lsz0Bde0C10B1286976/story01.htm',
                    	'Lernhilfe von Gleichaltrigen: T�fteln am Text',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'14',
                    	'17 Feb 2012 17:51:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbefb6/l/0Lsz0Bde0C10B1287326/story01.htm',
                    	'Lance Armstrongs Doping-Freispruch: Der Radler und der Fitness-Trainer',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'15',
                    	'17 Feb 2012 17:31:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbec1d/l/0Lsz0Bde0C10B128740A7/story01.htm',
                    	'Idee der CSU: Alpenverein soll nach Pulling',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'16',
                    	'17 Feb 2012 17:30:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbefb9/l/0Ljetzt0Bsueddeutsche0Bde0Ctexte0Canzeigen0C540A0A34/story01.htm',
                    	'M�dchen, tragt ihr eigentlich immer zusammenpassende Unterw�sche?',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'17',
                    	'17 Feb 2012 17:30:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbefb8/l/0Ljetzt0Bsueddeutsche0Bde0Ctexte0Canzeigen0C540A0A0A4/story01.htm',
                    	'Alte Heftchen, neues Gesicht',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'18',
                    	'17 Feb 2012 16:55:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbd580/l/0Lsz0Bde0C10B1287377/story01.htm',
                    	'China: Sex-Spielzeuge immer beliebter',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'19',
                    	'17 Feb 2012 16:54:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbaf0b/l/0Lsz0Bde0C10B1287327/story01.htm',
                    	'Insolvenz der Gro�b�ckerei: M�ller-Brot soll verkauft werden',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'20',
                    	'17 Feb 2012 16:45:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbaf0d/l/0Lsz0Bde0C10B1287322/story01.htm',
                    	'Hohe Kraftstoffpreise: Frust an der Zapfs�ule',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'21',
                    	'17 Feb 2012 16:45:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbaf0c/l/0Lsz0Bde0C10B1287369/story01.htm',
                    	'Twilight-Star mit ungewohntem Look: Pattinson mit Kahlkopf',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'22',
                    	'17 Feb 2012 16:41:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbbaf0e/l/0Lsz0Bde0C10B1287240A/story01.htm',
                    	'Filminvestor David Groenewold: Der Freund, der Wulff das Amt kostete',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'23',
                    	'17 Feb 2012 16:31:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbb6bad/l/0Lsz0Bde0C10B128730A9/story01.htm',
                    	'Vertrauliche Akten ver�ffentlicht: Die Geldquellen der Klimaskeptiker',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'24',
                    	'17 Feb 2012 16:25:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbb6bae/l/0Lsz0Bde0C10B1287134/story01.htm',
                    	'Bayerns Innenminister Herrmann: "Wir m�ssen den Rechtsextremismus ernster nehmen"',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'25',
                    	'17 Feb 2012 16:20:00',
                    	'http://rssfeed.sueddeutsche.de/c/795/f/447925/s/1cbb870c/l/0Lsz0Bde0C10B1286323/story01.htm',
                    	'Wahlkampf in Frankreich: Wie Sarkozy den Zauber zur�ckzwingen will',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'25'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>
