<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Sueddeutsche Online | Schlagzeilen - crossreading</title>
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
						
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("Sueddeutsche");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                            Newsletter &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="Wirtschaft" />
                        <br />
						<xsl:call-template name="Politik" />
                        <br />
						<xsl:call-template name="SportFussball" />
                        <br />
						<xsl:call-template name="Sport" />
                        <br />
						<xsl:call-template name="Sonstige" />
                        <br />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
                
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="Wirtschaft">
		<strong>&gt; Wirtschaft</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cwirtschaft'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaft'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(title, 'Schulden')
										or contains(title, 'schulden')
										or contains(title, 'Schuldenkrise')
										or contains(title, 'Vertrag')
										or contains(title, 'Vertr�ge')
										or contains(title, 'Insolvenz')
										or contains(title, 'Manager')
										or contains(title, 'Gl�ubiger')
										or contains(title, 'zinsen')
										or contains(title, 'Kredit')
										or contains(title, 'Bonit�t')
										or contains(title, 'Inflation')
										or contains(title, 'Fluggesellschaft')
										or contains(title, 'Pension')
										or contains(title, 'Rating')
										or contains(title, 'Anleihe')
										or contains(title, 'M�rkte')
										or contains(title, 'Gesch�ft')
										or contains(title, 'Wirtschaft')
										or contains(title, 'Finanzsystem')
										or contains(title, 'Dax')
										or contains(title, 'Handelsbeginn')
										or contains(title, 'Aufsichtsrat')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(title, 'Schulden')
										or contains(title, 'schulden')
										or contains(title, 'Schuldenkrise')
										or contains(title, 'Vertrag')
										or contains(title, 'Vertr�ge')
										or contains(title, 'Insolvenz')
										or contains(title, 'Manager')
										or contains(title, 'Gl�ubiger')
										or contains(title, 'zinsen')
										or contains(title, 'Kredit')
										or contains(title, 'Bonit�t')
										or contains(title, 'Inflation')
										or contains(title, 'Fluggesellschaft')
										or contains(title, 'Pension')
										or contains(title, 'Rating')
										or contains(title, 'Anleihe')
										or contains(title, 'M�rkte')
										or contains(title, 'Gesch�ft')
										or contains(title, 'Wirtschaft')
										or contains(title, 'Finanzsystem')
										or contains(title, 'Dax')
										or contains(title, 'Handelsbeginn')
										or contains(title, 'Aufsichtsrat')
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Politik">
		<strong>&gt; Politik</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Cpolitik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(title, 'Bundespr�sident')
										or contains(title, 'Parteimitglied')
										or contains(title, 'parteien-Koalition')
										or contains(title, 'Politisch')
										or contains(title, 'Atomstreit')
										or contains(title, 'Anschlag in')
										or contains(title, 'Isaf')
										or contains(title, 'Soldaten')
										or contains(title, 'Minister')
										or contains(title, 'Spanien')
										or contains(title, 'Politik')
										or contains(title, 'anschlag')
										or contains(title, 'CSU')
										or contains(title, 'Gro�britannien')
										or contains(title, 'Syrien')
										or contains(title, 'Parteichef')
										or contains(title, 'Wahlkampf')
										or contains(title, 'Gericht')
										or contains(title, 'EU-')
										or contains(title, 'US-Republikaner')
										or contains(title, 'Pr�sidentschaftswahl')
										or contains(title, 'Wahlf�lschung')
										or contains(title, 'Koalition')
										or contains(title, 'Wahlerfolg')
										or (
											contains(title, 'Russland')
											and contains(title, 'Putin')
										)
										or contains(title, 'Wahlsieg')
										or contains(title, 'minister')
										or contains(title, 'Atomkonflikt')
										or contains(title, 'Regierung')
										or (
											contains(title, 'Annan')
											and contains(title, 'Gespr�che')
										)
										or contains(title, 'politik')
										or contains(title, 'Pr�ventivangriff')
										or contains(title, 'Kriegsgefahr')
										or contains(title, 'B�rgermeisterwahl')
										or contains(title, 'Kommunalwahl')
										or (
											contains(title, 'Afghanistan')
											and contains(title, 'US-Soldat')
										)
										or contains(title, 'gegen Atomkraft')
										or contains(title, 'CDU-Chef')
										or contains(title, 'Iran-Israel')
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(title, 'Bundespr�sident')
										or contains(title, 'Parteimitglied')
										or contains(title, 'parteien-Koalition')
										or contains(title, 'Politisch')
										or contains(title, 'Atomstreit')
										or contains(title, 'Anschlag in')
										or contains(title, 'Isaf')
										or contains(title, 'Soldaten')
										or contains(title, 'Minister')
										or contains(title, 'Spanien')
										or contains(title, 'Politik')
										or contains(title, 'anschlag')
										or contains(title, 'CSU')
										or contains(title, 'Gro�britannien')
										or contains(title, 'Syrien')
										or contains(title, 'Parteichef')
										or contains(title, 'Wahlkampf')
										or contains(title, 'Gericht')
										or contains(title, 'EU-')
										or contains(title, 'US-Republikaner')
										or contains(title, 'Pr�sidentschaftswahl')
										or contains(title, 'Wahlf�lschung')
										or contains(title, 'Koalition')
										or contains(title, 'Wahlerfolg')
										or (
											contains(title, 'Russland')
											and contains(title, 'Putin')
										)
										or contains(title, 'Wahlsieg')
										or contains(title, 'minister')
										or contains(title, 'Atomkonflikt')
										or contains(title, 'Regierung')
										or (
											contains(title, 'Annan')
											and contains(title, 'Gespr�che')
										)
										or contains(title, 'politik')
										or contains(title, 'Pr�ventivangriff')
										or contains(title, 'Kriegsgefahr')
										or contains(title, 'B�rgermeisterwahl')
										or contains(title, 'Kommunalwahl')
										or (
											contains(title, 'Afghanistan')
											and contains(title, 'US-Soldat')
										)
										or contains(title, 'gegen Atomkraft')
										or contains(title, 'CDU-Chef')
										or contains(title, 'Iran-Israel')
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
        
	<xsl:template name="SportFussball">
		<strong>&gt; Sport - Fussball</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Csport'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sportFussball'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(title, 'Bundesliga')
									or contains(title, 'Derby')
									or contains(title, 'DFB')
									or contains(title, 'Fu�ball')
									or contains(title, 'EM 2012')
									or contains(title, 'VfB Stuttgart')
									or contains(title, 'FC Augsburg')
									or contains(title, 'BSC Berlin')
									or contains(title, 'Arsenal')
									or contains(title, 'FC Chelsea')
									or contains(title, '1860 M�nchen')
									or contains(title, 'FC St. Pauli')
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									contains(title, 'Bundesliga')
									or contains(title, 'Derby')
									or contains(title, 'DFB')
									or contains(title, 'Fu�ball')
									or contains(title, 'EM 2012')
									or contains(title, 'VfB Stuttgart')
									or contains(title, 'FC Augsburg')
									or contains(title, 'BSC Berlin')
									or contains(title, 'Arsenal')
									or contains(title, 'FC Chelsea')
									or contains(title, '1860 M�nchen')
									or contains(title, 'FC St. Pauli')
								])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sport">
		<strong>&gt; Sport</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'0Csport'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									(
										contains(title, 'Bundesliga')
										or contains(title, 'Derby')
										or contains(title, 'DFB')
										or contains(title, 'Fu�ball')
										or contains(title, 'EM 2012')
										or contains(title, 'VfB Stuttgart')
										or contains(title, 'FC Augsburg')
										or contains(title, 'BSC Berlin')
										or contains(title, 'Arsenal')
										or contains(title, 'FC Chelsea')
										or contains(title, '1860 M�nchen')
										or contains(title, 'FC St. Pauli')
									)=false
									and (
										contains(title, 'Pole-Rekord')
										or contains(title, 'Sport')
										or contains(title, 'Nationalmannschaft')
										or contains(title, 'Nationalspieler')
										or contains(title, 'Biathlon')
										or contains(title, 'Biathlet')
										or contains(title, 'Rennen der M�nner')
										or contains(title, 'Leichtathlet')
										or contains(title, 'WM-Massenstart')
										or contains(title, 'Olympia')
										or contains(title, 'Tennis')
									)
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
									(
										contains(title, 'Bundesliga')
										or contains(title, 'Derby')
										or contains(title, 'DFB')
										or contains(title, 'Fu�ball')
										or contains(title, 'EM 2012')
										or contains(title, 'VfB Stuttgart')
										or contains(title, 'FC Augsburg')
										or contains(title, 'BSC Berlin')
										or contains(title, 'Arsenal')
										or contains(title, 'FC Chelsea')
										or contains(title, '1860 M�nchen')
										or contains(title, 'FC St. Pauli')
									)=false
									and (
										contains(title, 'Pole-Rekord')
										or contains(title, 'Sport')
										or contains(title, 'Nationalmannschaft')
										or contains(title, 'Nationalspieler')
										or contains(title, 'Biathlon')
										or contains(title, 'Biathlet')
										or contains(title, 'Rennen der M�nner')
										or contains(title, 'Leichtathlet')
										or contains(title, 'WM-Massenstart')
										or contains(title, 'Olympia')
										or contains(title, 'Tennis')
									)
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										(
											contains(title, 'Schulden')
											or contains(title, 'schulden')
											or contains(title, 'Schuldenkrise')
											or contains(title, 'Vertrag')
											or contains(title, 'Vertr�ge')
											or contains(title, 'Insolvenz')
											or contains(title, 'Manager')
											or contains(title, 'Gl�ubiger')
											or contains(title, 'zinsen')
											or contains(title, 'Kredit')
											or contains(title, 'Bonit�t')
											or contains(title, 'Inflation')
											or contains(title, 'Fluggesellschaft')
											or contains(title, 'Pension')
											or contains(title, 'Rating')
											or contains(title, 'Anleihe')
											or contains(title, 'M�rkte')
											or contains(title, 'Gesch�ft')
											or contains(title, 'Wirtschaft')
											or contains(title, 'Finanzsystem')
											or contains(title, 'Dax')
											or contains(title, 'Handelsbeginn')
											or contains(title, 'Aufsichtsrat')
										)=false
	            						and (
											contains(title, 'Bundespr�sident')
											or contains(title, 'Parteimitglied')
											or contains(title, 'parteien-Koalition')
											or contains(title, 'Politisch')
											or contains(title, 'Atomstreit')
											or contains(title, 'Anschlag in')
											or contains(title, 'Isaf')
											or contains(title, 'Soldaten')
											or contains(title, 'Minister')
											or contains(title, 'Spanien')
											or contains(title, 'Politik')
											or contains(title, 'anschlag')
											or contains(title, 'CSU')
											or contains(title, 'Gro�britannien')
											or contains(title, 'Syrien')
											or contains(title, 'Parteichef')
											or contains(title, 'Wahlkampf')
											or contains(title, 'Gericht')
											or contains(title, 'EU-')
											or contains(title, 'US-Republikaner')
											or contains(title, 'Pr�sidentschaftswahl')
											or contains(title, 'Wahlf�lschung')
											or contains(title, 'Koalition')
											or contains(title, 'Wahlerfolg')
											or (
												contains(title, 'Russland')
												and contains(title, 'Putin')
											)
											or contains(title, 'Wahlsieg')
											or contains(title, 'minister')
											or contains(title, 'Atomkonflikt')
											or contains(title, 'Regierung')
											or (
												contains(title, 'Annan')
												and contains(title, 'Gespr�che')
											)
											or contains(title, 'politik')
											or contains(title, 'Pr�ventivangriff')
											or contains(title, 'Kriegsgefahr')
											or contains(title, 'B�rgermeisterwahl')
											or contains(title, 'Kommunalwahl')
											or (
												contains(title, 'Afghanistan')
												and contains(title, 'US-Soldat')
											)
											or contains(title, 'gegen Atomkraft')
											or contains(title, 'CDU-Chef')
											or contains(title, 'Iran-Israel')
	            						)=false
	                                    and (
											contains(title, 'Bundesliga')
											or contains(title, 'Derby')
											or contains(title, 'DFB')
											or contains(title, 'Fu�ball')
											or contains(title, 'EM 2012')
											or contains(title, 'VfB Stuttgart')
											or contains(title, 'FC Augsburg')
											or contains(title, 'BSC Berlin')
											or contains(title, 'Arsenal')
											or contains(title, 'FC Chelsea')
											or contains(title, '1860 M�nchen')
											or contains(title, 'FC St. Pauli')
											or contains(title, 'Sport')
											or contains(title, 'Nationalmannschaft')
											or contains(title, 'Nationalspieler')
											or contains(title, 'Biathlon')
											or contains(title, 'Biathlet')
											or contains(title, 'Rennen der M�nner')
											or contains(title, 'Leichtathlet')
											or contains(title, 'WM-Massenstart')
											or contains(title, 'Olympia')
											or contains(title, 'Tennis')
	                                    )=false
                                    ]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	''
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
        	
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										(
											contains(title, 'Schulden')
											or contains(title, 'schulden')
											or contains(title, 'Schuldenkrise')
											or contains(title, 'Vertrag')
											or contains(title, 'Vertr�ge')
											or contains(title, 'Insolvenz')
											or contains(title, 'Manager')
											or contains(title, 'Gl�ubiger')
											or contains(title, 'zinsen')
											or contains(title, 'Kredit')
											or contains(title, 'Bonit�t')
											or contains(title, 'Inflation')
											or contains(title, 'Fluggesellschaft')
											or contains(title, 'Pension')
											or contains(title, 'Rating')
											or contains(title, 'Anleihe')
											or contains(title, 'M�rkte')
											or contains(title, 'Gesch�ft')
											or contains(title, 'Wirtschaft')
											or contains(title, 'Finanzsystem')
											or contains(title, 'Dax')
											or contains(title, 'Handelsbeginn')
											or contains(title, 'Aufsichtsrat')
										)=false
	            						and (
											contains(title, 'Bundespr�sident')
											or contains(title, 'Parteimitglied')
											or contains(title, 'parteien-Koalition')
											or contains(title, 'Politisch')
											or contains(title, 'Atomstreit')
											or contains(title, 'Anschlag in')
											or contains(title, 'Isaf')
											or contains(title, 'Soldaten')
											or contains(title, 'Minister')
											or contains(title, 'Spanien')
											or contains(title, 'Politik')
											or contains(title, 'anschlag')
											or contains(title, 'CSU')
											or contains(title, 'Gro�britannien')
											or contains(title, 'Syrien')
											or contains(title, 'Parteichef')
											or contains(title, 'Wahlkampf')
											or contains(title, 'Gericht')
											or contains(title, 'EU-')
											or contains(title, 'US-Republikaner')
											or contains(title, 'Pr�sidentschaftswahl')
											or contains(title, 'Wahlf�lschung')
											or contains(title, 'Koalition')
											or contains(title, 'Wahlerfolg')
											or (
												contains(title, 'Russland')
												and contains(title, 'Putin')
											)
											or contains(title, 'Wahlsieg')
											or contains(title, 'minister')
											or contains(title, 'Atomkonflikt')
											or contains(title, 'Regierung')
											or (
												contains(title, 'Annan')
												and contains(title, 'Gespr�che')
											)
											or contains(title, 'politik')
											or contains(title, 'Pr�ventivangriff')
											or contains(title, 'Kriegsgefahr')
											or contains(title, 'B�rgermeisterwahl')
											or contains(title, 'Kommunalwahl')
											or (
												contains(title, 'Afghanistan')
												and contains(title, 'US-Soldat')
											)
											or contains(title, 'gegen Atomkraft')
											or contains(title, 'CDU-Chef')
											or contains(title, 'Iran-Israel')
	            						)=false
	                                    and (
											contains(title, 'Bundesliga')
											or contains(title, 'Derby')
											or contains(title, 'DFB')
											or contains(title, 'Fu�ball')
											or contains(title, 'EM 2012')
											or contains(title, 'VfB Stuttgart')
											or contains(title, 'FC Augsburg')
											or contains(title, 'BSC Berlin')
											or contains(title, 'Arsenal')
											or contains(title, 'FC Chelsea')
											or contains(title, '1860 M�nchen')
											or contains(title, 'FC St. Pauli')
											or contains(title, 'Sport')
											or contains(title, 'Nationalmannschaft')
											or contains(title, 'Nationalspieler')
											or contains(title, 'Biathlon')
											or contains(title, 'Biathlet')
											or contains(title, 'Rennen der M�nner')
											or contains(title, 'Leichtathlet')
											or contains(title, 'WM-Massenstart')
											or contains(title, 'Olympia')
											or contains(title, 'Tennis')
	                                    )=false
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
