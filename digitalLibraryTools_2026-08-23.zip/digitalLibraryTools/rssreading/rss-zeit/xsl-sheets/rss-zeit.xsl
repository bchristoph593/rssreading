<?xml version="1.0" encoding="ISO-8859-1" ?>
<!-- DWXMLSource="http://www.spiegel.de/schlagzeilen/index.rss" -->
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
	<!-- <!ENTITY apos   "&#039;"> -->
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" 
	  encoding="UTF-8" 
	  doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" 
	  doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"
	/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
				
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
				
                                
                <title>ZEIT Online | Schlagzeilen - rssreading</title>
                <link rel="shortcut icon" href="../images/favicon/fav-zeit.ico" />
                <link href="../css/style.css" rel="stylesheet" type="text/css" />                
			</head>
            
<!--			
			<body onload="lookupArticleLinkAmount(); ">
-->
			<body>
			<!--
                <script type="text/javascript" src="../js/jquery-latest.min.js">
				</script>
			-->
			
                <script type="text/javascript" src="../js/unfold.js"></script>
                <script type="text/javascript" src="../js/visitLink.js"></script>
                <script type="text/javascript" src="../js/wndLocalStorage.js"></script>
        
		<script type="text/javascript">
		  <![CDATA[
          ]]>
        </script>
		
				<xsl:processing-instruction name="php">
					include("../uc/header_imports_02.php");
				?</xsl:processing-instruction>
				
				<xsl:processing-instruction name="php">
					include("../uc/articleItem.php");
				?</xsl:processing-instruction>
				
				<xsl:processing-instruction name="php">
					include("../uc/articleLink.php");
				?</xsl:processing-instruction>
				
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("Zeit");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
						<xsl:variable name="linkCounter_all">
							<xsl:value-of select="count(item)"/>
						</xsl:variable>
			
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="../rss-zeit/">
							  &gt; Alle Nachrichten (<xsl:processing-instruction name="php">
								  echo '<xsl:value-of select="$linkCounter_all" />';
								?</xsl:processing-instruction>)</a>
<!--
                            <br />
							<a href="index-wirtschaft.php">&gt; Wirtschaft</a>
							<a href="index-politik.php">&gt; Politik</a>
							<a href="index-netzwelt.php">&gt; Netzwelt</a>
							<a href="index-kultur.php">&gt; Kultur</a>
							<a href="index-sport.php">&gt; Sport</a>
							<a href="index-wissenschaft.php">&gt; Wissenschaft</a>
-->
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <!-- <br /> -->
                        <hr />
                        
						<xsl:call-template name="Wirtschaft" />
                        <!-- <br /> -->
						<xsl:call-template name="Politik" />
                        <!-- <br /> -->
						<xsl:call-template name="Sport" />
                        <!-- <br /> -->
						<xsl:call-template name="Sonstige" />
                        <!-- <br /> -->
						
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
				
				<div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div>
				
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="string-replace-all">
		<xsl:param name="text" />
		<xsl:param name="replace" />
		<xsl:param name="by" />
		<xsl:choose>
			<xsl:when test="$text = '' or $replace = ''or not($replace)" >
				<!-- Prevent this routine from hanging -->
				<xsl:value-of select="$text" />
			</xsl:when>
			<xsl:when test="contains($text, $replace)">
				<xsl:value-of select="substring-before($text,$replace)" />
				<xsl:value-of select="$by" />
				<xsl:call-template name="string-replace-all">
					<xsl:with-param name="text" select="substring-after($text,$replace)" />
					<xsl:with-param name="replace" select="$replace" />
					<xsl:with-param name="by" select="$by" />
				</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$text" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	
	<xsl:template name="Wirtschaft">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wirtschaft'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaft'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_wirtschaft">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
		
		<strong>&gt; Wirtschaft (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_wirtschaft" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Politik">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_politik">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
											contains(title, 'Justizsenator')
										)
									])"/>
			</xsl:variable>
			
		<strong>&gt; Politik (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_politik" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										or (
											contains(title, 'Justizsenator')
										)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
											contains(title, 'Justizsenator')
										)
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sport">
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/sport'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_sport">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
										contains(title, 'Fu�ball-Nationalmannschaft')
										or contains(title, 'Basketball-Bundesliga')
										or contains(title, 'DFB-Pokal')
										or contains(title, 'Handball-Bundesliga')
										or contains(title, 'Gewalt im Stadion:')
										or contains(title, '3. Liga:')
										or contains(title, 'Fu�ball:')
										or contains(title, 'French-Open-Finale:')
										or contains(title, '2. Fu�ball-Bundesliga:')
										or contains(title, '2. Bundesliga:')
										or contains(title, 'Bundesliga-Transfers:')
										or contains(title, 'Fu�ball-Bundesliga:')
										or contains(title, 'Fu�ball-WM')
										or contains(title, 'Fu�ball in Spanien:')
										or contains(title, 'DEL:')
										or contains(title, 'Handball:')
										or contains(title, 'Basketball:')
										or contains(title, 'Regionalliga:')
										or contains(title, 'Basketball-Meister')
										or contains(title, 'Bundesliga:')
										or contains(title, 'Tennis:')
										or contains(title, 'Formel-1')
										or contains(title, 'WM-Gold')
										or contains(title, 'Zweite Liga:')
										or contains(title, 'Schwimmen:')
										or contains(title, 'Leichtathletik:')
										or contains(title, 'Schwimm-EM:')
										or contains(title, 'NBA:')
										or contains(title, 'Bundestrainer')
										or contains(title, 'Turn-EM')
										or contains(title, 'WM-Mehrkampf')
										or contains(title, 'Pflichtspiel-Generalprobe')
									    )
									])
								"/>
			</xsl:variable>
		
		<strong>&gt; Sport (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_sport" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									or (
										contains(title, 'Fu�ball-Nationalmannschaft')
										or contains(title, 'Basketball-Bundesliga')
										or contains(title, 'DFB-Pokal')
										or contains(title, 'Handball-Bundesliga')
										or contains(title, 'Gewalt im Stadion:')
										or contains(title, '3. Liga:')
										or contains(title, 'Fu�ball:')
										or contains(title, 'French-Open-Finale:')
										or contains(title, '2. Fu�ball-Bundesliga:')
										or contains(title, '2. Bundesliga:')
										or contains(title, 'Bundesliga-Transfers:')
										or contains(title, 'Fu�ball-Bundesliga:')
										or contains(title, 'Fu�ball-WM')
										or contains(title, 'Fu�ball in Spanien:')
										or contains(title, 'DEL:')
										or contains(title, 'Handball:')
										or contains(title, 'Basketball:')
										or contains(title, 'Regionalliga:')
										or contains(title, 'Basketball-Meister')
										or contains(title, 'Bundesliga:')
										or contains(title, 'Tennis:')
										or contains(title, 'Formel-1')
										or contains(title, 'WM-Gold')
										or contains(title, 'Zweite Liga:')
										or contains(title, 'Schwimmen:')
										or contains(title, 'Leichtathletik:')
										or contains(title, 'Schwimm-EM:')
										or contains(title, 'NBA:')
										or contains(title, 'Bundestrainer')
										or contains(title, 'Turn-EM')
										or contains(title, 'WM-Mehrkampf')
										or contains(title, 'Pflichtspiel-Generalprobe')
									)
								  ]">
				
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										or (
										contains(title, 'Fu�ball-Nationalmannschaft')
										or contains(title, 'Basketball-Bundesliga')
										or contains(title, 'DFB-Pokal')
										or contains(title, 'Handball-Bundesliga')
										or contains(title, 'Gewalt im Stadion:')
										or contains(title, '3. Liga:')
										or contains(title, 'Fu�ball:')
										or contains(title, 'French-Open-Finale:')
										or contains(title, '2. Fu�ball-Bundesliga:')
										or contains(title, '2. Bundesliga:')
										or contains(title, 'Bundesliga-Transfers:')
										or contains(title, 'Fu�ball-Bundesliga:')
										or contains(title, 'Fu�ball-WM')
										or contains(title, 'Fu�ball in Spanien:')
										or contains(title, 'DEL:')
										or contains(title, 'Handball:')
										or contains(title, 'Basketball:')
										or contains(title, 'Regionalliga:')
										or contains(title, 'Basketball-Meister')
										or contains(title, 'Bundesliga:')
										or contains(title, 'Tennis:')
										or contains(title, 'Formel-1')
										or contains(title, 'WM-Gold')
										or contains(title, 'Zweite Liga:')
										or contains(title, 'Schwimmen:')
										or contains(title, 'Leichtathletik:')
										or contains(title, 'Schwimm-EM:')
										or contains(title, 'NBA:')
										or contains(title, 'Bundestrainer')
										or contains(title, 'Turn-EM')
										or contains(title, 'WM-Mehrkampf')
										or contains(title, 'Pflichtspiel-Generalprobe')
									    )
									])
								"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sonstige">
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
		
			<xsl:variable name="linkCounter_sonstige">
				<xsl:value-of select="count(item[
            						contains(link, '/wirtschaft')=false
                                    and contains(link, '/politik')=false
									and (
										contains(title, 'Justizsenator')
									)=false
                                    and contains(link, '/sport')=false
									and contains(title, 'Fu�ball-Nationalmannschaft')=false
									and contains(title, 'Basketball-Bundesliga')=false
									and contains(title, 'DFB-Pokal')=false
									and contains(title, 'Handball-Bundesliga')=false
									and contains(title, 'Gewalt im Stadion:')=false
									and contains(title, '3. Liga:')=false
									and contains(title, 'Fu�ball:')=false
									and contains(title, 'French-Open-Finale:')=false
									and contains(title, '2. Fu�ball-Bundesliga:')=false
									and contains(title, '2. Bundesliga:')=false
									and contains(title, 'Bundesliga-Transfers:')=false
									and contains(title, 'Fu�ball-Bundesliga:')=false
									and contains(title, 'Fu�ball-WM')=false
									and contains(title, 'Fu�ball in Spanien:')=false
									and contains(title, 'DEL:')=false
									and contains(title, 'Handball:')=false
									and contains(title, 'Basketball:')=false
									and contains(title, 'Regionalliga:')=false
									and contains(title, 'Basketball-Meister')=false
									and contains(title, 'Bundesliga:')=false
									and contains(title, 'Tennis:')=false
									and contains(title, 'Formel-1')=false
									and contains(title, 'WM-Gold')=false
									and contains(title, 'Zweite Liga:')=false
									and contains(title, 'Schwimmen:')=false
									and contains(title, 'Leichtathletik:')=false
									and contains(title, 'Schwimm-EM:')=false
									and contains(title, 'NBA:')=false
									and contains(title, 'Bundestrainer')=false
									and contains(title, 'Turn-EM')=false
									and contains(title, 'WM-Mehrkampf')=false
									and contains(title, 'Pflichtspiel-Generalprobe')=false
                                    ]
									)"/>
			</xsl:variable>

		<strong>&gt; Sonstige (<xsl:processing-instruction name="php">
		  echo '<xsl:value-of select="$linkCounter_sonstige" />';
		?</xsl:processing-instruction>)
		</strong>
		
		<div class="divLinkSection">
			<xsl:for-each select="item[
            						contains(link, '/wirtschaft')=false
                                    and contains(link, '/politik')=false
									and (
										contains(title, 'Justizsenator')
									)=false
                                    and contains(link, '/sport')=false
									and contains(title, 'Fu�ball-Nationalmannschaft')=false
									and contains(title, 'Basketball-Bundesliga')=false
									and contains(title, 'DFB-Pokal')=false
									and contains(title, 'Handball-Bundesliga')=false
									and contains(title, 'Gewalt im Stadion:')=false
									and contains(title, '3. Liga:')=false
									and contains(title, 'Fu�ball:')=false
									and contains(title, 'French-Open-Finale:')=false
									and contains(title, '2. Fu�ball-Bundesliga:')=false
									and contains(title, '2. Bundesliga:')=false
									and contains(title, 'Bundesliga-Transfers:')=false
									and contains(title, 'Fu�ball-Bundesliga:')=false
									and contains(title, 'Fu�ball-WM')=false
									and contains(title, 'Fu�ball in Spanien:')=false
									and contains(title, 'DEL:')=false
									and contains(title, 'Handball:')=false
									and contains(title, 'Basketball:')=false
									and contains(title, 'Regionalliga:')=false
									and contains(title, 'Basketball-Meister')=false
									and contains(title, 'Bundesliga:')=false
									and contains(title, 'Tennis:')=false
									and contains(title, 'Formel-1')=false
									and contains(title, 'WM-Gold')=false
									and contains(title, 'Zweite Liga:')=false
									and contains(title, 'Schwimmen:')=false
									and contains(title, 'Leichtathletik:')=false
									and contains(title, 'Schwimm-EM:')=false
									and contains(title, 'NBA:')=false
									and contains(title, 'Bundestrainer')=false
									and contains(title, 'Turn-EM')=false
									and contains(title, 'WM-Mehrkampf')=false
									and contains(title, 'Pflichtspiel-Generalprobe')=false
                                    ]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
            						contains(link, '/wirtschaft')=false
                                    and contains(link, '/politik')=false
									and (
										contains(title, 'Justizsenator')
									)=false
                                    and contains(link, '/sport')=false
									and contains(title, 'Fu�ball-Nationalmannschaft')=false
									and contains(title, 'Basketball-Bundesliga')=false
									and contains(title, 'DFB-Pokal')=false
									and contains(title, 'Handball-Bundesliga')=false
									and contains(title, 'Gewalt im Stadion:')=false
									and contains(title, '3. Liga:')=false
									and contains(title, 'Fu�ball:')=false
									and contains(title, 'French-Open-Finale:')=false
									and contains(title, '2. Fu�ball-Bundesliga:')=false
									and contains(title, '2. Bundesliga:')=false
									and contains(title, 'Bundesliga-Transfers:')=false
									and contains(title, 'Fu�ball-Bundesliga:')=false
									and contains(title, 'Fu�ball-WM')=false
									and contains(title, 'Fu�ball in Spanien:')=false
									and contains(title, 'DEL:')=false
									and contains(title, 'Handball:')=false
									and contains(title, 'Basketball:')=false
									and contains(title, 'Regionalliga:')=false
									and contains(title, 'Basketball-Meister')=false
									and contains(title, 'Bundesliga:')=false
									and contains(title, 'Tennis:')=false
									and contains(title, 'Formel-1')=false
									and contains(title, 'WM-Gold')=false
									and contains(title, 'Zweite Liga:')=false
									and contains(title, 'Schwimmen:')=false
									and contains(title, 'Leichtathletik:')=false
									and contains(title, 'Schwimm-EM:')=false
									and contains(title, 'NBA:')=false
									and contains(title, 'Bundestrainer')=false
									and contains(title, 'Turn-EM')=false
									and contains(title, 'WM-Mehrkampf')=false
									and contains(title, 'Pflichtspiel-Generalprobe')=false
                                    ]
									)"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
