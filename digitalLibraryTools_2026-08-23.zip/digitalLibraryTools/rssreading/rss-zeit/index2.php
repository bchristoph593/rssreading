<?php
	include("../uc/header_imports.php");
	
   	$xslDoc = new DOMDocument();
   	$xslDoc->load("xsl-sheets/rss-zeit.xsl");
	
	$section = "schlagzeilen";
	
	$url_newsengine = "http://newsengine.v232681353.yourvserver.net/rss-news"; 
	$url = $url_newsengine . "/zeit/".$section."/index.rss";
	
   	$xmlDoc = new DOMDocument();
   	@$xmlDoc->load( $url );
	 
   	$proc = new XSLTProcessor();
	@$proc->importStylesheet($xslDoc);
   
   	@$htmlDocument = $proc->transformToXML($xmlDoc);
	
	// Here: Escape "'" - Character inside $htmlDocument
	$htmlDocument = ereg_replace("'er", "&acute;er", $htmlDocument);
		
	$fh1 = fopen("temp.php", "w");
	
	fwrite($fh1, $htmlDocument);
	fclose($fh1);
	
	@include("temp.php");
	
?>
