<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

  <html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta><meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>ZEIT Online | Schlagzeilen - rssreading</title><link rel="shortcut icon" href="../images/favicon/fav-zeit.ico"></link><link href="../css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="../js/unfold.js"></script><script type="text/javascript" src="../js/visitLink.js"></script><script type="text/javascript" src="../js/wndLocalStorage.js"></script><script type="text/javascript">
          </script><?php 
					include("../uc/header_imports_02.php");
				?><?php 
					include("../uc/articleItem.php");
				?><?php 
					include("../uc/articleLink.php");
				?><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("Zeit");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="../rss-zeit/">
							  &gt; Alle Nachrichten (<?php 
								  echo '15';
								?>)</a></div></div><div class="divContent"><strong style="margin:3px;">
                          &gt; <a href="http://localhost/digitalLibraryTools/rssreading/">Newsletter</a> &gt; DIE ZEIT | Nachrichten, News, Hintergründe und Debatten</strong><hr></hr><strong xmlns="">&gt; Wirtschaft (<?php 
		  echo '0';
		?>)
		</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Politik (<?php 
		  echo '1';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'politik',
                    	'1',
                    	'23 Aug 2026 08:28:00',
                    	'https://www.zeit.de/politik/ausland/2026-08/madschid-adineh-iran-hinrichtung-proteste-albors',
                    	'Todesstrafe im Iran: Erneut Mann im Iran hingerichtet wegen Teilnahme an Massenprotesten',
                    	'Im Iran wurde erneut ein Mann hingerichtet, weil er an regierungskritischen Protesten teilgenommen hatte. Die Justiz warf ihm zudem Unterstützung Israels und der USA vor.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'politik',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sport (<?php 
		  echo '1';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sport',
                    	'1',
                    	'23 Aug 2026 08:30:15',
                    	'https://www.zeit.de/news/2026-08/23/torwart-debatte-2-0-wer-wird-mart-nez-nummer-eins',
                    	'DFB-Pokal: Torwart-Debatte 2.0: Wer wird Martínez' Nummer eins?',
                    	''
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<strong xmlns="">&gt; Sonstige (<?php 
		  echo '13';
		?>)
		</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'23 Aug 2026 08:32:59',
                    	'https://www.zeit.de/wissenschaft/umwelt/2026-08/fischsterben-gleiwitzer-kanal-oder-goldalge-polen',
                    	'Fischsterben: Polen kämpft gegen Ausbreitung der giftigen Goldalge',
                    	'Erneut sterben in polnischen Gewässern Fische, und wieder ist eine Alge schuld: Polnische Behörden gehen in einem Nebengewässer der Oder gegen die Goldalge vor.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'23 Aug 2026 08:30:49',
                    	'https://www.zeit.de/news/2026-08/23/vw-chef-beschwoert-zusammenhalt-alle-muessen-mitziehen',
                    	'Vor Betriebsversammlungen: VW-Chef beschwört Zusammenhalt: «Alle müssen mitziehen»',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'23 Aug 2026 08:29:02',
                    	'https://www.zeit.de/news/2026-08/23/mann-faehrt-ueber-gehweg-an-bus-vorbei-und-verletzt-anwohner',
                    	'Verkehr: Mann fährt über Gehweg an Bus vorbei und verletzt Anwohner',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'23 Aug 2026 08:28:55',
                    	'https://www.zeit.de/news/2026-08/23/magdeburger-cdu-abgeordneter-offen-fuer-gespraeche-mit-linken',
                    	'Landtagswahl Sachsen-Anhalt: Magdeburger CDU-Abgeordneter offen für Gespräche mit Linken',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'23 Aug 2026 08:28:51',
                    	'https://www.zeit.de/news/2026-08/23/kein-platz-im-auto-junger-mann-faehrt-auf-dem-dach-mit',
                    	'Polizeieinsatz: Kein Platz im Auto? Junger Mann fährt auf dem Dach mit',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'6',
                    	'23 Aug 2026 08:24:07',
                    	'https://www.zeit.de/news/2026-08/23/merz-in-waldbrandgebiet-das-ist-klimawandel',
                    	'Nach Waldbrand: Merz in Waldbrandgebiet: «Das ist Klimawandel»',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'7',
                    	'23 Aug 2026 08:23:19',
                    	'https://www.zeit.de/news/2026-08/23/fahrer-nach-crash-schwer-verletzt-aus-auto-geschnitten',
                    	'Unfälle: Fahrer nach Crash schwer verletzt aus Auto geschnitten',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'8',
                    	'23 Aug 2026 08:20:42',
                    	'https://www.zeit.de/news/2026-08/23/krawalle-beim-suedwest-derby-clubs-suchen-nach-antworten',
                    	'Ausschreitungen in Mannheim: Krawalle beim Südwest-Derby: Clubs suchen nach Antworten',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'9',
                    	'23 Aug 2026 08:09:22',
                    	'https://www.zeit.de/digital/internet/2026-08/alibaba-kapitalerhoehung-hongkong-aktienemission-ki',
                    	'Chinesischer Techkonzern: Alibaba kündigt milliardenschwere KI-Offensive an',
                    	'Der chinesische Techkonzern Alibaba will in künstliche Intelligenz investieren. Um das zu finanzieren, will das Unternehmen neue Aktien ausgeben – in Milliardenhöhe.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'10',
                    	'23 Aug 2026 07:47:27',
                    	'https://www.zeit.de/2026/36/in-die-schweiz-emma-cline-roman-assistierter-suizid-psyche',
                    	'»In die Schweiz« von Emma Cline: Mit kalter Klinge',
                    	'Die US-amerikanische Schriftstellerin Emma Cline schreibt gnadenlose Literatur. Ihr Roman »In die Schweiz« ist eine Reise ans Ende des Bewusstseins.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'11',
                    	'23 Aug 2026 07:47:27',
                    	'https://www.zeit.de/2026/36/in-die-schweiz-emma-cline-roman-assistierter-suizid-psyche',
                    	'»In die Schweiz« von Emma Cline: Mit kalter Klinge',
                    	'Die US-amerikanische Schriftstellerin Emma Cline schreibt gnadenlose Literatur. Ihr Roman »In die Schweiz« ist eine Reise ans Ende des Bewusstseins.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'12',
                    	'23 Aug 2026 07:46:51',
                    	'https://www.zeit.de/zeit-magazin/wochenmarkt/2026-08/tomate-gemuese-pflanze-entwicklung-kueche',
                    	'Tomate: Eine Liebeserklärung an das runde Wunder',
                    	'Die Tomate kann erbsenklein sein und kegelkugeldick und farbig wie ein Monet. Und sie wird ständig weiterentwickelt. Auch damit sie die zunehmende Hitze übersteht.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'13',
                    	'23 Aug 2026 07:44:25',
                    	'https://www.zeit.de/2026/36/google-maps-bewertungen-sehenswuerdigkeiten-louvre-eiffelturm-akropolis',
                    	'Google-Maps-Bewertungen: Pyramiden, 1 Stern: »Eigentlich nur eine bisschen größere Sandburg«',
                    	'Ihr Urlaubsziel hatten Sie sich schöner vorgestellt? Sie sind nicht allein! Eine kleine Sammlung mieser Bewertungen zu den größten Sehenswürdigkeiten der Welt'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'13'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div></div><div style="clear:both"></div></div><div onclick="lookupArticleLinkAmount();" style="border:1px solid black;">Click!</div></body></html>

