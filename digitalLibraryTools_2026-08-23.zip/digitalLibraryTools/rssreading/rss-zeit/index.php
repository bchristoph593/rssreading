<?php
	include("../../newsengine/uc/newsPortal_01.php");
	include("../uc/header_imports_01.php");
	
	$xslPath = "http://localhost/digitalLibraryTools/rssreading/";
   	$xslPath .= "rss-zeit/xsl-sheets/rss-zeit.xsl";
	
	// echo "xslPath: ". $xslPath."<br />";
	
//	$url_newsengine = "http://newsengine.v232681353.yourvserver.net/rss-news"; 
//	$url = $url_newsengine . "/spiegelonline/".$section."/index.rss";
	
	$portal = "zeit";
	$section = "schlagzeilen";
	
	$url_newsengine = "http://localhost/digitalLibraryTools/newsengine/"; 
	$url = $url_newsengine . "ressourceBuilder.php?";
	$url .= "portal=".$portal;
	
	$rssPath = $url;

	// echo "rssPath: ". $rssPath."<br />";
	
	$newsPortal = new NewsPortal();
	$newsPortal->setXSLSheet( $xslPath );
	$newsPortal->setRSSFile( $rssPath );
	$newsPortal->doProcessing();
	
	include("temp.php");
?>
