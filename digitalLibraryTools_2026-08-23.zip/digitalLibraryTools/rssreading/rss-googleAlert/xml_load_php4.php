<?php
	echo "php4". "<br><hr/>";

	// echo phpinfo();

	function loadXMLFile($debug, $filename) {
		$xmlDoc = "";
		
		$xmlDoc = xmldocfile( $filename );
		
		if($debug) {
			if($xmlDoc) {
				print_r( $xmlDoc );
				echo "<br>";
				
			} else {
				echo "error on loading xml-doc: ". $filename. "<br>";
			}
		}
		
		return $xmlDoc;
	}

	/*
	 * XSLT Transformation
	 *
	 */

	function xslt_importStylesheet($debug, $xslDoc) {
		$proc = xslt_create();
		
		return $proc;
	}
	
	function xslt_transformToXML($debug, $xsltProc, $xmlDoc, $xmlFilePath, $xslFilePath) {
		$xslFilePath = getcwd(). "/". $xslFilePath;
		echo $xslFilePath. "<br>";
		echo $xmlFilePath. "<br>";
		
		$htmlDocument = xslt_process($xsltProc, $xmlFilePath, $xslFilePath);
		
		if($htmlDocument) {
			$result = 1;
		
		} else {
			$result = 0;
		}
		
		xslt_free($xsltProc);
		
		if($debug) {
			if($result) {
				echo "transformed to html". "<br>";
				
			} else {
				echo "error on transforming". "<br>";
			}
		}
		
		return $htmlDocument;
	}

?>