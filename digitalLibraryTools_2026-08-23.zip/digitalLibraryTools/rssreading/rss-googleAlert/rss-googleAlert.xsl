<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
				<title>RSS Google Alert</title>
				<link href="css/style.css" rel="stylesheet" type="text/css" />
			</head>
			
			<body>
				<div class="divContent">
					
					<div style="border-bottom:1px solid black; padding: 5px; margin: 0px 0px 0px 0px;">
						<form method="get">
							Keywords: <input name="q" type="text" value="" />
							<input type="submit" value="Show Newsletter" />
						</form>
					</div>
					
					<div style="border-bottom:1px solid black; padding: 15px 5px 15px 5px; margin: 0px 0px 15px 0px;">
						<strong>
							RSS Newsletter: <xsl:value-of select="title" />
						</strong>
					</div>
					
					<!-- Nachrichtenagenturen -->			
					<xsl:call-template name="Reuters" />
					
					<!-- Wirtschaftsnachrichten -->
					<xsl:call-template name="Handelsblatt" />
					<xsl:call-template name="Ftd.de" />
					
					<!-- Nachrichten, Magazine -->
					<xsl:call-template name="Faz.Net" />
					<xsl:call-template name="Fr-Online" />
					<xsl:call-template name="SpiegelOnline" />
					<xsl:call-template name="WeltOnline" />
					<xsl:call-template name="Sueddeutsche" />
					<xsl:call-template name="ZeitOnline" />
					<xsl:call-template name="NTV" />
					<xsl:call-template name="FocusOnline" />
					<xsl:call-template name="Stern" />
					<xsl:call-template name="HamburgerAbendblatt" />
					<xsl:call-template name="Tagesspiegel" />
					<xsl:call-template name="TAZ" />
					<xsl:call-template name="EchoOnline" />
					
					<!-- Technologie -->
					<xsl:call-template name="HeiseOnline" />
					<xsl:call-template name="ITTimes" />
					<xsl:call-template name="Golem" />
					<xsl:call-template name="ChipOnline" />
					<xsl:call-template name="PCGamesHardware" />
					<xsl:call-template name="Planet3DNow" />
					
					<!-- Fianzen, Aktien, Wertpapiere -->
					<xsl:call-template name="Finanzen.Net" />
					<xsl:call-template name="Finanznachrichten" />
					<xsl:call-template name="StockWorld" />
					<xsl:call-template name="Aktiencheck" />
					
					<xsl:call-template name="Unclassified" />
					
					<!--
					<xsl:call-template name="" />
					-->
									
				</div>
			</body>
			
		</html>	
	</xsl:template>
	
	<xsl:template name="Reuters">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'reuters')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'reuters')])"/>]
				Reuters
			</strong>
						
			<div class="divNews" style="display:block">				
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'reuters')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Reuters Deutschland'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>                                
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>	
				</xsl:for-each>
			</div>
							
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="Faz.Net">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'faz.net')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				 [<xsl:value-of select="count(item[contains(link, 'faz.net')])"/>]
				Frankfurter Allgemeine Zeitung
			</strong>
						
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'faz.net')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - FAZ - Frankfurter Allgemeine Zeitung'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
							
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="ZeitOnline">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'zeit.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				 [<xsl:value-of select="count(item[contains(link, 'zeit.de')])"/>]
				ZEIT Online
			</strong>
						
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'zeit.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - ZEIT ONLINE'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
							
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="NTV">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'n-tv.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				 [<xsl:value-of select="count(item[contains(link, 'n-tv.de')])"/>]
				n-tv.de NACHRICHTEN
			</strong>
						
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'n-tv.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - n-tv.de NACHRICHTEN'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
							
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="Handelsblatt">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'handelsblatt.com')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'handelsblatt.com')])"/>]
				 Handelsblatt
			</strong>
            							
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'handelsblatt.com')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Handelsblatt'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
                                
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
							
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="Ftd.de">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'ftd.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'ftd.de')])"/>]
				 Financial Times Deutschland
			</strong>
						
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'ftd.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Financial Times Deutschland'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
							
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="Fr-Online">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'fr-online.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'fr-online.de')])"/>]					
				 Frankfurter Rundschau
			</strong>
							
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'fr-online.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Frankfurter Rundschau'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="SpiegelOnline">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'www.spiegel.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'www.spiegel.de')])"/>]
				 Spiegel Online
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'www.spiegel.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Spiegel Online'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="WeltOnline">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, '.welt.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, '.welt.de')])"/>]
				 Welt Online
			</strong>
							
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'www.welt.de')
													or contains(link, 'newsticker.welt.de')
													">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - WELT ONLINE - Welt Online'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="Sueddeutsche">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'sueddeutsche.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'sueddeutsche.de')])"/>]
				 S�ddeutsche Zeitung
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'sueddeutsche.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - sueddeutsche.de'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="Tagesspiegel">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'tagesspiegel.de')])"/>
		</xsl:variable>
		
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'tagesspiegel.de')])"/>]
				 Tagesspiegel
			</strong>
			
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'tagesspiegel.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Tagesspiegel'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="FocusOnline">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'focus.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'focus.de')])"/>]
				 Focus Online
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'focus.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - FOCUS Online'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>
		
	<xsl:template name="Stern">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'stern.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'stern.de')])"/>]
				 Stern
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'stern.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - STERN.DE'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="HamburgerAbendblatt">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'abendblatt.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'abendblatt.de')])"/>]
				 Hamburger Abendblatt
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'abendblatt.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Hamburger Abendblatt'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="TAZ">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'taz.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'taz.de')])"/>]
				 taz. die Tageszeitung
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'taz.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - taz.de'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="EchoOnline">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'echo-online.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'echo-online.de')])"/>]
				 Echo Online
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'echo-online.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Echo-online'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="HeiseOnline">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'heise.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'heise.de')])"/>]
				 Heise
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'heise.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Heise Newsticker'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>                                
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="ITTimes">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'it-times.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'it-times.de')])"/>]
				 IT Times
			</strong>
					
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'it-times.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								<xsl:value-of select="title" />
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="Golem">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'golem.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'golem.de')])"/>]
				 Golem
			</strong>
					 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'golem.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - Golem.de'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>                                
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="PCGamesHardware">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'pcgameshardware.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'pcgameshardware.de')])"/>]
				 PC Games Hardware
			</strong>
					 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'pcgameshardware.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								<xsl:value-of select="title" />
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="ChipOnline">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, '.chip.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, '.chip.de')])"/>]
				 CHIP Online
			</strong>
					 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, '.chip.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								<xsl:value-of select="title" />
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="Planet3DNow">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'planet3dnow.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'planet3dnow.de')])"/>]
				 Planet 3DNow
			</strong>
					 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'planet3dnow.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								<xsl:value-of select="title" />
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="Finanzen.Net">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'finanzen.net')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'finanzen.net')])"/>]
				 Finanzen.net
			</strong>
					 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'finanzen.net')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								<xsl:value-of select="title" />
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>

	<xsl:template name="Finanznachrichten">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'finanznachrichten.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'finanznachrichten.de')])"/>]
				 Finanznachrichten.de
			</strong>
					 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'finanznachrichten.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
                                
								<xsl:call-template name="replace-string"> <!-- imported template -->
                                    <xsl:with-param name="text" select="title"/>
                                    <xsl:with-param name="replace" select="' - FinanzNachrichten.de'"/>
                                    <xsl:with-param name="with" select="''"/>
								</xsl:call-template>
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
						
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="StockWorld">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'stock-world')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'stock-world')])"/>]
				 Stock World
			</strong>
						 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'stock-world')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								<xsl:value-of select="title" />
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="Aktiencheck">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'aktiencheck.de')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
			<strong>
				&gt;
				[<xsl:value-of select="count(item[contains(link, 'aktiencheck.de')])"/>]
				 Aktien Check
			</strong>
						 
			<div class="divNews" style="display:block">
				<xsl:for-each select="item">
					<xsl:if test="contains(link, 'aktiencheck.de')">
						<div class="divItemDate">
							<xsl:value-of select="substring(pubDate, 6, 20)" />
						</div>
						<div class="divItemLink">
							<a target="_blank">
								<xsl:attribute name="href">
									<xsl:value-of select="link" />
								</xsl:attribute>
								<xsl:value-of select="title" />
							</a>
						</div>
						<div style="clear:both">
						</div>
					</xsl:if>
				</xsl:for-each>
			</div>
					
			<br />
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="Unclassified">
	
		<strong>&gt; Unclassified</strong>
		<div class="divNews" style="display:block">
			<xsl:for-each select="item">
				<xsl:if test="contains(link, 'faz.net')=false 
											and contains(link, 'reuters')=false
											and contains(link, 'handelsblatt.com')=false
											and contains(link, 'ftd.de')=false
											and contains(link, 'fr-online.de')=false
											and contains(link, 'www.welt.de')=false
											and contains(link, 'newsticker.welt.de')=false
											and contains(link, 'www.spiegel.de')=false
											and contains(link, 'sueddeutsche.de')=false
											and contains(link, 'tagesspiegel.de')=false
											and contains(link, 'focus.de')=false
											and contains(link, 'stern.de')=false
											and contains(link, 'abendblatt.de')=false
											and contains(link, 'taz.de')=false
											and contains(link, 'zeit.de')=false
											and contains(link, 'n-tv.de')=false
											and contains(link, 'echo-online.de')=false
											and contains(link, 'heise.de')=false
											and contains(link, '.chip.de')=false
											and contains(link, 'it-times.de')=false
											and contains(link, 'golem.de')=false
											and contains(link, 'pcgameshardware.de')=false
											and contains(link, 'planet3dnow.de')=false											
											and contains(link, 'finanzen.net')=false
											and contains(link, 'finanznachrichten.de')=false
											and contains(link, 'stock-world')=false
											and contains(link, 'aktiencheck.de')=false
											">
											
					<div class="divItemDate">
						<xsl:value-of select="substring(pubDate, 6, 20)" />
					</div>
					<div class="divItemLink">
						<a target="_blank">
							<xsl:attribute name="href">
								<xsl:value-of select="link" />
							</xsl:attribute>
							<xsl:value-of select="title" />
						</a>
					</div>
					<div style="clear:both">
					</div>
							
				</xsl:if>								
			</xsl:for-each>
		</div>
	</xsl:template>
    
    <!-- TOOLS: Here: Replace String -->
  	<xsl:template name="replace-string">
    	<xsl:param name="text"/>
        <xsl:param name="replace"/>
        <xsl:param name="with"/>
        <xsl:choose>
          <xsl:when test="contains($text,$replace)">
            <xsl:value-of select="substring-before($text,$replace)"/>
            <xsl:value-of select="$with"/>
            <xsl:call-template name="replace-string">
              <xsl:with-param name="text"
    select="substring-after($text,$replace)"/>
              <xsl:with-param name="replace" select="$replace"/>
              <xsl:with-param name="with" select="$with"/>
            </xsl:call-template>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="$text"/>
          </xsl:otherwise>
        </xsl:choose>
  	</xsl:template>
    
<!--
	<xsl:template name="">
		<xsl:variable name="linkCounter">
			<xsl:value-of select="count(item[contains(link, 'XXX')])"/>
		</xsl:variable>
					
		<xsl:if test="$linkCounter > 0">
		</xsl:if>
	</xsl:template>
-->
	
</xsl:stylesheet>