<?php

	if(file_exists("config/php5.flag")) {
		include("xml_load_php5.php");
	
	} else if(file_exists("config/php4.flag")) {
		include("xml_load_php4.php");
	}

?>

<?php
	$debug = 0;
	$result = "";

	$words = $_GET["q"];

	if($debug) {
		echo "keywords: ";
		echo $words;
		echo "<br>";
	}
	
	/*
	$xslDocFilename = "rss-googleAlert.xsl";
	
	$xslDoc = loadXMLFile($debug, $xslDocFilename);
	
	if($xslDoc) {
		$result = 1;
	} else {
		$result = 0;
	}
	*/
	
	$xslDoc = new DOMDocument();
	$result = $xslDoc->load("rss-googleAlert.xsl");
	
	if($debug) {
		echo "xsl-doc loaded: ";
		echo $result;
		echo "<br>";
	}
	
	/*
	$xmlDocFilename = "http://news.google.de/news?hl=de&tab=wn&ned=de&q=". 
													$words ."&ie=UTF-8&nolr=1&output=rss";
	
	$xmlDoc = loadXMLFile($debug, $xmlDocFilename);
													
	if($xmlDoc) {
		$result = 1;
	} else {
		$result = 0;
	}
	*/
	
	$xmlDoc = new DOMDocument();
  	$result = $xmlDoc->load("http://news.google.de/news?hl=de&tab=wn&ned=de&q=". $words .
								"&ie=UTF-8&nolr=1&output=rss");
	
	if($result) {
		if($debug) {
			echo "rss-doc loaded: ";
			echo $result;
			echo "<br>";
		}
			 
		/*
		$proc = xslt_importStylesheet($debug, $xslDoc);
		
		echo "stylesheet imported". "<br>";
				
		$htmlDocument = xslt_transformToXML($debug, $proc, $xmlDoc, $xmlDocFilename, $xslDocFilename);
		*/
		
		$proc = new XSLTProcessor();
		$result = $proc->importStylesheet($xslDoc);
		
		if($debug) {
			echo "stylesheet imported: ";
			echo $result;
			echo "<br>";
		}
		
		$htmlDocument = $proc->transformToXML($xmlDoc);
		
		// replace &quot; with "

		$htmlDocument = ereg_replace("�", "&uuml;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&Uuml;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&auml;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&Auml;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&ouml;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&Ouml;", $htmlDocument);

		$htmlDocument = ereg_replace("�", "&szlig;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&sect;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&eacute;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&laquo;", $htmlDocument);
		$htmlDocument = ereg_replace("�", "&raquo;", $htmlDocument);

		$htmlDocument = ereg_replace("&amp;quot;", "\"", $htmlDocument);
		$htmlDocument = ereg_replace("&amp;gt;", ">", $htmlDocument);
		$htmlDocument = ereg_replace("&amp;#39;", "'", $htmlDocument);
		$htmlDocument = ereg_replace("&amp;amp;", "&", $htmlDocument);
		
		
		echo $htmlDocument;
	
	} else {
		echo "error while loading rss-document!";
	}
	
?>