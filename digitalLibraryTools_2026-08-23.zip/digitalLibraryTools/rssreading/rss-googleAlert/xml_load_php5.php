<?php
	echo "php5". "<br><hr/>";

	function loadXMLFile($debug, $filename) {
		$xmlDoc = "";
		
		$xmlDoc = new DOMDocument();
  	$result = $xmlDoc->load( $filename );
		
		if($debug) {
			if($xmlDoc) {
				print_r( $xmlDoc );
				echo "<br>";
				
			} else {
				echo "error on loading xml-doc: ". $filename. "<br>";
			}
		}
		
		return $xmlDoc;
	}

	/*
	 * XSLT Transformation
	 *
	 */
	
	function xslt_importStylesheet($debug, $xslDoc) {
		$proc = new XSLTProcessor();
		$result = $proc->importStylesheet($xslDoc);
			
		if($debug) {
			echo "stylesheet imported: ";
			echo $result;
			echo $proc;
			echo "<br>";
		}
		
		return $proc;
	}
	
	function xslt_transformToXML($debug, $xsltProc, $xmlDoc) {
		$htmlDocument = $xsltProc->transformToXML($xmlDoc);
		
		return $htmlDocument;
	}

?>