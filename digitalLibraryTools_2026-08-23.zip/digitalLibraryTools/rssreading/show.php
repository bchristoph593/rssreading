<?php
	$url = mysql_escape_string( $_GET["ref"] );
	// $url = $_GET["ref"];

	/*
	  need for security checks
	 */
	// echo $url;
	header('Location:'. $url);
	
	/*
	 * DEBUG output to file
	 *
	 */
	
	//Gets the IP address
	$ip = mysql_escape_string( getenv("REMOTE_ADDR") );
	
	$adminAgent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6 (.NET CLR 3.5.30729) -- NT5-FX3.5-USR";
	$secureID = "jhg43n34oiger986nw7k";

	if(substr($ip, 0, 7) == "66.249.") {
	    // google-bot
	    $filename = "access_google_";
		
	} else 	if(substr($ip, 0, 13) == "67.195.37.184") {
		// yahoo-bot
		$filename = "access_yahoo_";
		
	} else 	if(substr($ip, 0, 7) == "130.83.") {
		// hrz tu darmstadt
		$filename = "access_hrz_";
		
	} else {
	    $filename = "access_";
		
		if($_SERVER['HTTP_USER_AGENT'] == $adminAgent) {
			$filename .= "admin_";
		}	
	}
	
	$f = fopen($filename. $secureID .'.log','a');
	
	fwrite($f, date("T -- Y-m-d H:i:s") );
	fwrite($f, " -- ");
	fwrite($f, $ip);
	fwrite($f, " -- ");
	fwrite($f, $url);
	
	if($_SERVER['HTTP_USER_AGENT'] == $adminAgent) {
	    fwrite($f, " -- ");
	    fwrite($f, "admin");
	}
	
	fwrite($f, "\n");
	
	fclose($f);
?>
