<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:content="http://purl.org/rss/1.0/modules/content/"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="ROBOTS" content="All"></meta><meta name="revisit-after" content="2 days"></meta><title>Spiegel Online | Schlagzeilen - crossreading</title><link href="/css/style.css" rel="stylesheet" type="text/css"></link></head><body><script type="text/javascript" src="/js/unfold.js"></script><script type="text/javascript" src="/js/visitLink.js"></script><div class="divContainer"><div style="display:block;"><?php 
							echo getSiteHeadBar("SpiegelOnline");
						?></div><div class="divMenu"><div class=""><strong>
                                Navigation
                            </strong></div><hr></hr><div class="divMenuLinks"><a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a></div></div><div class="divContent"><strong style="margin:3px;">
                            Newsletter &gt; SPIEGEL ONLINE - Schlagzeilen</strong><br></br><hr></hr><strong xmlns="">&gt; Wirtschaft</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'1',
                    	'17 Feb 2012 18:35:00',
                    	'http://www.spiegel.de/wirtschaft/soziales/0,1518,816095,00.html#ref=rss',
                    	'Dax und Dow im Plus: B�rsianer spekulieren auf rasche Griechen-Rettung',
                    	'B�rse verr�ckt: Der Dax hat am Freitag kr�ftig im Plus geschlossen. Anleger spekulieren auf rasche Hilfe f�r Griechenland. Dabei stellt sich die Mehrheit der Euro-Finanzminister auf ein Scheitern ein. Und nach SPIEGEL-Informationen klafft im Rettungspaket eine gro�e L�cke.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wirtschaft',
                    	'2',
                    	'17 Feb 2012 17:44:00',
                    	'http://www.spiegel.de/wirtschaft/soziales/0,1518,816056,00.html#ref=rss',
                    	'Aktion in der Schweiz: Ermittler beschlagnahmen falsche US-Anleihen im Billionenwert',
                    	'Es�k�nnte einer der spektakul�rsten Betrugsversuche in der Finanzgeschichte sein: Schweizer Beh�rden haben im Auftrag der italienischen Staatsanwaltschaft gef�lschte US-Anleihen im Wert von sechs Billionen Dollar konfisziert.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wirtschaft',
                    	'2'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Politik</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'politik',
                    	'1',
                    	'17 Feb 2012 21:39:00',
                    	'http://www.spiegel.de/politik/deutschland/0,1518,816112,00.html#ref=rss',
                    	'Umfrage zu Wulff-Nachfolger: 43 Prozent der Deutschen w�nschen sich Gauck',
                    	'Die Mehrheit der Deutschen w�nscht sich nach dem R�cktritt von Christian Wulff einen �berparteilichen Bundespr�sidenten. In einer Umfrage erzielte jedoch keiner der m�glichen Nachfolger die Mehrheit: Joachim Gauck kam auf 43 Prozent, jetzige Minister nur auf gut 20 Prozent der Stimmen.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'2',
                    	'17 Feb 2012 21:05:00',
                    	'http://www.spiegel.de/politik/deutschland/0,1518,816107,00.html#ref=rss',
                    	'Wulff-Nachfolge: De Maizi�re sagt ab',
                    	'Ihn darf man schon mal von der Kandidatenliste streichen: Verteidigungsminister Thomas de Maizi�re will nicht neuer Bundespr�sident werden,�k�ndigte der hoch gehandelte�CDU-Politiker an.�Die Koalitionsspitzen trafen sich am Abend zu ersten Sondierungsgespr�chen zur Nachfolge von Christian Wulff. '
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'3',
                    	'17 Feb 2012 21:00:39',
                    	'http://www.spiegel.de/politik/ausland/0,1518,816110,00.html#ref=rss',
                    	'Anschlag auf Kapitol vereitelt: FBI lockt Terrorverd�chtigen in die Falle ',
                    	'Die US-Polizei hat in der Hauptstadt Washington einen Terrorverd�chtigen festgenommen: Der 29-j�hrige Mann soll einen Selbstmordanschlag auf das Kapitol geplant haben - dann lockte ihn das FBI in die Falle.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'4',
                    	'17 Feb 2012 18:37:00',
                    	'http://www.spiegel.de/politik/deutschland/0,1518,816010,00.html#ref=rss',
                    	'Politiker und ihre Posten: Die Kunst des aufrechten Abgangs',
                    	'Ohne wenn und aber Verantwortung �bernehmen und den Stuhl r�umen: Das hat man unter Politikern nicht oft. Die meisten kleben an ihren Posten, bis es gar nicht mehr anders geht - und der Moment f�r einen Abgang in Ehren verpasst und das Comeback verbaut ist. '
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'5',
                    	'17 Feb 2012 18:28:00',
                    	'http://www.spiegel.de/politik/deutschland/0,1518,816093,00.html#ref=rss',
                    	'Bundespr�sidenten-Abgang: Migrantenverb�nde und Glaubensgemeinschaften traurig �ber Wulff-R�cktritt',
                    	'Der R�cktritt von Bundespr�sident Christian Wulff st��t selbst in Reihen von Schwarz-Gelb auf Zustimmung - mit gro�em Bedauern haben dagegen Migrantenverb�nde und Glaubensgemeinschaften seine Demission aufgenommen. '
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'6',
                    	'17 Feb 2012 18:10:00',
                    	'http://www.spiegel.de/politik/deutschland/0,1518,816034,00.html#ref=rss',
                    	'Neuer Bundespr�sident: Gesucht: Einer f�r alle',
                    	'Christian Wulffs R�cktritt trifft auch die Kanzlerin. Angela Merkel hat den peinlichsten Bundespr�sidenten in der Geschichte des Landes zu verantworten. Jetzt ist sie in�derselben Lage wie nach dem AKW-Gau in Fukushima: Sie kann einen zentralen politischen Fehler korrigieren.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'7',
                    	'17 Feb 2012 17:28:00',
                    	'http://www.spiegel.de/politik/deutschland/0,1518,815875,00.html#ref=rss',
                    	'Wulff-R�cktritt: Der N�chste, bitte!',
                    	'Die kurze Abschiedsrede, der Dank an seine Frau, die�guten W�nsche f�r die B�rger: Fast k�nnte man den Abgang�von Christian Wulff w�rdig nennen. Wenn er nicht in den letzten Wochen so viel Respekt verspielt h�tte - und�am Ende Fragen blieben,�wie sie noch keinem Vorg�nger gestellt wurden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'8',
                    	'17 Feb 2012 17:12:00',
                    	'http://www.spiegel.de/politik/deutschland/0,1518,816047,00.html#ref=rss',
                    	'Presseschau zum Wulff-R�cktritt: "Endlich! Endlich ist er weg"',
                    	'Aufatmen, Erleichterung, sogar Jubel: �berschw�nglich reagieren Medien in Deutschland auf Christian Wulffs R�cktritt vom h�chsten Amt im Staat. Tenor: Der j�ngste Pr�sident, den das Land je hatte, ist an der eigenen Unreife gescheitert. Das Ausland fragt sich, wie Kanzlerin Merkel jetzt reagiert. '
                    	);
            	?><?php 
					echo getArticleItem(
                    	'politik',
                    	'9',
                    	'17 Feb 2012 17:02:46',
                    	'http://www.spiegel.de/politik/ausland/0,1518,816043,00.html#ref=rss',
                    	'Ein Jahr Revolution: Ged�mpfte Feierstimmung in Libyen',
                    	'Vor zw�lf Monaten begann der Aufstand gegen das alte libysche Regime: Unter strengen Sicherheitsvorkehrungen ist am Freitag der erste Jahrestag des Revolutionsbeginns gefeiert worden. �berschattet wurde das Jubil�um von einem Konflikt zwischen verdienten K�mpfern und der �bergangsregierung. '
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'politik',
                    	'9'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Netzwelt</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'netzwelt',
                    	'1',
                    	'17 Feb 2012 17:07:00',
                    	'http://www.spiegel.de/netzwelt/web/0,1518,815920,00.html#ref=rss',
                    	'Netzwelt-Ticker: US-Heimatsch�tzer wollen Facebook �berwachen',
                    	'Die �berwachung "sozialer Medien" gef�hrdet B�rgerrechte,�f�rchten mehrere US-Abgeordnete anl�sslich�einer Anh�rung zu den Praktiken des Heimatschutzministeriums. Au�erdem im �berblick: Probleme mit SSD-Festplatten und gef�hrlicher Spieltrieb.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'netzwelt',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Unispiegel</strong><div xmlns="" class="divLinkSection"><?php 
            	echo getContainerListVisited(
                		'unispiegel',
                    	'0'
                    	);
			?></div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Wissenschaft</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'wissenschaft',
                    	'1',
                    	'17 Feb 2012 20:27:00',
                    	'http://www.spiegel.de/wissenschaft/medizin/0,1518,816089,00.html#ref=rss',
                    	'Forscherstreit: WHO lehnt Zensur der�Supervirus-Daten ab',
                    	'Die Debatte �ber das hochgef�hrliche, im Labor gez�chtete Grippevirus geht weiter: Das US-Gremium f�r Biosicherheit r�t dringend zu einer Zensur der Studienergebnisse. Die WHO jedoch fordert eine vollst�ndige Ver�ffentlichung aller Daten - aber auf keinen Fall sofort.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wissenschaft',
                    	'2',
                    	'17 Feb 2012 18:27:00',
                    	'http://www.spiegel.de/wissenschaft/technik/0,1518,816077,00.html#ref=rss',
                    	'Milit�rkooperation: Frankreich und Gro�britannien planen Drohnen-Entwicklung',
                    	'Kampfdrohnen, Flugzeugtr�ger,�Druckwasserreaktoren: Paris und London planen enge Kooperationen bei milit�rischen und Atom-Projekten. Andere europ�ische Staaten seien als weitere Partner willkommen, sagte Frankreichs Pr�sident Nicolas Sarkozy.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'wissenschaft',
                    	'3',
                    	'17 Feb 2012 17:29:00',
                    	'http://www.spiegel.de/wissenschaft/mensch/0,1518,816030,00.html#ref=rss',
                    	'Steile These: Klang-Trick soll f�r Stonehenge-Bau gesorgt haben',
                    	'Was hat die Urahnen der Briten dazu gebracht, vor 5000 Jahren die Steins�ulen von Stonehenge aufzustellen? An dieser Frage arbeiten sich Arch�ologen seit langem ab. Eine neue Theorie besagt nun, dass der Bau eine Frage des Sounds gewesen sein k�nnte.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'wissenschaft',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport - Fussball</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'1',
                    	'17 Feb 2012 22:30:00',
                    	'http://www.spiegel.de/sport/fussball/0,1518,816109,00.html#ref=rss',
                    	'Fu�ball-Bundesliga: Hoffenheim verpasst Sieg gegen Mainz',
                    	'1899 Hoffenheim ist zum Auftakt des 22. Spieltags nicht �ber ein Unentschieden gegen Mainz 05 hinausgekommen. Das Team von Markus Babbel war fr�h durch ein Eigentor�des FSV-Verteidigers Nikolce Noveski�in F�hrung gegangen - doch noch vor der Pause erzielte Mohamed Zidan den Ausgleich.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'2',
                    	'17 Feb 2012 21:35:00',
                    	'http://www.spiegel.de/sport/fussball/0,1518,816111,00.html#ref=rss',
                    	'Fu�ball-Bundesliga: Hertha soll sich mit Rehhagel einig sein',
                    	'Es w�re ein sensationelles Comeback: Otto Rehhagel soll Medienberichten zufolge neuer Trainer bei Hertha BSC Berlin werden. Der 73 Jahre alte Coach hat seit 2010 keine Mannschaft mehr trainiert. '
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sportFussball',
                    	'3',
                    	'17 Feb 2012 20:05:00',
                    	'http://www.spiegel.de/sport/fussball/0,1518,816102,00.html#ref=rss',
                    	'2. Fu�ball-Bundesliga: St. Pauli erobert die Tabellenspitze',
                    	'Drei�R�nge hochgeklettert: Der FC St. Pauli hat die Tabellenf�hrung in der zweiten Bundesliga �bernommen. Das Team von Andre Schubert siegte knapp in Duisburg. Der Karlsruher SC�verlie� nach dem Erfolg gegen Energie Cottbus die Abstiegsr�nge. Paderborn spielte remis gegen Dresden.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sportFussball',
                    	'3'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sport</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sport',
                    	'1',
                    	'17 Feb 2012 20:02:31',
                    	'http://www.spiegel.de/sport/wintersport/0,1518,816104,00.html#ref=rss',
                    	'Wintersport: Pittin schwer gest�rzt, Freitag mit Rekordweite',
                    	'Der Weltcup der Nordischen Kombinierer in Klingenthal ist nach einem schweren Sturz von Alessandro Pittin abgesagt worden. Richard Freitag sprang beim Skiflug-Weltcup in Oberstdorf weiter als je zuvor. Und: Sandra Kiriasis ist im Kampf um die Goldmedaille bei der Bob-WM unter Zugzwang.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sport',
                    	'1'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br><strong xmlns="">&gt; Sonstige</strong><div xmlns="" class="divLinkSection">
<?php 
					echo getArticleItem(
                    	'sonstige',
                    	'1',
                    	'17 Feb 2012 22:23:36',
                    	'http://www.spiegel.de/panorama/justiz/0,1518,816113,00.html#ref=rss',
                    	'Familie erschlagen: Belgisches Gericht verurteilt deutschen Axtm�rder',
                    	'Mit mehr als 50 Axthieben brachte er seine Frau, seinen Sohn und seine Tochter um. Jetzt, mehr als vier Jahre nach der Tat, verurteilte ein belgisches Gericht den Deutschen - der Sozialp�dagoge soll lebenslang in Haft. '
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'2',
                    	'17 Feb 2012 20:14:00',
                    	'http://www.spiegel.de/kultur/gesellschaft/0,1518,816031,00.html#ref=rss',
                    	'Herr Wulff reist heim: Letzter Halt Gro�burgwedel',
                    	'Mal den Maschmeyer anrufen? Oder�lieber�Peter Hintze? Oder erstmal in "Kokow�h"? Und dann�w�re da auch noch Preisskat! Bald hat Christian Wulff Schloss Bellevue endg�ltig ger�umt und ist auf seinem�allerletzten�Weg von Berlin nach Gro�burgwedel. SPIEGEL ONLINE hat sich schon mal eingef�hlt.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'3',
                    	'17 Feb 2012 19:46:00',
                    	'http://www.spiegel.de/panorama/0,1518,816103,00.html#ref=rss',
                    	'Angebliche Fehlgeburt: Costa Crociere�k�ndigt Klage gegen Italienerin an',
                    	'Eine Italienerin�gab an, wenige Tage nach ihrer Rettung von der havarierten�"Costa Concordia"�eine Fehlgeburt erlitten zu haben - und forderte eine Million Euro Schadensersatz. Doch Recherchen der Reederei und eines Fernsehsenders�ergaben: Die Geschichte ist offenbar erfunden.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'4',
                    	'17 Feb 2012 18:33:00',
                    	'http://www.spiegel.de/panorama/justiz/0,1518,816064,00.html#ref=rss',
                    	'Museumsraub in Griechenland: Attacke aufs Herz von Olympia',
                    	'Mit Kalaschnikows bewaffnete�Gangster haben ein Museum im antiken Olympia �berfallen und Kunstsch�tze von unsch�tzbarem Wert geraubt. Die Emp�rung in Griechenland ist gro�. Ist der rigide Sparkurs der Regierung Ursache des Coups? '
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'5',
                    	'17 Feb 2012 18:32:00',
                    	'http://www.spiegel.de/panorama/0,1518,815983,00.html#ref=rss',
                    	'New Yorker Fashion Week: Der Laufsteg kommt ins Wohnzimmer',
                    	'�ber 300 Shows gab es auf der New York Fashion Week - selbst f�r den flei�igsten Fachbesucher nicht zu schaffen. Neben viel luxuri�ser Kleidung zeigte die Modewoche vor allem eines: Die Designer wollen Kunden direkt erreichen, �ber YouTube, Livestreams und Videos.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'6',
                    	'17 Feb 2012 18:32:00',
                    	'http://www.spiegel.de/kultur/gesellschaft/0,1518,816096,00.html#ref=rss',
                    	'Britische Medien: Murdoch k�ndigt "Sun on Sunday" an',
                    	'Scotland Yard nimmt reihenweise seine Journalisten fest, doch nun holt Medienmogul Rupert Murdoch zum Befreiungsschlag aus: In London bekennt er sich zu seinem umstrittenen Boulevardblatt "Sun" - und k�ndigt eine neue Sonntagszeitung an.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'7',
                    	'17 Feb 2012 18:05:00',
                    	'http://www.spiegel.de/panorama/justiz/0,1518,816014,00.html#ref=rss',
                    	'Drogenschmuggel: Fluggast hat 68 Kokainbeutel im K�rper',
                    	'Er hatte zwei Kilogramm Kokain im Magen: Ein kolumbianischer Drogenschmuggler ist Zollfahndern am M�nchner Flughafen ins Netz gegangen. Der 45-J�hrige war auf dem�Weg nach Spanien.'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'8',
                    	'17 Feb 2012 17:42:30',
                    	'http://www.spiegel.de/panorama/0,1518,816070,00.html#ref=rss',
                    	'Augenblick: Grash�pfer',
                    	''
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'9',
                    	'17 Feb 2012 17:19:00',
                    	'http://www.spiegel.de/kultur/kino/0,1518,815725,00.html#ref=rss',
                    	'Doku �ber den Thomanerchor: Jauchzet, frohlocket! Und verkl�ret.',
                    	'Jesus, ist das�harmonisch! P�nktlich zum�800-j�hrigen Bestehen startet eine Kinodoku �ber den weltber�hmten Leipziger Thomanerchor.�"Die Thomaner" macht Lust auf Kirchenmusik und zeigt Jungen, von denen Familienministerin Schr�der nur tr�umen kann. Aber�warum nur diese Heile-Welt-Blase?'
                    	);
            	?><?php 
					echo getArticleItem(
                    	'sonstige',
                    	'10',
                    	'17 Feb 2012 16:48:00',
                    	'http://www.spiegel.de/reise/aktuell/0,1518,816008,00.html#ref=rss',
                    	'Airport Frankfurt: Flughafen trotzt Streik-Chaos',
                    	'Der Streik der�Vorfeldkontrolle in Frankfurt scheint seine Wirkung bislang zu verfehlen. Deutschlands wichtigstes Luftfahrt-Drehkreuz funktioniert, wenn auch mit Einschr�nkungen. Die Gewerkschaft droht mit h�rteren�Ma�nahmen in der kommenden Woche.'
                    	);
            	?><?php 
            	echo getContainerListVisited(
                		'sonstige',
                    	'10'
                    	);
			?>
</div>
<div xmlns="" style="clear:both"></div>
<br></br></div><div style="clear:both"></div></div></body></html>

