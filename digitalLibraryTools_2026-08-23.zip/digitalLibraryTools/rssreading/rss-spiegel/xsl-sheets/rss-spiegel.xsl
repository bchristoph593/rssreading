<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE xsl:stylesheet  [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:content="http://purl.org/rss/1.0/modules/content/">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
	
	<xsl:template match="channel">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
                
                <meta name="ROBOTS" content="All" />
                <meta name="revisit-after" content="2 days" />
                                
                <title>Spiegel Online | Schlagzeilen - crossreading</title>
                <link rel="shortcut icon" href="/images/favicon/fav-spiegel.ico" />
                <link href="/css/style.css" rel="stylesheet" type="text/css" />                
			</head>
						
			<body>
                <script type="text/javascript" src="/js/unfold.js"></script>
                <script type="text/javascript" src="/js/visitLink.js"></script>
                
                <div class="divContainer">
                	<div style="display:block;">
						<xsl:processing-instruction name="php">
							echo getSiteHeadBar("SpiegelOnline");
						?</xsl:processing-instruction>
                    </div>
                    
                	<div class="divMenu">
                    	<div class="">
                            <strong>
                                Navigation
                            </strong>
                        </div>
                        
                        <hr />
                        
                        <div class="divMenuLinks">
                        	<a class="linkSelected" href="index.php">&gt; Aktuelle Nachrichten</a>
                        </div>
                                                
                    </div>
                    
                    <div class="divContent">
                        <strong style="margin:3px;">
                            Newsletter &gt; <xsl:value-of select="title" />
                        </strong>
                        
                        <br />
                        <hr />
                        
						<xsl:call-template name="Wirtschaft" />
                        <br />
						<xsl:call-template name="PolitikEuropa" />
                        <br />
						<xsl:call-template name="Politik" />
                        <br />
						<xsl:call-template name="Netzwelt" />
                        <br />
						<xsl:call-template name="Unispiegel" />
                        <br />
						<xsl:call-template name="Wissenschaft" />
                        <br />
						<xsl:call-template name="SportFussball" />
                        <br />
						<xsl:call-template name="Sport" />
                        <br />
						<xsl:call-template name="Sonstige" />
                        <br />
                                            
                    </div>
                    <div style="clear:both"></div>
                    
            	</div>
                
			</body>
			
		</html>	
	</xsl:template>
    
	<xsl:template name="Wirtschaft">
		<strong>&gt; Wirtschaft</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wirtschaft'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wirtschaft'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="PolitikEuropa">
		<strong>&gt; Politik - Europa</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik-europa'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										and (
											contains(title, 'Sarkozy')
											or contains(title, 'Spanier')
											or contains(title, 'Griechen')
											or contains(title, 'Griechenland')
											or contains(title, 'Athen')
											or contains(title, 'EU')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										and (
											contains(title, 'Sarkozy')
											or contains(title, 'Spanier')
											or contains(title, 'Griechen')
											or contains(title, 'Griechenland')
											or contains(title, 'Athen')
											or contains(title, 'EU')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Politik">
		<strong>&gt; Politik</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/politik'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'politik'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										contains(link, $searchFor)
										and (
											contains(title, 'Sarkozy')
											or contains(title, 'Spanier')
											or contains(title, 'Griechen')
											or contains(title, 'Griechenland')
											or contains(title, 'Athen')
											or contains(title, 'EU')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)=false
									]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										contains(link, $searchFor)
										and (
											contains(title, 'Sarkozy')
											or contains(title, 'Spanier')
											or contains(title, 'Griechen')
											or contains(title, 'Griechenland')
											or contains(title, 'Athen')
											or contains(title, 'EU')
											or contains(title, 'Euro')
											or contains(title, 'Italien')
											or contains(title, 'Berlusconi')
										)=false
									])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    
	<xsl:template name="Netzwelt">
		<strong>&gt; Netzwelt</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/netzwelt'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'netzwelt'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Unispiegel">
		<strong>&gt; Unispiegel</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/unispiegel'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'unispiegel'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="SportFussball">
		<strong>&gt; Sport - Fussball</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/sport/fussball'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sportFussball'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
									contains(link, $searchFor)
									or contains(description, 'Fangewalt im Fu�ball')
									or contains(title, 'kicker.tv:')
									or contains(title, 'Champions League')
									or contains(description, 'Fu�ball')
									or contains(description, 'Champions League')
									or contains(description, 'Premier League')
									or contains(description, 'Rekordmeister')
									or contains(description, 'Nationalspieler')
									or contains(title, 'FC Bayern')
									or contains(description, 'FC Bayern')
									or contains(description, 'Mannschaft von Trainer')
									or contains(description, 'K.o.-Runde')
									or contains(description, 'Spieltag')
									or contains(description, 'Torj�ger')
									or contains(title, 'DFB')
									or contains(description, 'DFB')
									or contains(description, 'Bundesliga')
									or (
										contains(description, 'Abstiegskandidat')
										and contains(description, 'Saison')
									)
									or (
										contains(description, 'Trainer')
										and 
										(
											contains(description, 'Club')
											or contains(description, 'Verein')
										)
									)
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
												contains(link, $searchFor)
												or contains(description, 'Fangewalt im Fu�ball')
												or contains(title, 'kicker.tv:')
												or contains(title, 'Champions League')
												or contains(description, 'Fu�ball')
												or contains(description, 'Champions League')
												or contains(description, 'Premier League')
												or contains(description, 'Rekordmeister')
												or contains(description, 'Nationalspieler')
												or contains(title, 'FC Bayern')
												or contains(description, 'FC Bayern')
												or contains(description, 'Mannschaft von Trainer')
												or contains(description, 'K.o.-Runde')
												or contains(description, 'Spieltag')
												or contains(description, 'Torj�ger')
												or contains(title, 'DFB')
												or contains(description, 'DFB')
												or contains(description, 'Bundesliga')
												or (
													contains(description, 'Abstiegskandidat')
													and contains(description, 'Saison')
												)
												or (
													contains(description, 'Trainer')
													and 
													(
														contains(description, 'Club')
														or contains(description, 'Verein')
													)
												)
											])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sport">
		<strong>&gt; Sport</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/sport'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sport'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
										(
											contains(link, $searchFor)
											and contains(link, '/sport/fussball')=false
										)
										or (
											contains(description, 'Weltmeister')
											and contains(description, 'Moto2')
										)
										or (
											contains(title, 'Sport')
										)
								]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
										(
											contains(link, $searchFor)
											and contains(link, '/sport/fussball')=false
										)
										or (
											contains(description, 'Weltmeister')
											and contains(description, 'Moto2')
										)
										or (
											contains(title, 'Sport')
										)
										])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Wissenschaft">
		<strong>&gt; Wissenschaft</strong>
        
		<xsl:variable name="searchFor">
        	<xsl:value-of select="'/wissenschaft'"/>
		</xsl:variable>
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'wissenschaft'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[contains(link, $searchFor)]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
            
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[contains(link, $searchFor)])"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>

	<xsl:template name="Sonstige">
		<strong>&gt; Sonstige</strong>
        
		<xsl:variable name="sectionName">
        	<xsl:value-of select="'sonstige'"/>
		</xsl:variable>
            
		<div class="divLinkSection">
			<xsl:for-each select="item[
	            						contains(link, '/wirtschaft')=false
	                                    and contains(link, '/politik')=false
	                                    and contains(link, '/unispiegel')=false
	                                    and contains(link, '/netzwelt')=false
	                                    and contains(link, '/sport')=false
										and contains(description, 'Fangewalt im Fu�ball')=false
										and contains(title, 'kicker.tv:')=false
										and contains(title, 'Champions League')=false
										and contains(description, 'Fu�ball')=false
										and contains(description, 'Champions League')=false
										and contains(description, 'Premier League')=false
										and contains(description, 'Rekordmeister')=false
										and contains(description, 'Nationalspieler')=false
										and contains(title, 'FC Bayern')=false
										and contains(description, 'FC Bayern')=false
										and contains(description, 'Mannschaft von Trainer')=false
										and contains(description, 'K.o.-Runde')=false
										and contains(description, 'Spieltag')=false
										and contains(description, 'Torj�ger')=false
										and contains(title, 'DFB')=false
										and contains(description, 'DFB')=false
										and contains(description, 'Bundesliga')=false
										and contains(description, 'Trainer')=false
										and contains(description, 'Spieler')=false
										and (
											contains(description, 'Abstiegskandidat')=false
											and contains(description, 'Saison')=false
										)
										and (
											contains(description, 'Weltmeister')
											and contains(description, 'Moto2')
										)=false
										and (
											contains(title, 'Sport')
										)=false
	                                    and contains(link, '/wissenschaft')=false
                                    ]">
				<xsl:processing-instruction name="php">
					echo getArticleItem(
                    	'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="position()" />',
                    	'<xsl:value-of select="substring(pubDate, 6, 20)" />',
                    	'<xsl:value-of select="link" />',
                    	'<xsl:value-of select="title" />',
                    	'<xsl:value-of select="description"/>'
                    	);
            	?</xsl:processing-instruction>
        	</xsl:for-each>
        	
			<xsl:variable name="linkCounter">
				<xsl:value-of select="count(item[
            							contains(link, '/wirtschaft')=false
                                        and contains(link, '/politik')=false
                                        and contains(link, '/unispiegel')=false
                                        and contains(link, '/netzwelt')=false
			                            and contains(link, '/sport')=false
										and contains(description, 'Fangewalt im Fu�ball')=false
										and contains(title, 'kicker.tv:')=false
										and contains(title, 'Champions League')=false
										and contains(description, 'Fu�ball')=false
										and contains(description, 'Champions League')=false
										and contains(description, 'Premier League')=false
										and contains(description, 'Rekordmeister')=false
										and contains(description, 'Nationalspieler')=false
										and contains(title, 'FC Bayern')=false
										and contains(description, 'FC Bayern')=false
										and contains(description, 'Mannschaft von Trainer')=false
										and contains(description, 'K.o.-Runde')=false
										and contains(description, 'Spieltag')=false
										and contains(description, 'Torj�ger')=false
										and contains(title, 'DFB')=false
										and contains(description, 'DFB')=false
										and contains(description, 'Bundesliga')=false
										and contains(description, 'Trainer')=false
										and contains(description, 'Spieler')=false
										and (
											contains(description, 'Abstiegskandidat')=false
											and contains(description, 'Saison')=false
										)
										and (
											contains(description, 'Weltmeister')
											and contains(description, 'Moto2')
										)=false
										and (
											contains(title, 'Sport')
										)=false
										and contains(link, '/wissenschaft')=false
									]
											)"/>
			</xsl:variable>
			<xsl:processing-instruction name="php">
            	echo getContainerListVisited(
                		'<xsl:value-of select="$sectionName" />',
                    	'<xsl:value-of select="$linkCounter" />'
                    	);
			?</xsl:processing-instruction>
		</div>
        <div style="clear:both">
        </div>
    </xsl:template>
    	
</xsl:stylesheet>
